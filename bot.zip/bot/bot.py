"""
bot.py — Главный файл Telegram-бота.
Запуск: python bot.py
Конфигурация: settings.txt (BOT_TOKEN, OWNER_ID)
"""

import asyncio
import logging
from html import escape
import os
import random
import string
import time
from datetime import datetime, timedelta
from typing import Any, Dict, Optional

import aiohttp
from aiogram import Bot, Dispatcher, F, types
from aiogram.exceptions import TelegramBadRequest
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage
from pyrogram import Client, errors as pyro_errors

import broadcaster
import database as db
import keyboards as kb

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)

# Служебные INFO от aiogram/Pyrogram на каждый update и каждый reconnect
# не несут пользы в обычной работе и быстро раздувают лог. Ошибки уровня
# WARNING/ERROR при этом остаются видимыми.
for _logger_name, _logger_level in {
    "aiogram.event": logging.WARNING,
    "aiogram.dispatcher": logging.WARNING,
    "pyrogram.dispatcher": logging.ERROR,
    "pyrogram.session.session": logging.ERROR,
    "pyrogram.connection.connection": logging.WARNING,
    "pyrogram.connection.transport.tcp": logging.ERROR,
    "asyncio": logging.ERROR,
}.items():
    logging.getLogger(_logger_name).setLevel(_logger_level)

logger = logging.getLogger(__name__)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
SESSIONS_DIR = broadcaster.SESSIONS_DIR

# ─── SETTINGS ─────────────────────────────────────────────────────────────────

def load_settings() -> Dict[str, str]:
    path = os.path.join(BASE_DIR, "settings.txt")
    settings = {}
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if "=" in line:
                    k, v = line.split("=", 1)
                    settings[k.strip()] = v.strip()
    return settings


# ─── FSM STATES ───────────────────────────────────────────────────────────────

class States(StatesGroup):
    # Session add
    sess_phone = State()
    sess_code = State()
    sess_2fa = State()
    sess_name = State()
    sess_rename = State()
    sess_proxy = State()
    # Template
    tpl_name = State()
    tpl_texts_add = State()
    tpl_texts_del = State()
    tpl_chats_add = State()
    tpl_chats_del = State()
    tpl_set_delay_msg = State()
    tpl_set_delay_cycle = State()
    tpl_set_chunk = State()
    tpl_set_typing = State()
    tpl_repeats = State()
    tpl_autosub_delay = State()
    tpl_ac_daily = State()
    tpl_ac_attempts = State()
    tpl_ac_chats = State()
    tpl_ar_cd = State()
    tpl_ar_reply_wait = State()
    tpl_tb_trig_kw = State()
    tpl_tb_trig_reply = State()
    tpl_tb_chats_add = State()
    # Process
    proc_name = State()
    proc_flood_input = State()
    proc_slow_input = State()
    proc_work_input = State()
    # Admin states
    adm_api_id = State()
    adm_api_hash = State()
    adm_broadcast_text = State()
    adm_give_sub_id = State()
    adm_give_sub_days = State()
    adm_take_sub_id = State()
    adm_take_sub_days = State()
    adm_plan_name = State()
    adm_plan_days = State()
    adm_plan_price = State()
    adm_plan_discount = State()
    adm_plan_discount_until = State()
    adm_promo_code = State()
    adm_promo_type = State()
    adm_promo_value = State()
    adm_promo_uses = State()
    adm_promo_activation = State()
    adm_promo_discount_duration = State()
    adm_admin_add = State()
    adm_admin_remove = State()
    adm_link = State()
    adm_media_val = State()
    adm_ref_level_count = State()
    adm_ref_level_data = State()
    adm_cryptobot_token = State()
    adm_user_search = State()
    adm_session_search = State()
    adm_user_ban_id = State()
    ref_withdraw = State()
    promo_code = State()


# Temp storage for multi-step flows
_temp: Dict[int, Any] = {}

# Pyrogram clients for auth flow: uid -> Client
_auth_clients: Dict[int, Client] = {}


# ─── UTILS ────────────────────────────────────────────────────────────────────

def fmt_sub(user_id: int) -> str:
    if db.has_subscription(user_id):
        days = db.sub_days_left(user_id)
        return f"✅ Осталось {days} дн."
    return "❌ Отсутствует"


def parse_interval(text: str):
    text = text.strip()
    if "-" in text:
        parts = text.split("-")
        try:
            return int(parts[0].strip()), int(parts[1].strip())
        except Exception:
            return None, None
    try:
        v = int(text)
        return v, v
    except Exception:
        return None, None


def parse_duration(text: str):
    """Парсит дни.часы.минуты; 0.0.0 означает бессрочно."""
    parts = (text or "").strip().split(".")
    if len(parts) != 3:
        return None
    try:
        days, hours, minutes = map(int, parts)
        if days < 0 or hours < 0 or hours > 23 or minutes < 0 or minutes > 59:
            return None
        return days * 86400 + hours * 3600 + minutes * 60
    except ValueError:
        return None


async def safe_edit(message: types.Message, text: str, reply_markup=None, parse_mode: str = "HTML"):
    try:
        await message.edit_text(text, reply_markup=reply_markup, parse_mode=parse_mode,
                                disable_web_page_preview=True)
    except TelegramBadRequest:
        pass


async def safe_answer(message: types.Message, text: str, reply_markup=None, parse_mode: str = "HTML"):
    try:
        await message.answer(text, reply_markup=reply_markup, parse_mode=parse_mode,
                             disable_web_page_preview=True)
    except Exception:
        pass


# ─── /start ───────────────────────────────────────────────────────────────────

async def cmd_start(message: types.Message, state: FSMContext, bot: Bot):
    await state.clear()
    user = message.from_user
    text = message.text or ""

    # Handle referral
    ref_code = None
    if " " in text:
        arg = text.split(" ", 1)[1].strip()
        if arg.startswith("ref_"):
            ref_code = arg

    ref_by = None
    existing_user = db.get_user(user.id)
    if ref_code and existing_user is None:
        ref_user = db.get_user_by_ref(ref_code)
        if ref_user and ref_user["user_id"] != user.id:
            ref_by = ref_user["user_id"]

    db.ensure_user(user.id, user.username, user.first_name, ref_by=ref_by)
    if ref_by:
        db.record_ref_visit(ref_code, user.id)

    u = db.get_user(user.id)
    if u and u.get("banned"):
        await message.answer("🚫 Ваш аккаунт заблокирован.")
        return

    await message.answer("🏠 <b>Главное меню</b>", reply_markup=kb.main_menu(user.id), parse_mode="HTML")


# ─── NAVIGATION ───────────────────────────────────────────────────────────────

async def nav_main_menu(event, state: FSMContext):
    await state.clear()
    uid = event.from_user.id
    if isinstance(event, types.CallbackQuery):
        await safe_edit(event.message, "🏠 <b>Главное меню</b>", reply_markup=kb.main_menu(uid))
        await event.answer()
    else:
        await event.answer("🏠 <b>Главное меню</b>", reply_markup=kb.main_menu(uid), parse_mode="HTML")


# ─── PROFILE ──────────────────────────────────────────────────────────────────

async def cb_profile(cb: types.CallbackQuery):
    uid = cb.from_user.id
    u = db.get_user(uid)
    sessions = db.get_sessions(uid)
    running = sum(1 for s in sessions if broadcaster.is_running(s["id"]))
    created = u.get("created_at", "—")[:10] if u else "—"

    check_stats = db.get_check_stats(uid)
    check_text = "нет" if not check_stats else ", ".join(
        f"{row['amount']:.8g} {row['currency']} ({row['checks']} шт.)"
        for row in check_stats
    )
    text = (
        f"👤 <b>Профиль</b>\n\n"
        f"🆔 ID: <code>{uid}</code>\n"
        f"📅 Дата регистрации: {created}\n"
        f"💳 Подписка: {fmt_sub(uid)}\n\n"
        f"📱 Подключено сессий: {len(sessions)}\n"
        f"⚡ Работающих сессий: {running}\n"
        f"📨 Всего отправлено сообщений: {u.get('messages_sent', 0) if u else 0}\n"
        f"🧾 Поймано чеков: {check_text}"
    )
    await safe_edit(cb.message, text, reply_markup=kb.profile_kb())
    await cb.answer()


# ─── SESSIONS ─────────────────────────────────────────────────────────────────

async def cb_sessions(cb: types.CallbackQuery, state: FSMContext):
    await state.clear()
    uid = cb.from_user.id
    if not db.has_subscription(uid) and not db.is_admin(uid):
        await cb.answer("❌ Требуется подписка", show_alert=True)
        return
    await safe_edit(cb.message, "📱 <b>Управление сессиями</b>", reply_markup=kb.sessions_kb(uid))
    await cb.answer()


async def cb_sess_open(cb: types.CallbackQuery):
    sess_id = int(cb.data.split(":")[1])
    sess = db.get_session(sess_id)
    if not sess:
        await cb.answer("Сессия не найдена", show_alert=True)
        return
    proxy = f"{sess['proxy_host']}:{sess['proxy_port']}" if sess.get("proxy_host") else "Нет"
    text = (
        f"📱 <b>Сессия: {sess['name']}</b>\n\n"
        f"📞 Телефон: {sess.get('phone', '—')}\n"
        f"🌐 Прокси: {proxy}\n"
        f"📨 Отправлено: {sess.get('messages_sent', 0)}\n"
        f"🕐 Последний запуск: {sess.get('last_run') or '—'}"
    )
    await safe_edit(cb.message, text, reply_markup=kb.session_menu_kb(sess_id))
    await cb.answer()


async def cb_sess_stats(cb: types.CallbackQuery):
    sess_id = int(cb.data.split(":")[1])
    sess = db.get_session(sess_id)
    if not sess:
        await cb.answer("Не найдено", show_alert=True)
        return
    check_stats = db.get_session_check_stats(sess_id)
    check_text = "нет" if not check_stats else ", ".join(
        f"{row['amount']:.8g} {row['currency']} ({row['checks']} шт.)"
        for row in check_stats
    )
    text = (
        f"📊 <b>Статистика сессии: {sess['name']}</b>\n\n"
        f"🆔 TG ID: {sess.get('tg_id', '—')}\n"
        f"👤 Username: @{sess.get('tg_username') or '—'}\n"
        f"📨 Отправлено сообщений: {sess.get('messages_sent', 0)}\n"
        f"🧾 Поймано чеков: {check_text}\n"
        f"🕐 Последний запуск: {sess.get('last_run') or '—'}"
    )
    await safe_edit(cb.message, text, reply_markup=kb.kb([kb.btn("⬅️ Назад", f"sess_open:{sess_id}")]))
    await cb.answer()


async def cb_sess_rename(cb: types.CallbackQuery, state: FSMContext):
    sess_id = int(cb.data.split(":")[1])
    _temp[cb.from_user.id] = {"sess_id": sess_id}
    await state.set_state(States.sess_rename)
    await safe_edit(cb.message, "✏️ Введите новое имя сессии:", reply_markup=kb.kb(kb.back(f"sess_open:{sess_id}")))
    await cb.answer()


async def cb_sess_add(cb: types.CallbackQuery, state: FSMContext):
    uid = cb.from_user.id
    if not db.has_subscription(uid) and not db.is_admin(uid):
        await cb.answer("❌ Требуется подписка", show_alert=True)
        return
    api_id = db.get_setting("api_id")
    api_hash = db.get_setting("api_hash")
    if not api_id or not api_hash:
        await cb.answer("❌ API ключи не настроены. Обратитесь к администратору.", show_alert=True)
        return
    await state.set_state(States.sess_phone)
    await safe_edit(cb.message,
                    "📱 <b>Добавление сессии</b>\n\nВведите номер телефона в формате: <code>+79001234567</code>",
                    reply_markup=kb.kb(kb.back("sessions")))
    await cb.answer()


async def state_sess_phone(message: types.Message, state: FSMContext):
    uid = message.from_user.id
    phone = message.text.strip()
    api_id = db.get_setting("api_id")
    api_hash = db.get_setting("api_hash")

    session_id_temp = f"tmp_{uid}"
    spath = os.path.join(SESSIONS_DIR, session_id_temp)

    client = Client(spath, api_id=int(api_id), api_hash=api_hash, no_updates=True)
    try:
        await client.connect()
        sent = await client.send_code(phone)
        _auth_clients[uid] = client
        _temp[uid] = {"phone": phone, "phone_code_hash": sent.phone_code_hash}
        await state.set_state(States.sess_code)
        await message.answer(
            "📨 Код отправлен на ваш аккаунт.\n\n"
            "Введите код с префиксом <code>00</code>\n"
            "Пример: если код <code>12345</code>, введите <code>0012345</code>",
            parse_mode="HTML",
            reply_markup=kb.kb(kb.back("sessions")),
        )
    except Exception as e:
        try:
            await client.disconnect()
        except Exception:
            pass
        await message.answer(f"❌ Ошибка: {e}")
        await state.clear()


async def state_sess_code(message: types.Message, state: FSMContext):
    uid = message.from_user.id
    code_raw = message.text.strip()
    code = code_raw.lstrip("0") if code_raw.startswith("00") else code_raw

    client = _auth_clients.get(uid)
    temp = _temp.get(uid, {})
    if not client or not temp:
        await state.clear()
        await message.answer("❌ Сессия истекла. Начните заново.")
        return

    try:
        await client.sign_in(temp["phone"], temp["phone_code_hash"], code)
        me = await client.get_me()
        await _finalize_session(uid, client, me, message, state)
    except pyro_errors.SessionPasswordNeeded:
        await state.set_state(States.sess_2fa)
        await message.answer(
            "🔒 Введите пароль двухфакторной аутентификации:",
            reply_markup=kb.kb(kb.back("sessions")),
        )
    except Exception as e:
        await message.answer(
            f"❌ Ошибка: {e}",
            reply_markup=kb.kb(kb.back("sessions")),
        )
        await _cleanup_auth(uid)
        await state.clear()


async def state_sess_2fa(message: types.Message, state: FSMContext):
    uid = message.from_user.id
    client = _auth_clients.get(uid)
    if not client:
        await state.clear()
        return
    try:
        await client.check_password(message.text.strip())
        me = await client.get_me()
        await _finalize_session(uid, client, me, message, state)
    except Exception as e:
        await message.answer(
            f"❌ Ошибка 2FA: {e}",
            reply_markup=kb.kb(kb.back("sessions")),
        )
        await _cleanup_auth(uid)
        await state.clear()


async def _finalize_session(uid: int, client: Client, me, message: types.Message, state: FSMContext):
    """Сохраняем сессию и перемещаем файл."""
    phone = _temp.get(uid, {}).get("phone", "")
    
    # 1. СНАЧАЛА ОБЯЗАТЕЛЬНО ОТКЛЮЧАЕМ КЛИЕНТ
    try:
        await client.disconnect()
    except Exception:
        pass
    _auth_clients.pop(uid, None)

    # 2. Создаём запись в БД и получаем ID сессии (у тебя это будет 1)
    sess_id = db.add_session(uid, f"Аккаунт {me.first_name}", phone, me.id, me.username)

    # 3. ТЕПЕРЬ ПЕРЕМЕЩАЕМ ФАЙЛ
    src = os.path.join(SESSIONS_DIR, f"tmp_{uid}.session")
    dst = os.path.join(SESSIONS_DIR, f"{sess_id}.session")
    
    # Даем Windows 300мс, чтобы полностью освободить дескриптор файла
    await asyncio.sleep(0.3)
    
    try:
        if os.path.exists(src):
            os.rename(src, dst)
            logger.info(f"Файл успешно переименован в {sess_id}.session")
        else:
            logger.error(f"Временный файл не найден: {src}")
    except Exception as ex:
        logger.error(f"Не удалось переименовать файл сессии: {ex}")
        await message.answer("❌ Ошибка файловой системы при сохранении сессии.")
        return

    _temp.pop(uid, None)
    _temp[uid] = {"sess_id": sess_id}
    await state.set_state(States.sess_name)
    await message.answer(
        f"✅ Сессия создана!\n👤 Аккаунт: <b>{me.first_name}</b>\n\n"
        f"Введите кастомное имя для сессии (или отправьте <code>-</code> для имени по умолчанию):",
        parse_mode="HTML",
        reply_markup=kb.kb(kb.back("sessions")),
    )


async def _cleanup_auth(uid: int):
    client = _auth_clients.pop(uid, None)
    if client:
        try:
            await client.disconnect()
        except Exception:
            pass
    _temp.pop(uid, None)
    # Remove temp session file
    tmp = os.path.join(SESSIONS_DIR, f"tmp_{uid}.session")
    try:
        if os.path.exists(tmp):
            os.remove(tmp)
    except Exception:
        pass


async def state_sess_name(message: types.Message, state: FSMContext):
    uid = message.from_user.id
    name = message.text.strip()
    sess_id = _temp.get(uid, {}).get("sess_id")
    if sess_id and name != "-":
        db.rename_session(sess_id, name)
    await state.clear()
    _temp.pop(uid, None)
    await message.answer("✅ Сессия сохранена!", reply_markup=kb.sessions_kb(uid), parse_mode="HTML")


async def state_sess_rename(message: types.Message, state: FSMContext):
    uid = message.from_user.id
    sess_id = _temp.get(uid, {}).get("sess_id")
    if sess_id:
        db.rename_session(sess_id, message.text.strip())
    await state.clear()
    await message.answer("✅ Имя изменено!", reply_markup=kb.sessions_kb(uid), parse_mode="HTML")


async def cb_sess_proxy(cb: types.CallbackQuery, state: FSMContext):
    sess_id = int(cb.data.split(":")[1])
    _temp[cb.from_user.id] = {"sess_id": sess_id}
    await state.set_state(States.sess_proxy)
    await safe_edit(
        cb.message,
        "🌐 <b>Настройка прокси</b>\n\n"
        "Отправьте данные в формате:\n"
        "<code>схема хост порт логин пароль</code>\n\n"
        "Пример:\n<code>socks5 1.2.3.4 1080 user pass</code>\n\n"
        "Чтобы удалить прокси — отправьте <code>удалить</code>",
        reply_markup=kb.kb(kb.back(f"sess_open:{sess_id}")),
    )
    await cb.answer()


async def state_sess_proxy(message: types.Message, state: FSMContext):
    uid = message.from_user.id
    sess_id = _temp.get(uid, {}).get("sess_id")
    text = message.text.strip()
    if text.lower() == "удалить":
        db.set_session_proxy(sess_id, None, None, None, None)
        await message.answer("✅ Прокси удалён", reply_markup=kb.sessions_kb(uid), parse_mode="HTML")
    else:
        parts = text.split()
        if len(parts) < 3:
            await message.answer("❌ Неверный формат. Попробуйте ещё раз.")
            return
        scheme = parts[0]
        host = parts[1]
        port = int(parts[2])
        login = parts[3] if len(parts) > 3 else ""
        password = parts[4] if len(parts) > 4 else ""
        db.set_session_proxy(sess_id, host, port, login, password, scheme)
        await message.answer("✅ Прокси сохранён!", reply_markup=kb.sessions_kb(uid), parse_mode="HTML")
    await state.clear()


async def cb_sess_delete(cb: types.CallbackQuery):
    sess_id = int(cb.data.split(":")[1])
    db.delete_session(sess_id)
    # Try to remove session file
    f = os.path.join(SESSIONS_DIR, f"{sess_id}.session")
    try:
        if os.path.exists(f):
            os.remove(f)
    except Exception:
        pass
    uid = cb.from_user.id
    await safe_edit(cb.message, "🗑 Сессия удалена.", reply_markup=kb.sessions_kb(uid))
    await cb.answer()


# ─── TEMPLATES ────────────────────────────────────────────────────────────────

async def cb_templates(cb: types.CallbackQuery, state: FSMContext):
    await state.clear()
    uid = cb.from_user.id
    if not db.has_subscription(uid) and not db.is_admin(uid):
        await cb.answer("❌ Требуется подписка", show_alert=True)
        return
    await safe_edit(cb.message, "📋 <b>Управление шаблонами</b>", reply_markup=kb.templates_kb(uid))
    await cb.answer()


async def cb_tpl_create(cb: types.CallbackQuery):
    await safe_edit(cb.message, "📋 <b>Создание шаблона</b>\n\nВыберите тип сервиса:", reply_markup=kb.tpl_service_kb())
    await cb.answer()


async def cb_tpl_svc(cb: types.CallbackQuery, state: FSMContext):
    service = cb.data.split(":")[1]
    _temp[cb.from_user.id] = {"tpl_service": service}
    await state.set_state(States.tpl_name)
    svc_name = kb.SERVICE_NAMES.get(service, service)
    await safe_edit(cb.message, f"✏️ Введите название шаблона для сервиса <b>{svc_name}</b>:",
                    reply_markup=kb.kb(kb.back("templates")))
    await cb.answer()


async def state_tpl_name(message: types.Message, state: FSMContext):
    uid = message.from_user.id
    service = _temp.get(uid, {}).get("tpl_service", "broadcast")
    default_data = _default_tpl_data(service)
    tpl_id = db.create_template(uid, message.text.strip(), service, default_data)
    _temp.pop(uid, None)
    await state.clear()
    tpl = db.get_template(tpl_id)
    svc = kb.SERVICE_NAMES.get(tpl["service"], tpl["service"])
    await message.answer(f"✅ Шаблон создан!\n\n📋 <b>{tpl['name']}</b> | {svc}",
                         reply_markup=kb.tpl_menu_kb(tpl_id, service, tpl["data"]), parse_mode="HTML")


def _default_tpl_data(service: str) -> dict:
    if service == "broadcast":
        return {
            "texts": [], "msg_mode": "random", "alt_case": False,
            "parts_symbols": False,
            "chats": [], "random_chats": False,
            "autosub_enabled": False, "autosub_actions": {"subscribe": True, "join": True, "start_bots": True}, "autosub_delay": 3,
            "delay_msg_min": 3, "delay_msg_max": 7,
            "delay_cycle_min": 60, "delay_cycle_max": 120,
            "chunk_mode": False, "chunk_size": 20,
            "chunk_delay_min": 180, "chunk_delay_max": 300,
            "typing_mode": False, "typing_min": 3, "typing_max": 7,
        }
    elif service == "autoresponder":
        return {
            "ar_who": "all", "ar_reply_text": "", "ar_reply_media": None,
            "ar_cooldown": 8,
            "typing_mode": False, "typing_min": 3, "typing_max": 7,
        }
    elif service == "triggerbot":
        return {
            "tb_where": "all", "tb_chats": [], "triggers": [],
            "typing_mode": False, "typing_min": 3, "typing_max": 7,
        }
    elif service == "autochecker":
        return {
            "ac_source": "send", "ac_where": "all", "ac_chats": [],
            "ac_daily_limit": None, "ac_attempts": 1,
        }
    return {}


async def cb_tpl_open(cb: types.CallbackQuery):
    tpl_id = int(cb.data.split(":")[1])
    tpl = db.get_template(tpl_id)
    if not tpl:
        await cb.answer("Шаблон не найден", show_alert=True)
        return
    svc = kb.SERVICE_NAMES.get(tpl["service"], tpl["service"])
    await safe_edit(cb.message, f"📋 <b>Шаблон: {tpl['name']}</b>\n🔧 Сервис: {svc}",
                    reply_markup=kb.tpl_menu_kb(tpl_id, tpl["service"], tpl["data"]))
    await cb.answer()


async def cb_tpl_rename(cb: types.CallbackQuery, state: FSMContext):
    tpl_id = int(cb.data.split(":")[1])
    _temp[cb.from_user.id] = {"tpl_id": tpl_id, "flow": "rename"}
    await state.set_state(States.tpl_name)
    await safe_edit(cb.message, "✏️ Введите новое имя шаблона:", reply_markup=kb.kb(kb.back(f"tpl_open:{tpl_id}")))
    await cb.answer()


async def cb_tpl_delete(cb: types.CallbackQuery):
    tpl_id = int(cb.data.split(":")[1])
    uid = cb.from_user.id
    try:
        # Останавливаем процессы пользователя, которые используют шаблон.
        for proc in db.get_processes(uid):
            if tpl_id in proc.get("template_ids", []):
                await broadcaster.stop_process(proc["id"])
        db.delete_template(tpl_id)
        await safe_edit(cb.message, "🗑 Шаблон удалён.", reply_markup=kb.templates_kb(uid))
        await cb.answer("✅ Удалено")
    except Exception as ex:
        logger.exception("Ошибка удаления шаблона %s", tpl_id)
        await cb.answer(f"❌ Не удалось удалить: {ex}", show_alert=True)


# ─── TEMPLATE: BROADCAST TEXTS ────────────────────────────────────────────────

async def cb_tpl_texts(cb: types.CallbackQuery):
    tpl_id = int(cb.data.split(":")[1])
    tpl = db.get_template(tpl_id)
    if not tpl:
        await cb.answer("Не найдено", show_alert=True)
        return
    data = tpl["data"]
    texts = data.get("texts", [])
    preview = "\n".join(f"{i+1}. {t[:40]}{'…' if len(t) > 40 else ''}" for i, t in enumerate(texts[:10]))
    if len(texts) > 10:
        preview += f"\n…и ещё {len(texts)-10}"
    mode_names = {"random": "Случайный", "parts": "Из частей", "sequence": "По порядку"}
    mode = data.get("msg_mode", "random")
    text = (
        f"💬 <b>Тексты шаблона</b>\n"
        f"Режим: <b>{mode_names.get(mode, mode)}</b>\n"
        f"Всего: {len(texts)}\n\n"
        f"{preview or 'Пусто'}"
    )
    await safe_edit(cb.message, text, reply_markup=kb.tpl_texts_kb(tpl_id, data))
    await cb.answer()


async def cb_tpl_texts_mode(cb: types.CallbackQuery):
    tpl_id = int(cb.data.split(":")[1])
    tpl = db.get_template(tpl_id)
    data = tpl["data"]
    modes = ["random", "parts", "sequence"]
    cur = data.get("msg_mode", "random")
    data["msg_mode"] = modes[(modes.index(cur) + 1) % len(modes)]
    db.update_template_data(tpl_id, data)
    await cb_tpl_texts(cb)


async def cb_tpl_texts_alt(cb: types.CallbackQuery):
    tpl_id = int(cb.data.split(":")[1])
    tpl = db.get_template(tpl_id)
    data = tpl["data"]
    data["alt_case"] = not data.get("alt_case", False)
    db.update_template_data(tpl_id, data)
    await cb_tpl_texts(cb)


async def cb_tpl_texts_symbols(cb: types.CallbackQuery):
    tpl_id = int(cb.data.split(":")[1])
    tpl = db.get_template(tpl_id)
    if not tpl:
        await cb.answer("Шаблон не найден", show_alert=True)
        return
    data = tpl["data"]
    data["parts_symbols"] = not data.get("parts_symbols", False)
    db.update_template_data(tpl_id, data)
    await cb_tpl_texts(cb)


async def cb_tpl_texts_add(cb: types.CallbackQuery, state: FSMContext):
    tpl_id = int(cb.data.split(":")[1])
    _temp[cb.from_user.id] = {"tpl_id": tpl_id}
    await state.set_state(States.tpl_texts_add)
    label = "часть" if db.get_template(tpl_id)["data"].get("msg_mode") == "parts" else "текст"
    await safe_edit(cb.message, f"✏️ Отправьте {label} для добавления:", reply_markup=kb.kb(kb.back(f"tpl_texts:{tpl_id}")))
    await cb.answer()


async def state_tpl_texts_add(message: types.Message, state: FSMContext):
    uid = message.from_user.id
    tpl_id = _temp.get(uid, {}).get("tpl_id")
    tpl = db.get_template(tpl_id)
    data = tpl["data"]
    data.setdefault("texts", []).append(message.text.strip())
    db.update_template_data(tpl_id, data)
    await state.clear()
    label = "Часть" if data.get("msg_mode") == "parts" else "Текст"
    await message.answer(f"✅ {label} добавлен!", parse_mode="HTML")
    tpl2 = db.get_template(tpl_id)
    texts = tpl2["data"].get("texts", [])
    preview = "\n".join(f"{i+1}. {t[:40]}" for i, t in enumerate(texts[:10]))
    await message.answer(f"💬 <b>Тексты ({len(texts)})</b>\n\n{preview or 'Пусто'}",
                         reply_markup=kb.tpl_texts_kb(tpl_id, tpl2["data"]), parse_mode="HTML")


async def cb_tpl_texts_del(cb: types.CallbackQuery, state: FSMContext):
    tpl_id = int(cb.data.split(":")[1])
    _temp[cb.from_user.id] = {"tpl_id": tpl_id}
    await state.set_state(States.tpl_texts_del)
    await safe_edit(cb.message, "🗑 Введите номер текста для удаления:", reply_markup=kb.kb(kb.back(f"tpl_texts:{tpl_id}")))
    await cb.answer()


async def state_tpl_texts_del(message: types.Message, state: FSMContext):
    uid = message.from_user.id
    tpl_id = _temp.get(uid, {}).get("tpl_id")
    tpl = db.get_template(tpl_id)
    data = tpl["data"]
    try:
        idx = int(message.text.strip()) - 1
        data["texts"].pop(idx)
        db.update_template_data(tpl_id, data)
        await message.answer("✅ Текст удалён!", reply_markup=kb.kb(kb.back(f"tpl_texts:{tpl_id}")))
    except Exception:
        await message.answer("❌ Неверный номер", reply_markup=kb.kb(kb.back(f"tpl_texts:{tpl_id}")))
    await state.clear()


async def cb_tpl_texts_clear(cb: types.CallbackQuery):
    tpl_id = int(cb.data.split(":")[1])
    tpl = db.get_template(tpl_id)
    data = tpl["data"]
    data["texts"] = []
    db.update_template_data(tpl_id, data)
    await cb_tpl_texts(cb)


# ─── TEMPLATE: BROADCAST CHATS ────────────────────────────────────────────────

async def cb_tpl_chats(cb: types.CallbackQuery):
    tpl_id = int(cb.data.split(":")[1])
    tpl = db.get_template(tpl_id)
    data = tpl["data"]
    chats = data.get("chats", [])
    preview = "\n".join(f"{i+1}. {c}" for i, c in enumerate(chats[:15]))
    if len(chats) > 15:
        preview += f"\n…и ещё {len(chats)-15}"
    folder_note = f"\n📁 Папка: <b>{data.get('folder_name')}</b> (аккаунт {data.get('folder_session_id')})" if data.get("folder_id") else ""
    text = f"👥 <b>Чаты</b>\nВсего: {len(chats)}{folder_note}\n\n{preview or 'Пусто'}"
    await safe_edit(cb.message, text, reply_markup=kb.tpl_chats_kb(tpl_id, data))
    await cb.answer()


async def cb_tpl_chats_folder(cb: types.CallbackQuery):
    tpl_id = int(cb.data.split(":")[1])
    sessions = db.get_sessions(cb.from_user.id)
    if not sessions:
        await safe_edit(
            cb.message,
            "📁 <b>Выберите аккаунт для выбора папки</b>\n\n"
            "У вас еще не добавлены аккаунты",
            reply_markup=kb.kb(
                [kb.btn("➕ Добавить аккаунт", "sessions")],
                kb.back(f"tpl_chats:{tpl_id}"),
            ),
        )
        await cb.answer()
        return
    await safe_edit(
        cb.message,
        "📁 <b>Выберите аккаунт для загрузки папок</b>",
        reply_markup=kb.tpl_folder_sessions_kb(tpl_id, sessions),
    )
    await cb.answer()


async def cb_tpl_folder_session(cb: types.CallbackQuery):
    parts = cb.data.split(":")
    tpl_id, session_id = int(parts[1]), int(parts[2])
    try:
        folders = await broadcaster.get_session_folders(session_id)
    except Exception as ex:
        logger.exception("Ошибка получения папок")
        await cb.answer(f"❌ Не удалось получить папки: {ex}", show_alert=True)
        return
    if not folders:
        await safe_edit(cb.message, "📁 У этого аккаунта нет доступных папок.", reply_markup=kb.kb(kb.back(f"tpl_chats_folder:{tpl_id}")))
        await cb.answer()
        return
    session = db.get_session(session_id)
    await safe_edit(
        cb.message,
        f"📱 Аккаунт: <b>{session['name']}</b>\n\nВыберите папку:\n\n"
        "⚠️ Если выбрать папку, шаблон можно будет запускать только на этом аккаунте.",
        reply_markup=kb.tpl_folders_kb(tpl_id, session_id, folders),
    )
    await cb.answer()


async def cb_tpl_folder_set(cb: types.CallbackQuery):
    parts = cb.data.split(":")
    tpl_id, session_id, folder_id = int(parts[1]), int(parts[2]), int(parts[3])
    # title is fetched again to keep callback data short
    folders = await broadcaster.get_session_folders(session_id)
    folder = next((x for x in folders if x["id"] == folder_id), None)
    if not folder:
        await cb.answer("Папка не найдена", show_alert=True)
        return
    tpl = db.get_template(tpl_id)
    data = tpl["data"]
    data["folder_session_id"] = session_id
    data["folder_id"] = folder_id
    data["folder_name"] = folder["name"]
    data["chats"] = []
    db.update_template_data(tpl_id, data)
    await cb_tpl_chats(cb)


async def cb_tpl_folder_clear(cb: types.CallbackQuery):
    tpl_id = int(cb.data.split(":")[1])
    tpl = db.get_template(tpl_id)
    data = tpl["data"]
    for key in ("folder_session_id", "folder_id", "folder_name"):
        data.pop(key, None)
    db.update_template_data(tpl_id, data)
    await cb_tpl_chats(cb)


async def cb_tpl_chats_rand(cb: types.CallbackQuery):
    tpl_id = int(cb.data.split(":")[1])
    tpl = db.get_template(tpl_id)
    data = tpl["data"]
    data["random_chats"] = not data.get("random_chats", False)
    db.update_template_data(tpl_id, data)
    await cb_tpl_chats(cb)


async def cb_tpl_chats_add(cb: types.CallbackQuery, state: FSMContext):
    tpl_id = int(cb.data.split(":")[1])
    _temp[cb.from_user.id] = {"tpl_id": tpl_id}
    await state.set_state(States.tpl_chats_add)
    await safe_edit(cb.message,
                    "➕ Отправьте список чатов (по одному или несколько через Enter/пробел).\n"
                    "Поддерживаются: @username, t.me/link, ID (числовой):",
                    reply_markup=kb.kb(kb.back(f"tpl_chats:{tpl_id}")))
    await cb.answer()


async def state_tpl_chats_add(message: types.Message, state: FSMContext):
    uid = message.from_user.id
    tpl_id = _temp.get(uid, {}).get("tpl_id")
    tpl = db.get_template(tpl_id)
    data = tpl["data"]
    raw = message.text.strip().replace("\n", " ").split()
    added = 0
    for c in raw:
        c = c.strip().rstrip(",")
        if not c:
            continue
        if "t.me/" in c:
            c = c.split("t.me/")[-1].split("/")[0]
        if c.startswith("@"):
            c = c[1:]
        try:
            int(c)
            chat = c
        except ValueError:
            chat = f"@{c}"
        if chat not in data.setdefault("chats", []):
            data["chats"].append(chat)
            added += 1
    db.update_template_data(tpl_id, data)
    await state.clear()
    await message.answer(f"✅ Добавлено чатов: {added}", parse_mode="HTML")
    tpl2 = db.get_template(tpl_id)
    chats2 = tpl2["data"].get("chats", [])
    preview = "\n".join(f"{i+1}. {c}" for i, c in enumerate(chats2[:15]))
    await message.answer(f"👥 <b>Чаты ({len(chats2)})</b>\n\n{preview or 'Пусто'}",
                         reply_markup=kb.tpl_chats_kb(tpl_id, tpl2["data"]), parse_mode="HTML")


async def cb_tpl_chats_del(cb: types.CallbackQuery, state: FSMContext):
    tpl_id = int(cb.data.split(":")[1])
    _temp[cb.from_user.id] = {"tpl_id": tpl_id}
    await state.set_state(States.tpl_chats_del)
    await safe_edit(cb.message, "🗑 Введите номер чата для удаления (можно несколько через пробел):",
                    reply_markup=kb.kb(kb.back(f"tpl_chats:{tpl_id}")))
    await cb.answer()


async def state_tpl_chats_del(message: types.Message, state: FSMContext):
    uid = message.from_user.id
    tpl_id = _temp.get(uid, {}).get("tpl_id")
    tpl = db.get_template(tpl_id)
    data = tpl["data"]
    try:
        indices = {int(n) - 1 for n in message.text.split() if n.isdigit()}
        data["chats"] = [c for i, c in enumerate(data.get("chats", [])) if i not in indices]
        db.update_template_data(tpl_id, data)
        await message.answer("✅ Чаты удалены!", reply_markup=kb.kb(kb.back(f"tpl_chats:{tpl_id}")))
    except Exception:
        await message.answer("❌ Ошибка", reply_markup=kb.kb(kb.back(f"tpl_chats:{tpl_id}")))
    await state.clear()


async def cb_tpl_chats_clear(cb: types.CallbackQuery):
    tpl_id = int(cb.data.split(":")[1])
    tpl = db.get_template(tpl_id)
    data = tpl["data"]
    data["chats"] = []
    db.update_template_data(tpl_id, data)
    await cb_tpl_chats(cb)


# ─── TEMPLATE: TIMINGS ────────────────────────────────────────────────────────

async def cb_tpl_timings(cb: types.CallbackQuery):
    tpl_id = int(cb.data.split(":")[1])
    tpl = db.get_template(tpl_id)
    data = tpl["data"]
    d_msg = f"{data.get('delay_msg_min',3)}-{data.get('delay_msg_max',7)}с"
    d_cycle = f"{data.get('delay_cycle_min',60)}-{data.get('delay_cycle_max',120)}с"
    text = (
        f"⏱ <b>Тайминги</b>\n\n"
        f"✉️ Задержка между сообщениями: <b>{d_msg}</b>\n"
        f"🔄 Задержка между циклами: <b>{d_cycle}</b>"
    )
    await safe_edit(cb.message, text, reply_markup=kb.tpl_timings_kb(tpl_id))
    await cb.answer()


async def cb_tpl_set_delay_msg(cb: types.CallbackQuery, state: FSMContext):
    tpl_id = int(cb.data.split(":")[1])
    _temp[cb.from_user.id] = {"tpl_id": tpl_id}
    await state.set_state(States.tpl_set_delay_msg)
    await safe_edit(cb.message, "Введите задержку между сообщениями в секундах.\nПример: <code>3-7</code> или <code>5</code>",
                    reply_markup=kb.kb(kb.back(f"tpl_timings:{tpl_id}")))
    await cb.answer()


async def state_tpl_set_delay_msg(message: types.Message, state: FSMContext):
    uid = message.from_user.id
    tpl_id = _temp.get(uid, {}).get("tpl_id")
    mn, mx = parse_interval(message.text)
    if mn is None:
        await message.answer("❌ Неверный формат", reply_markup=kb.kb(kb.back(f"tpl_timings:{tpl_id}")))
        return
    tpl = db.get_template(tpl_id)
    data = tpl["data"]
    data["delay_msg_min"] = mn
    data["delay_msg_max"] = mx
    db.update_template_data(tpl_id, data)
    await state.clear()
    await message.answer("✅ Сохранено!", reply_markup=kb.kb(kb.back(f"tpl_timings:{tpl_id}")))


async def cb_tpl_set_delay_cycle(cb: types.CallbackQuery, state: FSMContext):
    tpl_id = int(cb.data.split(":")[1])
    _temp[cb.from_user.id] = {"tpl_id": tpl_id}
    await state.set_state(States.tpl_set_delay_cycle)
    await safe_edit(cb.message, "Введите задержку между циклами в секундах.\nПример: <code>60-120</code> или <code>90</code>",
                    reply_markup=kb.kb(kb.back(f"tpl_timings:{tpl_id}")))
    await cb.answer()


async def state_tpl_set_delay_cycle(message: types.Message, state: FSMContext):
    uid = message.from_user.id
    tpl_id = _temp.get(uid, {}).get("tpl_id")
    mn, mx = parse_interval(message.text)
    if mn is None:
        await message.answer("❌ Неверный формат", reply_markup=kb.kb(kb.back(f"tpl_timings:{tpl_id}")))
        return
    tpl = db.get_template(tpl_id)
    data = tpl["data"]
    data["delay_cycle_min"] = mn
    data["delay_cycle_max"] = mx
    db.update_template_data(tpl_id, data)
    await state.clear()
    await message.answer("✅ Сохранено!", reply_markup=kb.kb(kb.back(f"tpl_timings:{tpl_id}")))


# ─── TEMPLATE: CHUNKS ─────────────────────────────────────────────────────────

async def cb_tpl_chunks(cb: types.CallbackQuery):
    tpl_id = int(cb.data.split(":")[1])
    tpl = db.get_template(tpl_id)
    data = tpl["data"]
    on = "✅" if data.get("chunk_mode") else "❌"
    text = (
        f"📦 <b>Режим пачек</b>\n\n"
        f"Статус: {on}\n"
        f"Размер пачки: {data.get('chunk_size', 20)} сообщений\n"
        f"Пауза после пачки: {data.get('chunk_delay_min',180)}-{data.get('chunk_delay_max',300)}с"
    )
    await safe_edit(cb.message, text, reply_markup=kb.tpl_chunks_kb(tpl_id, data))
    await cb.answer()


async def cb_tpl_chunks_toggle(cb: types.CallbackQuery):
    tpl_id = int(cb.data.split(":")[1])
    tpl = db.get_template(tpl_id)
    data = tpl["data"]
    data["chunk_mode"] = not data.get("chunk_mode", False)
    db.update_template_data(tpl_id, data)
    await cb_tpl_chunks(cb)


async def cb_tpl_set_chunk(cb: types.CallbackQuery, state: FSMContext):
    tpl_id = int(cb.data.split(":")[1])
    _temp[cb.from_user.id] = {"tpl_id": tpl_id}
    await state.set_state(States.tpl_set_chunk)
    await safe_edit(cb.message,
                    "Введите настройки пачек в формате:\n"
                    "<code>размер задержка_мин-задержка_макс</code>\n\n"
                    "Пример: <code>20 180-300</code>",
                    reply_markup=kb.kb(kb.back(f"tpl_chunks:{tpl_id}")))
    await cb.answer()


async def state_tpl_set_chunk(message: types.Message, state: FSMContext):
    uid = message.from_user.id
    tpl_id = _temp.get(uid, {}).get("tpl_id")
    parts = message.text.strip().split()
    try:
        size = int(parts[0])
        mn, mx = parse_interval(parts[1]) if len(parts) > 1 else (180, 300)
        tpl = db.get_template(tpl_id)
        data = tpl["data"]
        data["chunk_size"] = size
        data["chunk_delay_min"] = mn
        data["chunk_delay_max"] = mx
        db.update_template_data(tpl_id, data)
        await state.clear()
        await message.answer("✅ Сохранено!", reply_markup=kb.kb(kb.back(f"tpl_chunks:{tpl_id}")))
    except Exception:
        await message.answer("❌ Неверный формат", reply_markup=kb.kb(kb.back(f"tpl_chunks:{tpl_id}")))


# ─── TEMPLATE: TYPING ─────────────────────────────────────────────────────────

async def cb_tpl_typing(cb: types.CallbackQuery):
    tpl_id = int(cb.data.split(":")[1])
    tpl = db.get_template(tpl_id)
    data = tpl["data"]
    on = "✅" if data.get("typing_mode") else "❌"
    text = (
        f"⌨️ <b>Режим «Печатает»</b>\n\n"
        f"Статус: {on}\n"
        f"Время набора: {data.get('typing_min',3)}-{data.get('typing_max',7)}с"
    )
    await safe_edit(cb.message, text, reply_markup=kb.tpl_typing_kb(tpl_id, data))
    await cb.answer()


async def cb_tpl_typing_toggle(cb: types.CallbackQuery):
    tpl_id = int(cb.data.split(":")[1])
    tpl = db.get_template(tpl_id)
    data = tpl["data"]
    data["typing_mode"] = not data.get("typing_mode", False)
    db.update_template_data(tpl_id, data)
    await cb_tpl_typing(cb)


async def cb_tpl_set_typing(cb: types.CallbackQuery, state: FSMContext):
    tpl_id = int(cb.data.split(":")[1])
    _temp[cb.from_user.id] = {"tpl_id": tpl_id}
    await state.set_state(States.tpl_set_typing)
    await safe_edit(cb.message, "Введите время имитации набора в секундах.\nПример: <code>3-7</code>",
                    reply_markup=kb.kb(kb.back(f"tpl_typing:{tpl_id}")))
    await cb.answer()


async def state_tpl_set_typing(message: types.Message, state: FSMContext):
    uid = message.from_user.id
    tpl_id = _temp.get(uid, {}).get("tpl_id")
    mn, mx = parse_interval(message.text)
    if mn is None:
        await message.answer("❌ Неверный формат", reply_markup=kb.kb(kb.back(f"tpl_typing:{tpl_id}")))
        return
    tpl = db.get_template(tpl_id)
    data = tpl["data"]
    data["typing_min"] = mn
    data["typing_max"] = mx
    db.update_template_data(tpl_id, data)
    await state.clear()
    await message.answer("✅ Сохранено!", reply_markup=kb.kb(kb.back(f"tpl_typing:{tpl_id}")))


# ─── TEMPLATE: AUTOSUB ─────────────────────────────────────────────────────────

async def cb_tpl_autosub(cb: types.CallbackQuery):
    tpl_id = int(cb.data.split(":")[1])
    tpl = db.get_template(tpl_id)
    await safe_edit(cb.message, "🛠 <b>Автосаб</b>\n\nНастройки Автосаба не используют Анти-Заморозку и Авто-Замедление процесса.", reply_markup=kb.tpl_autosub_kb(tpl_id, tpl["data"]))
    await cb.answer()


async def cb_tpl_autosub_toggle(cb: types.CallbackQuery):
    tpl_id = int(cb.data.split(":")[1])
    tpl = db.get_template(tpl_id); data = tpl["data"]
    data["autosub_enabled"] = not data.get("autosub_enabled", False)
    db.update_template_data(tpl_id, data)
    await cb_tpl_autosub(cb)


async def cb_tpl_autosub_action(cb: types.CallbackQuery):
    parts = cb.data.split(":"); tpl_id, action = int(parts[1]), parts[2]
    tpl = db.get_template(tpl_id); data = tpl["data"]
    actions = data.setdefault("autosub_actions", {"subscribe": True, "join": True, "start_bots": True})
    actions[action] = not actions.get(action, True)
    db.update_template_data(tpl_id, data)
    await cb_tpl_autosub(cb)


async def cb_tpl_autosub_delay(cb: types.CallbackQuery, state: FSMContext):
    tpl_id = int(cb.data.split(":")[1])
    _temp[cb.from_user.id] = {"tpl_id": tpl_id}
    await state.set_state(States.tpl_autosub_delay)
    await safe_edit(cb.message, "Введите задержку между действиями Автосаба в секундах:", reply_markup=kb.kb(kb.back(f"tpl_autosub:{tpl_id}")))
    await cb.answer()


async def state_tpl_autosub_delay(message: types.Message, state: FSMContext):
    uid = message.from_user.id; tpl_id = _temp.get(uid, {}).get("tpl_id")
    try:
        value = int((message.text or "").strip())
        if value < 0: raise ValueError
        tpl = db.get_template(tpl_id); data = tpl["data"]; data["autosub_delay"] = value
        db.update_template_data(tpl_id, data); _temp.pop(uid, None); await state.clear()
        await message.answer("✅ Задержка сохранена", reply_markup=kb.kb(kb.back(f"tpl_autosub:{tpl_id}")))
    except Exception:
        await message.answer("❌ Введите число от 0")


# ─── TEMPLATE: REPEATS ─────────────────────────────────────────────────────────

async def cb_tpl_repeats(cb: types.CallbackQuery):
    tpl_id = int(cb.data.split(":")[1])
    tpl = db.get_template(tpl_id)
    if not tpl:
        await cb.answer("Шаблон не найден", show_alert=True)
        return
    data = tpl["data"]
    current = data.get("repeat_cycles")
    label = "Безлимит" if not current else str(current)
    await safe_edit(
        cb.message,
        f"🔁 <b>Повторы рассылки</b>\n\nТекущее значение: <b>{label}</b>",
        reply_markup=kb.tpl_repeats_kb(tpl_id, data),
    )
    await cb.answer()


async def cb_tpl_repeats_toggle(cb: types.CallbackQuery):
    tpl_id = int(cb.data.split(":")[1])
    tpl = db.get_template(tpl_id)
    data = tpl["data"]
    data["repeat_cycles"] = None
    db.update_template_data(tpl_id, data)
    await cb_tpl_repeats(cb)


async def cb_tpl_repeats_set(cb: types.CallbackQuery, state: FSMContext):
    tpl_id = int(cb.data.split(":")[1])
    _temp[cb.from_user.id] = {"tpl_id": tpl_id}
    await state.set_state(States.tpl_repeats)
    await safe_edit(
        cb.message,
        "🔢 Введите количество циклов от 1 и выше:",
        reply_markup=kb.kb(kb.back(f"tpl_repeats:{tpl_id}")),
    )
    await cb.answer()


async def state_tpl_repeats(message: types.Message, state: FSMContext):
    uid = message.from_user.id
    tpl_id = _temp.get(uid, {}).get("tpl_id")
    try:
        value = int((message.text or "").strip())
        if value < 1:
            raise ValueError
        tpl = db.get_template(tpl_id)
        data = tpl["data"]
        data["repeat_cycles"] = value
        db.update_template_data(tpl_id, data)
        _temp.pop(uid, None)
        await state.clear()
        await message.answer(
            f"✅ Повторы установлены: {value}",
            reply_markup=kb.kb(kb.back(f"tpl_repeats:{tpl_id}")),
        )
    except Exception:
        await message.answer(
            "❌ Введите целое число от 1",
            reply_markup=kb.kb(kb.back(f"tpl_repeats:{tpl_id}")),
        )


# ─── TEMPLATE: AUTOCHECKER ────────────────────────────────────────────────────

async def cb_tpl_autochecker(cb: types.CallbackQuery):
    tpl_id = int(cb.data.split(":")[1])
    tpl = db.get_template(tpl_id)
    if not tpl:
        await cb.answer("Шаблон не найден", show_alert=True)
        return
    data = tpl["data"]
    daily = data.get("ac_daily_limit") or "Безлимит"
    where = {"all": "Везде", "selected": "Выбранные чаты", "except": "Везде кроме"}.get(data.get("ac_where", "all"), "Везде")
    text = (
        "🧾 <b>Авточекер CryptoBot/@send</b>\n\n"
        f"🤖 Источник: @send\n"
        f"📍 Где ловить: {where}\n"
        f"📅 Успешных активаций в сутки: {daily}\n"
        f"🔁 Попыток на один чек: {data.get('ac_attempts', 1)}\n"
        f"📌 Чатов в списке: {len(data.get('ac_chats', []))}"
    )
    await safe_edit(cb.message, text, reply_markup=kb.tpl_menu_kb(tpl_id, tpl["service"], data))
    await cb.answer()


async def cb_tpl_ac_source(cb: types.CallbackQuery):
    tpl_id = int(cb.data.split(":")[1])
    tpl = db.get_template(tpl_id)
    await safe_edit(cb.message, "🤖 <b>Источник чеков</b>\n\nПоддерживается CryptoBot/@send.", reply_markup=kb.ac_source_kb(tpl_id, tpl["data"].get("ac_source", "send")))
    await cb.answer()


async def cb_tpl_ac_source_toggle(cb: types.CallbackQuery):
    tpl_id = int(cb.data.split(":")[1])
    tpl = db.get_template(tpl_id)
    data = tpl["data"]
    data["ac_source"] = "both" if data.get("ac_source", "send") == "send" else "send"
    db.update_template_data(tpl_id, data)
    await cb_tpl_ac_source(cb)


async def cb_tpl_ac_where(cb: types.CallbackQuery):
    tpl_id = int(cb.data.split(":")[1])
    tpl = db.get_template(tpl_id)
    current = tpl["data"].get("ac_where", "all")
    await safe_edit(cb.message, "📍 <b>Где ловить чеки?</b>", reply_markup=kb.ac_where_kb(tpl_id, current))
    await cb.answer()


async def cb_tpl_ac_where_set(cb: types.CallbackQuery, state: FSMContext):
    parts = cb.data.split(":")
    tpl_id = int(parts[1])
    value = parts[2]
    tpl = db.get_template(tpl_id)
    data = tpl["data"]
    data["ac_where"] = value
    if value == "all":
        data["ac_chats"] = []
        db.update_template_data(tpl_id, data)
        await cb_tpl_ac_where(cb)
        return
    if value == "folder":
        db.update_template_data(tpl_id, data)
        sessions = db.get_sessions(cb.from_user.id)
        if not sessions:
            await safe_edit(cb.message, "📁 Выберите аккаунт для выбора папки. Аккаунты ещё не добавлены.", reply_markup=kb.kb([kb.btn("➕ Добавить аккаунт", "sessions")], kb.back(f"tpl_ac_where:{tpl_id}")))
        else:
            await safe_edit(cb.message, "📁 Выберите аккаунт для загрузки папок", reply_markup=kb.ac_folder_sessions_kb(tpl_id, sessions))
        await cb.answer()
        return
    db.update_template_data(tpl_id, data)
    _temp[cb.from_user.id] = {"tpl_id": tpl_id}
    await state.set_state(States.tpl_ac_chats)
    await safe_edit(cb.message, "📍 Отправьте список чатов через пробел или Enter:", reply_markup=kb.kb(kb.back(f"tpl_ac_where:{tpl_id}")))
    await cb.answer()


async def cb_tpl_ac_folder(cb: types.CallbackQuery):
    tpl_id = int(cb.data.split(":")[1])
    sessions = db.get_sessions(cb.from_user.id)
    if not sessions:
        await safe_edit(cb.message, "📁 Аккаунты ещё не добавлены", reply_markup=kb.kb([kb.btn("➕ Добавить аккаунт", "sessions")], kb.back(f"tpl_ac_where:{tpl_id}")))
    else:
        await safe_edit(cb.message, "📁 Выберите аккаунт для загрузки папок", reply_markup=kb.ac_folder_sessions_kb(tpl_id, sessions))
    await cb.answer()


async def cb_tpl_ac_folder_session(cb: types.CallbackQuery):
    parts = cb.data.split(":")
    tpl_id, session_id = int(parts[1]), int(parts[2])
    folders = await broadcaster.get_session_folders(session_id)
    if not folders:
        await safe_edit(cb.message, "📁 У аккаунта нет доступных папок", reply_markup=kb.kb(kb.back(f"tpl_ac_folder:{tpl_id}")))
    else:
        await safe_edit(cb.message, "📁 Выберите папку", reply_markup=kb.ac_folders_kb(tpl_id, session_id, folders))
    await cb.answer()


async def cb_tpl_ac_folder_set(cb: types.CallbackQuery):
    parts = cb.data.split(":")
    tpl_id, session_id, folder_id = int(parts[1]), int(parts[2]), int(parts[3])
    folders = await broadcaster.get_session_folders(session_id)
    folder = next((x for x in folders if x["id"] == folder_id), None)
    if not folder:
        await cb.answer("Папка не найдена", show_alert=True)
        return
    tpl = db.get_template(tpl_id)
    data = tpl["data"]
    data["ac_where"] = "folder"
    data["ac_folder_session_id"] = session_id
    data["ac_folder_id"] = folder_id
    data["ac_folder_name"] = folder["name"]
    db.update_template_data(tpl_id, data)
    await cb_tpl_ac_where(cb)


async def state_tpl_ac_chats(message: types.Message, state: FSMContext):
    uid = message.from_user.id
    tpl_id = _temp.get(uid, {}).get("tpl_id")
    tpl = db.get_template(tpl_id)
    data = tpl["data"]
    chats = []
    for value in (message.text or "").replace("\n", " ").split():
        value = value.strip().rstrip(",")
        if value.startswith("https://t.me/"):
            value = value.split("t.me/", 1)[1].split("/", 1)[0]
        if value.startswith("@"):
            value = value[1:]
        chats.append(value if value.lstrip("-").isdigit() else f"@{value}")
    data["ac_chats"] = list(dict.fromkeys(chats))
    db.update_template_data(tpl_id, data)
    _temp.pop(uid, None)
    await state.clear()
    await message.answer("✅ Список чатов сохранён", reply_markup=kb.kb(kb.back(f"tpl_ac_where:{tpl_id}")))


async def cb_tpl_ac_chats_add(cb: types.CallbackQuery, state: FSMContext):
    tpl_id = int(cb.data.split(":")[1])
    _temp[cb.from_user.id] = {"tpl_id": tpl_id}
    await state.set_state(States.tpl_ac_chats)
    await safe_edit(cb.message, "📍 Отправьте список чатов через пробел или Enter:", reply_markup=kb.kb(kb.back(f"tpl_ac_where:{tpl_id}")))
    await cb.answer()


async def cb_tpl_ac_chats_clear(cb: types.CallbackQuery):
    tpl_id = int(cb.data.split(":")[1])
    tpl = db.get_template(tpl_id)
    data = tpl["data"]
    data["ac_chats"] = []
    db.update_template_data(tpl_id, data)
    await cb_tpl_ac_where(cb)


async def cb_tpl_ac_daily(cb: types.CallbackQuery, state: FSMContext):
    tpl_id = int(cb.data.split(":")[1])
    _temp[cb.from_user.id] = {"tpl_id": tpl_id}
    await state.set_state(States.tpl_ac_daily)
    await safe_edit(cb.message, "📅 Введите лимит успешных активаций в сутки. 0 — безлимит:", reply_markup=kb.kb(kb.back(f"tpl_autochecker:{tpl_id}")))
    await cb.answer()


async def state_tpl_ac_daily(message: types.Message, state: FSMContext):
    uid = message.from_user.id
    tpl_id = _temp.get(uid, {}).get("tpl_id")
    try:
        value = int((message.text or "").strip())
        if value < 0:
            raise ValueError
        tpl = db.get_template(tpl_id)
        data = tpl["data"]
        data["ac_daily_limit"] = None if value == 0 else value
        db.update_template_data(tpl_id, data)
        _temp.pop(uid, None)
        await state.clear()
        await message.answer("✅ Лимит сохранён", reply_markup=kb.kb(kb.back(f"tpl_autochecker:{tpl_id}")))
    except Exception:
        await message.answer("❌ Введите целое число от 0")


async def cb_tpl_ac_attempts(cb: types.CallbackQuery, state: FSMContext):
    tpl_id = int(cb.data.split(":")[1])
    _temp[cb.from_user.id] = {"tpl_id": tpl_id}
    await state.set_state(States.tpl_ac_attempts)
    await safe_edit(cb.message, "🔁 Введите число попыток на один чек (от 1):", reply_markup=kb.kb(kb.back(f"tpl_autochecker:{tpl_id}")))
    await cb.answer()


async def state_tpl_ac_attempts(message: types.Message, state: FSMContext):
    uid = message.from_user.id
    tpl_id = _temp.get(uid, {}).get("tpl_id")
    try:
        value = int((message.text or "").strip())
        if value < 1:
            raise ValueError
        tpl = db.get_template(tpl_id)
        data = tpl["data"]
        data["ac_attempts"] = value
        db.update_template_data(tpl_id, data)
        _temp.pop(uid, None)
        await state.clear()
        await message.answer("✅ Попытки сохранены", reply_markup=kb.kb(kb.back(f"tpl_autochecker:{tpl_id}")))
    except Exception:
        await message.answer("❌ Введите целое число от 1")


# ─── TEMPLATE: AUTORESPONDER ──────────────────────────────────────────────────

async def cb_tpl_ar_who(cb: types.CallbackQuery):
    tpl_id = int(cb.data.split(":")[1])
    tpl = db.get_template(tpl_id)
    current = tpl["data"].get("ar_who", "all")
    await safe_edit(cb.message, "🎯 <b>Кому отвечать?</b>", reply_markup=kb.ar_who_kb(tpl_id, current))
    await cb.answer()


async def cb_tpl_ar_who_set(cb: types.CallbackQuery):
    parts = cb.data.split(":")
    tpl_id = int(parts[1])
    val = parts[2]
    tpl = db.get_template(tpl_id)
    data = tpl["data"]
    data["ar_who"] = val
    db.update_template_data(tpl_id, data)
    await cb_tpl_ar_who(cb)


async def cb_tpl_ar_reply(cb: types.CallbackQuery, state: FSMContext):
    tpl_id = int(cb.data.split(":")[1])
    _temp[cb.from_user.id] = {"tpl_id": tpl_id}
    await state.set_state(States.tpl_ar_reply_wait)
    await safe_edit(cb.message,
                    "✉️ Отправьте сообщение-ответ (текст, фото, гифка, стикер, видео до 30 сек):",
                    reply_markup=kb.kb(kb.back(f"tpl_open:{tpl_id}")))
    await cb.answer()


async def state_tpl_ar_reply(message: types.Message, state: FSMContext):
    uid = message.from_user.id
    tpl_id = _temp.get(uid, {}).get("tpl_id")
    tpl = db.get_template(tpl_id)
    data = tpl["data"]

    # Check media limits
    no_limits = db.get_setting("media_no_limits", False)
    max_photo_mb = db.get_setting("media_max_photo_mb", 10)
    max_gif_mb = db.get_setting("media_max_gif_mb", 20)
    max_video_mb = db.get_setting("media_max_video_mb", 50)
    max_video_sec = db.get_setting("media_max_video_sec", 30)

    if message.text:
        data["ar_reply_text"] = message.text
        data["ar_reply_media"] = None
    elif message.photo:
        photo = message.photo[-1]
        if not no_limits and photo.file_size > max_photo_mb * 1024 * 1024:
            await message.answer(f"❌ Фото слишком большое. Макс: {max_photo_mb} МБ")
            return
        data["ar_reply_media"] = {"type": "photo", "file_id": photo.file_id}
        data["ar_reply_text"] = message.caption or ""
    elif message.animation:
        if not no_limits and message.animation.file_size > max_gif_mb * 1024 * 1024:
            await message.answer(f"❌ Гифка слишком большая. Макс: {max_gif_mb} МБ")
            return
        data["ar_reply_media"] = {"type": "animation", "file_id": message.animation.file_id}
        data["ar_reply_text"] = message.caption or ""
    elif message.sticker:
        data["ar_reply_media"] = {"type": "sticker", "file_id": message.sticker.file_id}
        data["ar_reply_text"] = ""
    elif message.video:
        if not no_limits:
            if message.video.duration > max_video_sec:
                await message.answer(f"❌ Видео слишком длинное. Макс: {max_video_sec}с")
                return
            if message.video.file_size > max_video_mb * 1024 * 1024:
                await message.answer(f"❌ Видео слишком большое. Макс: {max_video_mb} МБ")
                return
        data["ar_reply_media"] = {"type": "video", "file_id": message.video.file_id}
        data["ar_reply_text"] = message.caption or ""
    else:
        await message.answer("❌ Неподдерживаемый тип медиа")
        return

    db.update_template_data(tpl_id, data)
    await state.clear()
    await message.answer(
        "✅ Сообщение ответа сохранено!",
        parse_mode="HTML",
        reply_markup=kb.kb(kb.back(f"tpl_open:{tpl_id}")),
    )


async def cb_tpl_ar_cd(cb: types.CallbackQuery, state: FSMContext):
    tpl_id = int(cb.data.split(":")[1])
    _temp[cb.from_user.id] = {"tpl_id": tpl_id}
    await state.set_state(States.tpl_ar_cd)
    tpl = db.get_template(tpl_id)
    cur = tpl["data"].get("ar_cooldown", 8)
    await safe_edit(cb.message, f"⏳ Текущий КД: {cur}ч\n\nВведите количество часов паузы между ответами одному пользователю:",
                    reply_markup=kb.kb(kb.back(f"tpl_open:{tpl_id}")))
    await cb.answer()


async def state_tpl_ar_cd(message: types.Message, state: FSMContext):
    uid = message.from_user.id
    tpl_id = _temp.get(uid, {}).get("tpl_id")
    try:
        hours = int(message.text.strip())
        tpl = db.get_template(tpl_id)
        data = tpl["data"]
        data["ar_cooldown"] = hours
        db.update_template_data(tpl_id, data)
        await state.clear()
        await message.answer(
            f"✅ КД установлен: {hours}ч",
            reply_markup=kb.kb(kb.back(f"tpl_open:{tpl_id}")),
        )
    except Exception:
        await message.answer("❌ Введите число", reply_markup=kb.kb(kb.back(f"tpl_open:{tpl_id}")))


# ─── TEMPLATE: TRIGGERBOT ─────────────────────────────────────────────────────

async def cb_tpl_tb_where(cb: types.CallbackQuery):
    tpl_id = int(cb.data.split(":")[1])
    tpl = db.get_template(tpl_id)
    current = tpl["data"].get("tb_where", "all")
    await safe_edit(cb.message, "📍 <b>Где отвечать?</b>", reply_markup=kb.tb_where_kb(tpl_id, current))
    await cb.answer()


async def cb_tpl_tb_where_set(cb: types.CallbackQuery):
    parts = cb.data.split(":")
    tpl_id = int(parts[1])
    val = parts[2]
    tpl = db.get_template(tpl_id)
    data = tpl["data"]
    data["tb_where"] = val
    db.update_template_data(tpl_id, data)
    if val == "selected":
        _temp[cb.from_user.id] = {"tpl_id": tpl_id}
        await state_handler_tb_chats(cb)
        return
    await cb_tpl_tb_where(cb)


async def state_handler_tb_chats(cb: types.CallbackQuery):
    """Показываем меню добавления чатов для триггербота."""
    tpl_id = _temp.get(cb.from_user.id, {}).get("tpl_id")
    if not tpl_id:
        return
    tpl = db.get_template(tpl_id)
    data = tpl["data"]
    chats = data.get("tb_chats", [])
    preview = "\n".join(f"{i+1}. {c}" for i, c in enumerate(chats[:10]))
    await safe_edit(
        cb.message,
        f"📍 <b>Выборочные чаты</b>\nВсего: {len(chats)}\n\n{preview or 'Пусто'}\n\n"
        f"Отправьте чаты для добавления или нажмите Назад:",
        reply_markup=kb.kb(
            [kb.btn("➕ Добавить чаты", f"tpl_tb_chats_add:{tpl_id}")],
            kb.back(f"tpl_open:{tpl_id}"),
        ),
    )


async def cb_tpl_tb_chats_add(cb: types.CallbackQuery, state: FSMContext):
    tpl_id = int(cb.data.split(":")[1])
    _temp[cb.from_user.id] = {"tpl_id": tpl_id}
    await state.set_state(States.tpl_tb_chats_add)
    await safe_edit(cb.message, "Введите список чатов/групп (через Enter или пробел):",
                    reply_markup=kb.kb(kb.back(f"tpl_open:{tpl_id}")))
    await cb.answer()


async def state_tpl_tb_chats_add(message: types.Message, state: FSMContext):
    uid = message.from_user.id
    tpl_id = _temp.get(uid, {}).get("tpl_id")
    tpl = db.get_template(tpl_id)
    data = tpl["data"]
    raw = message.text.strip().replace("\n", " ").split()
    for c in raw:
        c = c.strip()
        if c and c not in data.setdefault("tb_chats", []):
            data["tb_chats"].append(c)
    db.update_template_data(tpl_id, data)
    await state.clear()
    await message.answer(
        "✅ Чаты добавлены!",
        reply_markup=kb.kb(kb.back(f"tpl_open:{tpl_id}")),
    )


async def cb_tpl_tb_triggers(cb: types.CallbackQuery):
    tpl_id = int(cb.data.split(":")[1])
    tpl = db.get_template(tpl_id)
    triggers = tpl["data"].get("triggers", [])
    await safe_edit(cb.message, f"🔑 <b>Триггеры ({len(triggers)})</b>",
                    reply_markup=kb.tb_triggers_kb(tpl_id, triggers))
    await cb.answer()


async def cb_tpl_tb_trig_add(cb: types.CallbackQuery, state: FSMContext):
    tpl_id = int(cb.data.split(":")[1])
    _temp[cb.from_user.id] = {"tpl_id": tpl_id}
    await state.set_state(States.tpl_tb_trig_kw)
    await safe_edit(cb.message, "🔑 Введите ключевое слово/фразу, на которое будет реагировать триггер:",
                    reply_markup=kb.kb(kb.back(f"tpl_tb_triggers:{tpl_id}")))
    await cb.answer()


async def state_tpl_tb_trig_kw(message: types.Message, state: FSMContext):
    uid = message.from_user.id
    keywords = [part.strip() for part in (message.text or "").split() if part.strip()]
    if not keywords:
        await message.answer("❌ Укажите хотя бы одно слово")
        return
    _temp[uid]["keywords"] = keywords
    await state.set_state(States.tpl_tb_trig_reply)
    tpl_id = _temp.get(uid, {}).get("tpl_id")
    await message.answer(
        f"🔑 Будет добавлено ключевых слов: {len(keywords)}\n"
        "✉️ Теперь отправьте один общий ответ (текст, фото, гифка, стикер, видео до 30 сек):",
        reply_markup=kb.kb(kb.back(f"tpl_tb_triggers:{tpl_id}")),
    )


async def state_tpl_tb_trig_reply(message: types.Message, state: FSMContext):
    uid = message.from_user.id
    temp = _temp.get(uid, {})
    tpl_id = temp.get("tpl_id")
    kw = temp.get("kw", "")
    keywords = temp.get("keywords") or ([kw] if kw and kw != "edit" else [])

    tpl = db.get_template(tpl_id)
    data = tpl["data"]

    trigger = {"keyword": "", "reply_text": "", "reply_media": None}

    if message.text:
        trigger["reply_text"] = message.text
    elif message.photo:
        trigger["reply_media"] = {"type": "photo", "file_id": message.photo[-1].file_id}
        trigger["reply_text"] = message.caption or ""
    elif message.animation:
        trigger["reply_media"] = {"type": "animation", "file_id": message.animation.file_id}
        trigger["reply_text"] = message.caption or ""
    elif message.sticker:
        trigger["reply_media"] = {"type": "sticker", "file_id": message.sticker.file_id}
    elif message.video:
        trigger["reply_media"] = {"type": "video", "file_id": message.video.file_id}
        trigger["reply_text"] = message.caption or ""
    else:
        await message.answer("❌ Неподдерживаемый тип ответа", reply_markup=kb.kb(kb.back(f"tpl_tb_triggers:{tpl_id}")))
        return

    triggers = data.setdefault("triggers", [])
    trig_idx = temp.get("trig_idx")
    if trig_idx is not None and 0 <= trig_idx < len(triggers):
        trigger["keyword"] = triggers[trig_idx].get("keyword", kw)
        triggers[trig_idx] = trigger
        result_text = f"✅ Ответ триггера «{trigger['keyword']}» изменён!"
    else:
        for keyword in keywords:
            item = dict(trigger)
            item["keyword"] = keyword
            triggers.append(item)
        result_text = f"✅ Создано ключевых слов: {len(keywords)}"

    db.update_template_data(tpl_id, data)
    _temp.pop(uid, None)
    await state.clear()
    await message.answer(
        result_text,
        parse_mode="HTML",
        reply_markup=kb.kb(kb.back(f"tpl_tb_triggers:{tpl_id}")),
    )


async def cb_tpl_tb_trig_open(cb: types.CallbackQuery):
    parts = cb.data.split(":")
    tpl_id = int(parts[1])
    idx = int(parts[2])
    tpl = db.get_template(tpl_id)
    triggers = tpl["data"].get("triggers", [])
    if idx >= len(triggers):
        await cb.answer("Не найдено", show_alert=True)
        return
    t = triggers[idx]
    text = f"🔑 <b>Триггер: {t['keyword']}</b>\n\nОтвет: {t.get('reply_text') or '[медиа]'}"
    await safe_edit(cb.message, text, reply_markup=kb.trigger_menu_kb(tpl_id, idx))
    await cb.answer()


async def cb_tpl_tb_trig_edit(cb: types.CallbackQuery, state: FSMContext):
    parts = cb.data.split(":")
    tpl_id = int(parts[1])
    idx = int(parts[2])
    _temp[cb.from_user.id] = {"tpl_id": tpl_id, "trig_idx": idx, "kw": "edit"}
    await state.set_state(States.tpl_tb_trig_reply)
    await safe_edit(cb.message, "✉️ Отправьте новое ответное сообщение:",
                    reply_markup=kb.kb(kb.back(f"tpl_tb_trig_open:{tpl_id}:{idx}")))
    await cb.answer()


async def cb_tpl_tb_trig_del(cb: types.CallbackQuery):
    parts = cb.data.split(":")
    tpl_id = int(parts[1])
    idx = int(parts[2])
    tpl = db.get_template(tpl_id)
    data = tpl["data"]
    if idx < len(data.get("triggers", [])):
        data["triggers"].pop(idx)
        db.update_template_data(tpl_id, data)
    await cb_tpl_tb_triggers(cb)


# ─── PROCESSES ────────────────────────────────────────────────────────────────

async def cb_processes(cb: types.CallbackQuery, state: FSMContext):
    await state.clear()
    uid = cb.from_user.id
    if not db.has_subscription(uid) and not db.is_admin(uid):
        await cb.answer("❌ Требуется подписка", show_alert=True)
        return
    await safe_edit(cb.message, "⚡ <b>Управление процессами</b>", reply_markup=kb.processes_kb(uid))
    await cb.answer()


async def cb_proc_create(cb: types.CallbackQuery):
    await safe_edit(cb.message, "➕ <b>Создание процесса</b>\n\nВыберите сервис:", reply_markup=kb.proc_service_kb())
    await cb.answer()


async def cb_proc_svc(cb: types.CallbackQuery, state: FSMContext):
    service = cb.data.split(":")[1]
    _temp[cb.from_user.id] = {"proc_service": service}
    await state.set_state(States.proc_name)
    svc_name = kb.SERVICE_NAMES.get(service, service)
    await safe_edit(cb.message, f"✏️ Введите имя процесса для сервиса <b>{svc_name}</b>:",
                    reply_markup=kb.kb(kb.back("processes")))
    await cb.answer()


async def state_proc_name(message: types.Message, state: FSMContext):
    uid = message.from_user.id
    service = _temp.get(uid, {}).get("proc_service", "broadcast")
    proc_id = db.create_process(uid, message.text.strip(), service)
    _temp.pop(uid, None)
    await state.clear()
    proc = db.get_process(proc_id)
    svc = kb.SERVICE_NAMES.get(proc["service"], proc["service"])
    text = (
        f"⚡ <b>Процесс: {proc['name']}</b>\n"
        f"🔧 Сервис: {svc}\n"
        f"📱 Аккаунты: не выбраны\n"
        f"📋 Шаблон: не выбран"
    )
    await message.answer(text, reply_markup=kb.proc_menu_kb(proc_id, False), parse_mode="HTML")


async def cb_proc_open(cb: types.CallbackQuery):
    proc_id = int(cb.data.split(":")[1])
    proc = db.get_process(proc_id)
    if not proc:
        await cb.answer("Процесс не найден", show_alert=True)
        return
    svc = kb.SERVICE_NAMES.get(proc["service"], proc["service"])
    sess_ids = proc["session_ids"]
    sessions = [db.get_session(s) for s in sess_ids if db.get_session(s)]
    sess_names = ", ".join(s["name"] for s in sessions) if sessions else "не выбраны"
    template_ids = proc.get("template_ids", [])
    template_names = []
    for template_id in template_ids:
        tpl = db.get_template(template_id)
        if tpl:
            template_names.append(tpl["name"])
    tpl_name = ", ".join(template_names) if template_names else "не выбран"
    running = broadcaster.is_running(proc_id)
    status = "▶️ Работает" if running else "⏹️ Остановлен"
    text = (
        f"⚡ <b>Процесс: {proc['name']}</b>\n"
        f"🔧 Сервис: {svc}\n"
        f"📊 Статус: {status}\n"
        f"📱 Аккаунты: {sess_names}\n"
        f"📋 Шаблоны: {tpl_name}\n"
        f"⏱ Время работы: {((proc.get('work_settings') or {}).get('duration_text') if (proc.get('work_settings') or {}).get('mode') == 'duration' else ((proc.get('work_settings') or {}).get('cycles', 'Бессрочно') if (proc.get('work_settings') or {}).get('mode') == 'cycles' else 'Бессрочно'))}\n"
        f"🛡 Анти-Заморозка: {'вкл' if (proc.get('flood_settings') or {}).get('enabled', True) else 'выкл'}\n"
        f"🐢 Авто-Замедление: {'вкл' if (proc.get('slowdown_settings') or {}).get('enabled', False) else 'выкл'}\n"
        f"🔔 Логи: {proc.get('log_level', 'errors')}"
    )
    await safe_edit(cb.message, text, reply_markup=kb.proc_menu_kb(proc_id, running))
    await cb.answer()


async def cb_proc_accounts(cb: types.CallbackQuery):
    proc_id = int(cb.data.split(":")[1])
    uid = cb.from_user.id
    proc = db.get_process(proc_id)
    selected = proc["session_ids"] if proc else []
    await safe_edit(cb.message, "📱 <b>Выберите аккаунты</b> (отмечаете галочкой):",
                    reply_markup=kb.proc_accounts_kb(proc_id, uid, selected))
    await cb.answer()


async def cb_proc_acc_toggle(cb: types.CallbackQuery):
    parts = cb.data.split(":")
    proc_id = int(parts[1])
    sess_id = int(parts[2])
    proc = db.get_process(proc_id)
    selected = list(proc["session_ids"])
    if sess_id in selected:
        selected.remove(sess_id)
    else:
        selected.append(sess_id)
    db.update_process(proc_id, session_ids=selected)
    uid = cb.from_user.id
    await safe_edit(cb.message, "📱 <b>Выберите аккаунты</b>:",
                    reply_markup=kb.proc_accounts_kb(proc_id, uid, selected))
    await cb.answer()


async def cb_proc_acc_save(cb: types.CallbackQuery):
    proc_id = int(cb.data.split(":")[1])
    await cb_proc_open(cb)


async def cb_proc_template(cb: types.CallbackQuery):
    proc_id = int(cb.data.split(":")[1])
    uid = cb.from_user.id
    proc = db.get_process(proc_id)
    await safe_edit(
        cb.message,
        "📋 <b>Выберите один или несколько шаблонов</b>:",
        reply_markup=kb.proc_template_kb(proc_id, uid, proc["service"], proc.get("template_ids", [])),
    )
    await cb.answer()


async def cb_proc_tpl_toggle(cb: types.CallbackQuery):
    parts = cb.data.split(":")
    proc_id = int(parts[1])
    tpl_id = int(parts[2])
    proc = db.get_process(proc_id)
    selected = list(proc.get("template_ids", []))
    if tpl_id in selected:
        selected.remove(tpl_id)
    else:
        selected.append(tpl_id)
    db.update_process(proc_id, template_ids=selected)
    await cb_proc_template(cb)


async def cb_proc_tpl_save(cb: types.CallbackQuery):
    await cb_proc_open(cb)


async def cb_proc_work(cb: types.CallbackQuery):
    proc_id = int(cb.data.split(":")[1])
    proc = db.get_process(proc_id)
    data = proc.get("work_settings") or {"mode": "unlimited"}
    text = (
        "⏱ <b>Время работы процесса</b>\n\n"
        "По умолчанию процесс работает бессрочно.\n"
        "Если срок закончится во время цикла, текущий цикл будет завершён."
    )
    await safe_edit(cb.message, text, reply_markup=kb.proc_work_kb(proc_id, data))
    await cb.answer()


async def cb_proc_work_mode(cb: types.CallbackQuery):
    proc_id = int(cb.data.split(":")[1])
    db.update_process(proc_id, work_settings={"mode": "unlimited"})
    await cb_proc_work(cb)


async def cb_proc_work_set(cb: types.CallbackQuery, state: FSMContext):
    parts = cb.data.split(":")
    proc_id, kind = int(parts[1]), parts[2]
    _temp[cb.from_user.id] = {"proc_id": proc_id, "kind": kind}
    await state.set_state(States.proc_work_input)
    if kind == "cycles":
        prompt = "Введите количество циклов от 1:"
    else:
        prompt = "Введите срок в формате дни.часы.минуты.\n0.0.0 — бессрочно:"
    await safe_edit(cb.message, prompt, reply_markup=kb.kb(kb.back(f"proc_work:{proc_id}")))
    await cb.answer()


async def state_proc_work_input(message: types.Message, state: FSMContext):
    uid = message.from_user.id
    temp = _temp.get(uid, {})
    proc_id = temp.get("proc_id")
    try:
        proc = db.get_process(proc_id)
        if temp.get("kind") == "cycles":
            value = int((message.text or "").strip())
            if value < 1:
                raise ValueError
            data = {"mode": "cycles", "cycles": value}
        else:
            seconds = parse_duration(message.text)
            if seconds is None:
                raise ValueError
            data = {"mode": "unlimited" if seconds == 0 else "duration", "duration_seconds": seconds, "duration_text": (message.text or "").strip()}
        db.update_process(proc_id, work_settings=data)
        _temp.pop(uid, None)
        await state.clear()
        await message.answer("✅ Время работы сохранено", reply_markup=kb.kb(kb.back(f"proc_work:{proc_id}")))
    except Exception:
        await message.answer("❌ Некорректный формат")


async def cb_proc_flood(cb: types.CallbackQuery):
    proc_id = int(cb.data.split(":")[1])
    proc = db.get_process(proc_id)
    data = proc.get("flood_settings") or {"enabled": True, "threshold": 3, "hours": 1}
    await safe_edit(cb.message, "🛡 <b>Реакция на FloodWait (Анти-Заморозка)</b>\n\nНастройка применяется только к FloodWait за частую рассылку сообщений. Автосаб на неё не распространяется.", reply_markup=kb.proc_flood_kb(proc_id, data))
    await cb.answer()


async def cb_proc_flood_toggle(cb: types.CallbackQuery):
    proc_id = int(cb.data.split(":")[1])
    proc = db.get_process(proc_id)
    data = proc.get("flood_settings") or {"enabled": True, "threshold": 3, "hours": 1}
    data["enabled"] = not data.get("enabled", True)
    db.update_process(proc_id, flood_settings=data)
    await cb_proc_flood(cb)


async def cb_proc_flood_set(cb: types.CallbackQuery, state: FSMContext):
    parts = cb.data.split(":")
    proc_id, key = int(parts[1]), parts[2]
    _temp[cb.from_user.id] = {"proc_id": proc_id, "key": key}
    await state.set_state(States.proc_flood_input)
    label = "количество FloodWait" if key == "threshold" else "количество часов окна"
    await safe_edit(cb.message, f"Введите {label} (целое число от 1):", reply_markup=kb.kb(kb.back(f"proc_flood:{proc_id}")))
    await cb.answer()


async def state_proc_flood_input(message: types.Message, state: FSMContext):
    uid = message.from_user.id
    temp = _temp.get(uid, {})
    try:
        value = int((message.text or "").strip())
        if value < 1:
            raise ValueError
        proc = db.get_process(temp["proc_id"])
        data = proc.get("flood_settings") or {"enabled": True, "threshold": 3, "hours": 1}
        data[temp["key"]] = value
        db.update_process(temp["proc_id"], flood_settings=data)
        _temp.pop(uid, None)
        await state.clear()
        await message.answer("✅ Настройка сохранена", reply_markup=kb.kb(kb.back(f"proc_flood:{temp['proc_id']}")))
    except Exception:
        await message.answer("❌ Введите целое число от 1")


async def cb_proc_slow(cb: types.CallbackQuery):
    proc_id = int(cb.data.split(":")[1])
    proc = db.get_process(proc_id)
    data = proc.get("slowdown_settings") or {"enabled": False, "threshold": 1, "mode": "percent", "value": 20}
    await safe_edit(cb.message, "🐢 <b>Авто-Замедление</b>\n\nНастройка изменяет только задержки текущего процесса и не меняет шаблон. На Автосаб не распространяется.", reply_markup=kb.proc_slow_kb(proc_id, data))
    await cb.answer()


async def cb_proc_slow_toggle(cb: types.CallbackQuery):
    proc_id = int(cb.data.split(":")[1])
    proc = db.get_process(proc_id)
    data = proc.get("slowdown_settings") or {"enabled": False, "threshold": 1, "mode": "percent", "value": 20}
    data["enabled"] = not data.get("enabled", False)
    db.update_process(proc_id, slowdown_settings=data)
    await cb_proc_slow(cb)


async def cb_proc_slow_mode(cb: types.CallbackQuery):
    proc_id = int(cb.data.split(":")[1])
    proc = db.get_process(proc_id)
    data = proc.get("slowdown_settings") or {"enabled": False, "threshold": 1, "mode": "percent", "value": 20}
    data["mode"] = "seconds" if data.get("mode", "percent") == "percent" else "percent"
    db.update_process(proc_id, slowdown_settings=data)
    await cb_proc_slow(cb)


async def cb_proc_slow_set(cb: types.CallbackQuery, state: FSMContext):
    parts = cb.data.split(":")
    proc_id, key = int(parts[1]), parts[2]
    _temp[cb.from_user.id] = {"proc_id": proc_id, "key": key}
    await state.set_state(States.proc_slow_input)
    await safe_edit(cb.message, "Введите целое число. Для процента допустимо 1-100:", reply_markup=kb.kb(kb.back(f"proc_slow:{proc_id}")))
    await cb.answer()


async def state_proc_slow_input(message: types.Message, state: FSMContext):
    uid = message.from_user.id
    temp = _temp.get(uid, {})
    try:
        value = int((message.text or "").strip())
        proc = db.get_process(temp["proc_id"])
        data = proc.get("slowdown_settings") or {"enabled": False, "threshold": 1, "mode": "percent", "value": 20}
        if temp["key"] == "threshold" and value < 1:
            raise ValueError
        if temp["key"] == "value" and (value < 1 or (data.get("mode") == "percent" and value > 100)):
            raise ValueError
        data[temp["key"]] = value
        db.update_process(temp["proc_id"], slowdown_settings=data)
        _temp.pop(uid, None)
        await state.clear()
        await message.answer("✅ Настройка сохранена", reply_markup=kb.kb(kb.back(f"proc_slow:{temp['proc_id']}")))
    except Exception:
        await message.answer("❌ Некорректное значение")


async def cb_proc_logs(cb: types.CallbackQuery):
    proc_id = int(cb.data.split(":")[1])
    proc = db.get_process(proc_id)
    current = proc.get("log_level", "errors")
    await safe_edit(cb.message, "🔔 <b>Настройка логов</b>\n\nВыберите уровень уведомлений:",
                    reply_markup=kb.proc_logs_kb(proc_id, current))
    await cb.answer()


async def cb_proc_set_log(cb: types.CallbackQuery):
    parts = cb.data.split(":")
    proc_id = int(parts[1])
    level = parts[2]
    db.update_process(proc_id, log_level=level)
    await cb.answer("✅ Сохранено!")
    await cb_proc_open(cb)


async def cb_proc_start(cb: types.CallbackQuery, bot: Bot):
    proc_id = int(cb.data.split(":")[1])
    proc = db.get_process(proc_id)
    if not proc:
        await cb.answer("❌ Процесс не найден", show_alert=True)
        return


    if not proc.get("template_ids"):
        await cb.answer("❌ Сначала выберите шаблон", show_alert=True)
        return
    for template_id in proc.get("template_ids", []):
        template = db.get_template(template_id)
        folder_session_id = (template["data"].get("folder_session_id") or template["data"].get("ac_folder_session_id")) if template else None
        if folder_session_id and set(proc.get("session_ids", [])) != {int(folder_session_id)}:
            await cb.answer(
                "❌ В шаблоне выбрана папка, которая привязана к другому аккаунту. "
                "Выберите этот аккаунт в процессе или уберите папку.",
                show_alert=True,
            )
            return
    if not proc.get("session_ids"):
        await cb.answer("❌ Сначала выберите аккаунты", show_alert=True)
        return

    settings = load_settings()
    bot_token = settings.get("BOT_TOKEN", "")

    ok = await broadcaster.start_process(proc_id, bot_token)
    if ok:
        await cb.answer("✅ Процесс запущен!")
    else:
        await cb.answer("❌ Не удалось запустить процесс", show_alert=True)
    await cb_proc_open(cb)


async def cb_proc_stop(cb: types.CallbackQuery):
    proc_id = int(cb.data.split(":")[1])
    await broadcaster.stop_process(proc_id)
    await cb.answer("⏹ Процесс остановлен!")
    await cb_proc_open(cb)


async def cb_proc_delete(cb: types.CallbackQuery):
    proc_id = int(cb.data.split(":")[1])
    await broadcaster.stop_process(proc_id)
    db.delete_process(proc_id)
    uid = cb.from_user.id
    await safe_edit(cb.message, "🗑 Процесс удалён.", reply_markup=kb.processes_kb(uid))
    await cb.answer()


# ─── FUNCTIONS ────────────────────────────────────────────────────────────────

async def cb_functions(cb: types.CallbackQuery):
    await safe_edit(cb.message, "⚙️ <b>Функции</b>\n\nВыберите сервис для просмотра информации:",
                    reply_markup=kb.functions_kb())
    await cb.answer()


# ─── PROMO CODES ──────────────────────────────────────────────────────────────

async def _enter_promo(message: types.Message, state: FSMContext, code: str = ""):
    if code:
        ok, result = db.redeem_promo(message.from_user.id, code)
        await state.clear()
        await message.answer(("✅ " if ok else "❌ ") + result, reply_markup=kb.kb(kb.back("subscriptions")))
        return
    await state.set_state(States.promo_code)
    await message.answer("🎟 Введите промокод:", reply_markup=kb.kb(kb.back("subscriptions")))


async def cb_promo_enter(cb: types.CallbackQuery, state: FSMContext):
    await _enter_promo(cb.message, state)
    await cb.answer()


async def state_promo_code(message: types.Message, state: FSMContext):
    await _enter_promo(message, state, (message.text or "").strip())


async def cmd_promo(message: types.Message, state: FSMContext):
    parts = (message.text or "").split(maxsplit=1)
    await _enter_promo(message, state, parts[1].strip() if len(parts) > 1 else "")


# ─── SUBSCRIPTIONS ────────────────────────────────────────────────────────────

async def cb_subscriptions(cb: types.CallbackQuery):
    uid = cb.from_user.id
    plans = db.get_plans()
    if not plans:
        await safe_edit(cb.message, "💳 <b>Подписки</b>\n\nТарифы пока не добавлены.",
                        reply_markup=kb.kb(kb.back("main_menu")))
        await cb.answer()
        return
    discount = db.get_user_discount(uid)
    text = "💳 <b>Подписки</b>\n\n"
    if discount:
        text += f"🎟 Ваша скидка: <b>{discount}%</b> (сохраняется до оплаты)\n\n"
    for p in plans:
        price = db.effective_price(p)
        if discount:
            price = round(price * (1 - discount / 100), 2)
        disc = f" (скидка {p['discount_pct']}%)" if p.get("discount_pct") else ""
        text += f"• <b>{p['name']}</b> — ${price:.2f}{disc} ({p['days']} дн.)\n"
    await safe_edit(cb.message, text, reply_markup=kb.subscriptions_kb(plans, uid))
    await cb.answer()


async def cb_sub_buy(cb: types.CallbackQuery, bot: Bot):
    plan_id = int(cb.data.split(":")[1])
    plan = db.get_plan(plan_id)
    if not plan:
        await cb.answer("Тариф не найден", show_alert=True)
        return

    cryptobot_token = db.get_setting("cryptobot_token")
    if not cryptobot_token:
        await cb.answer("❌ Оплата временно недоступна. Обратитесь к администратору.", show_alert=True)
        return

    price = db.effective_price(plan)
    uid = cb.from_user.id
    promo_discount = db.get_user_discount(uid)
    if promo_discount:
        price = round(price * (1 - promo_discount / 100), 2)

    try:
        async with aiohttp.ClientSession() as session:
            resp = await session.post(
                "https://pay.crypt.bot/api/createInvoice",
                headers={"Crypto-Pay-API-Token": cryptobot_token},
                json={
                    "asset": "USDT",
                    "amount": str(price),
                    "description": f"Подписка: {plan['name']} ({plan['days']} дней)",
                    "expires_in": 3600,
                },
                timeout=aiohttp.ClientTimeout(total=15),
            )
            result = await resp.json()

        if not result.get("ok"):
            await cb.answer("❌ Ошибка создания счёта", show_alert=True)
            return

        invoice_data = result["result"]
        db.create_invoice(uid, plan_id, str(invoice_data["invoice_id"]), price)


        pay_url = invoice_data["bot_invoice_url"]
        await safe_edit(
            cb.message,
            f"💳 <b>Счёт создан!</b>\n\n"
            f"Тариф: {plan['name']}\n"
            f"Сумма: ${price:.2f} USDT\n\n"
            f"После оплаты подписка активируется автоматически.",
            reply_markup=kb.kb(
                [kb.url_btn("💳 Оплатить", pay_url)],
                kb.back("subscriptions"),
            ),
        )
    except Exception as e:
        logger.error(f"CryptoBot error: {e}")
        await cb.answer("❌ Ошибка создания счёта", show_alert=True)

    await cb.answer()


# ─── REFERRAL ─────────────────────────────────────────────────────────────────

async def cb_referral(cb: types.CallbackQuery):
    ref_enabled = db.get_setting("ref_enabled", True)
    uid = cb.from_user.id
    user = db.get_user(uid)
    if not user:
        await cb.answer()
        return

    if not ref_enabled:
        await safe_edit(cb.message, "🤝 <b>Реф. программа</b>\n\n❌ Реферальная программа отключена.",
                        reply_markup=kb.kb(kb.back("main_menu")))
        await cb.answer()
        return

    ref_code = user.get("ref_code", "—")
    bot_username = db.get_setting("bot_username", "your_bot")
    ref_link = f"https://t.me/{bot_username}?start={ref_code}"

    level_info = db.get_ref_level(uid)
    level_text = f"Ваш уровень: {level_info['level']} ({level_info['name']}) — {level_info['pct']}%"
    if level_info.get("next"):
        nxt = level_info["next"]
        needed = nxt["required_ref"] - user.get("ref_paid", 0)
        level_text += f"\nДо уровня {nxt['level']} ({nxt['name']} — {nxt['pct']}%): осталось {needed} реф."

    text = (
        f"🤝 <b>Реферальная программа</b>\n\n"
        f"🔗 Ваша ссылка: <code>{ref_link}</code>\n\n"
        f"📊 {level_text}\n\n"
        f"👥 Переходов: {user.get('ref_clicks', 0)}\n"
        f"💳 Оплативших: {user.get('ref_paid', 0)}\n"
        f"💰 Всего заработано: ${user.get('ref_balance', 0) + user.get('ref_balance', 0):.2f}\n"
        f"💵 Текущий баланс: ${user.get('ref_balance', 0):.2f}"
    )
    await safe_edit(cb.message, text, reply_markup=kb.referral_kb())
    await cb.answer()


async def cb_ref_withdraw(cb: types.CallbackQuery):
    uid = cb.from_user.id
    user = db.get_user(uid)
    balance = float(user.get("ref_balance", 0) if user else 0)
    if balance < 1:
        await cb.answer("❌ Минимальная сумма вывода: $1", show_alert=True)
        return

    token = db.get_setting("cryptobot_token")
    if not token:
        await cb.answer("❌ CryptoBot временно не настроен", show_alert=True)
        return

    amount_text = f"{balance:.8f}".rstrip("0").rstrip(".")
    try:
        async with aiohttp.ClientSession() as session:
            response = await session.post(
                "https://pay.crypt.bot/api/createCheck",
                headers={"Crypto-Pay-API-Token": token},
                json={
                    "asset": "USDT",
                    "amount": amount_text,
                    "pin_to_user_id": uid,
                },
                timeout=aiohttp.ClientTimeout(total=15),
            )
            result = await response.json()

        if not result.get("ok"):
            description = result.get("error", {}).get("name", "неизвестная ошибка")
            await cb.answer(f"❌ Не удалось создать чек: {description}", show_alert=True)
            return

        check = result.get("result") or {}
        check_id = check.get("check_id") or check.get("id")
        check_url = check.get("bot_check_url") or check.get("check_url")
        if not check_id or not check_url:
            await cb.answer("❌ CryptoBot не вернул ссылку на чек", show_alert=True)
            return

        if not db.create_ref_withdrawal(uid, balance, str(check_id), check_url):
            # Если баланс уже изменился параллельно, удаляем созданный чек,
            # чтобы деньги не зависли без записи в нашей БД.
            try:
                async with aiohttp.ClientSession() as session:
                    await session.post(
                        "https://pay.crypt.bot/api/deleteCheck",
                        headers={"Crypto-Pay-API-Token": token},
                        json={"check_id": check_id},
                        timeout=aiohttp.ClientTimeout(total=10),
                    )
            except Exception:
                pass
            await cb.answer("❌ Баланс уже изменился. Повторите попытку.", show_alert=True)
            return

        await safe_edit(
            cb.message,
            f"✅ <b>Чек на вывод создан</b>\n\n"
            f"Сумма: <b>${balance:.2f} USDT</b>\n"
            "Чек закреплён за вашим Telegram-аккаунтом.",
            reply_markup=kb.kb(
                [kb.url_btn("💸 Открыть чек", check_url)],
                kb.back("referral"),
            ),
        )
        await cb.answer("✅ Чек создан")
    except Exception as ex:
        logger.exception("Ошибка создания реферального чека")
        await cb.answer(f"❌ Ошибка создания чека: {ex}", show_alert=True)

async def state_ref_withdraw(message: types.Message, state: FSMContext):
    uid = message.from_user.id
    try:
        amount = float(message.text.strip().replace(",", "."))
    except Exception:
        await message.answer("❌ Неверная сумма")
        return
    ok = db.withdraw_request(uid, amount)
    await state.clear()
    if ok:
        await message.answer(f"✅ Заявка на вывод ${amount:.2f} отправлена!\nОжидайте обработки.", parse_mode="HTML")
    else:
        await message.answer("❌ Недостаточно средств")


# ─── SUPPORT / CHANNEL ────────────────────────────────────────────────────────

async def cb_support(cb: types.CallbackQuery):
    await safe_edit(cb.message, "👨‍💻 <b>Тех. поддержка</b>", reply_markup=kb.support_kb())
    await cb.answer()


async def cb_channel(cb: types.CallbackQuery):
    await safe_edit(cb.message, "📢 <b>Наш канал</b>", reply_markup=kb.channel_kb())
    await cb.answer()


async def cb_adm_statistics(cb: types.CallbackQuery):
    if not admin_check(cb):
        return await cb.answer("❌", show_alert=True)
    stats = db.get_admin_statistics()
    stats["active_sessions"] = len(broadcaster.get_active_session_ids())
    text = (
        "📊 <b>Статистика проекта</b>\n\n"
        f"👥 Всего пользователей: {stats['total_users']}\n"
        f"📱 Активных сессий: {stats['active_sessions']}\n"
        f"⚡ Активных пользователей: {stats['active_users']}\n"
        f"💳 Пользователей с подпиской: {stats['subscribed']}\n"
        f"📨 Всего отправлено сообщений: {stats['total_messages']}\n"
        f"🤝 Приглашено по рефералам: {stats['referrals']}\n\n"
        f"💰 Заработок с оплаченных подписок: ${stats['subscription_revenue']:.2f}\n"
        f"🤝 Заработано по рефералам: ${stats['referral_earned']:.2f}\n"
        f"💸 Выведено рефералами: ${stats['referral_withdrawn']:.2f}"
    )
    await safe_edit(cb.message, text, reply_markup=kb.kb(kb.back("admin_menu")))
    await cb.answer()


# ─── ADMIN MENU ───────────────────────────────────────────────────────────────

def admin_check(cb: types.CallbackQuery) -> bool:
    if not db.is_admin(cb.from_user.id):
        return False
    return True


async def cb_admin_menu(cb: types.CallbackQuery, state: FSMContext):
    await state.clear()
    if not admin_check(cb):
        await cb.answer("❌ Нет доступа", show_alert=True)
        return
    await safe_edit(cb.message, "🛠 <b>Админ-меню</b>", reply_markup=kb.admin_main_kb(cb.from_user.id))
    await cb.answer()


async def cb_adm_settings(cb: types.CallbackQuery):
    if not admin_check(cb):
        return await cb.answer("❌", show_alert=True)
    await safe_edit(cb.message, "⚙️ <b>Общие настройки</b>", reply_markup=kb.adm_settings_kb())
    await cb.answer()


# API Keys
async def cb_adm_set_api(cb: types.CallbackQuery, state: FSMContext):
    if not admin_check(cb):
        return await cb.answer("❌", show_alert=True)
    cur_id = db.get_setting("api_id", "—")
    await state.set_state(States.adm_api_id)
    await safe_edit(cb.message,
                    f"🔑 <b>Настройка API ключей</b>\n\nТекущий API ID: <code>{cur_id}</code>\n\nВведите новый API ID:",
                    reply_markup=kb.kb(kb.back("adm_settings")))
    await cb.answer()


async def state_adm_api_id(message: types.Message, state: FSMContext):
    if not db.is_admin(message.from_user.id):
        return
    if not message.text.strip().isdigit():
        await message.answer("❌ API ID должен быть числом")
        return
    _temp[message.from_user.id] = {"api_id": message.text.strip()}
    await state.set_state(States.adm_api_hash)
    await message.answer(
        "Введите API Hash:",
        reply_markup=kb.kb(kb.back("adm_settings")),
    )


async def state_adm_api_hash(message: types.Message, state: FSMContext):
    if not db.is_admin(message.from_user.id):
        return
    uid = message.from_user.id
    api_id = _temp.get(uid, {}).get("api_id")
    db.set_setting("api_id", api_id)
    db.set_setting("api_hash", message.text.strip())
    _temp.pop(uid, None)
    await state.clear()
    await message.answer(f"✅ API ключи сохранены!\nAPI ID: {api_id}", reply_markup=kb.kb(kb.back("adm_settings")))


# Links
async def cb_adm_set_links(cb: types.CallbackQuery):
    if not admin_check(cb):
        return await cb.answer("❌", show_alert=True)
    await safe_edit(cb.message, "🔗 <b>Изменить ссылки</b>", reply_markup=kb.adm_links_kb())
    await cb.answer()


async def cb_adm_link(cb: types.CallbackQuery, state: FSMContext):
    if not admin_check(cb):
        return await cb.answer("❌", show_alert=True)
    key_map = {
        "adm_link_channel": ("channel_url", "ссылку на канал"),
        "adm_link_support": ("support_url", "ссылку на поддержку"),
        "adm_link_func_broadcast": ("func_broadcast_url", "ссылку канала Рассылки"),
        "adm_link_func_ar": ("func_ar_url", "ссылку канала Автоответчика"),
        "adm_link_func_tb": ("func_tb_url", "ссылку канала Триггербота"),
        "adm_link_func_autochecker": ("func_autochecker_url", "ссылку канала Авточекера"),
    }
    key, label = key_map.get(cb.data, (None, None))
    if not key:
        return await cb.answer()
    _temp[cb.from_user.id] = {"link_key": key}
    await state.set_state(States.adm_link)
    cur = db.get_setting(key, "—")
    await safe_edit(cb.message, f"🔗 Текущее значение: <code>{cur}</code>\n\nВведите {label}:",
                    reply_markup=kb.kb(kb.back("adm_set_links")))
    await cb.answer()


async def state_adm_link(message: types.Message, state: FSMContext):
    if not db.is_admin(message.from_user.id):
        return
    uid = message.from_user.id
    key = _temp.get(uid, {}).get("link_key")
    db.set_setting(key, message.text.strip())
    _temp.pop(uid, None)
    await state.clear()
    await message.answer("✅ Ссылка сохранена!", reply_markup=kb.kb(kb.back("adm_set_links")))


# Media limits
async def cb_adm_media_limits(cb: types.CallbackQuery):
    if not admin_check(cb):
        return await cb.answer("❌", show_alert=True)
    no_limits = db.get_setting("media_no_limits", False)
    photo = db.get_setting("media_max_photo_mb", 10)
    gif = db.get_setting("media_max_gif_mb", 20)
    video_s = db.get_setting("media_max_video_mb", 50)
    video_d = db.get_setting("media_max_video_sec", 30)
    text = (
        f"🖼 <b>Лимиты медиафайлов</b>\n\n"
        f"{'🚫 Лимиты ОТКЛЮЧЕНЫ' if no_limits else '✅ Лимиты ВКЛЮЧЕНЫ'}\n\n"
        f"🖼 Картинки: {photo} МБ\n"
        f"🎞 Гифки: {gif} МБ\n"
        f"🎬 Видео: {video_s} МБ / {video_d} сек"
    )
    await safe_edit(cb.message, text, reply_markup=kb.adm_media_limits_kb())
    await cb.answer()


async def cb_adm_media_toggle(cb: types.CallbackQuery):
    if not admin_check(cb):
        return await cb.answer("❌", show_alert=True)
    db.set_setting("media_no_limits", not db.get_setting("media_no_limits", False))
    await cb_adm_media_limits(cb)


async def cb_adm_media_set(cb: types.CallbackQuery, state: FSMContext):
    if not admin_check(cb):
        return await cb.answer("❌", show_alert=True)
    key_map = {
        "adm_media_photo": ("media_max_photo_mb", "макс. вес картинки (МБ)"),
        "adm_media_gif": ("media_max_gif_mb", "макс. вес гифки (МБ)"),
        "adm_media_video_size": ("media_max_video_mb", "макс. вес видео (МБ)"),
        "adm_media_video_dur": ("media_max_video_sec", "макс. длительность видео (сек)"),
    }
    key, label = key_map.get(cb.data, (None, None))
    if not key:
        return await cb.answer()
    _temp[cb.from_user.id] = {"media_key": key}
    await state.set_state(States.adm_media_val)
    cur = db.get_setting(key, "—")
    await safe_edit(cb.message, f"Текущее: {cur}\n\nВведите {label}:",
                    reply_markup=kb.kb(kb.back("adm_media_limits")))
    await cb.answer()


async def state_adm_media_val(message: types.Message, state: FSMContext):
    if not db.is_admin(message.from_user.id):
        return
    uid = message.from_user.id
    key = _temp.get(uid, {}).get("media_key")
    try:
        val = int(message.text.strip())
        db.set_setting(key, val)
        await state.clear()
        await message.answer("✅ Сохранено!", reply_markup=kb.kb(kb.back("adm_media_limits")))
    except Exception:
        await message.answer("❌ Введите число")


# Subscriptions management
async def cb_adm_subs(cb: types.CallbackQuery):
    if not admin_check(cb):
        return await cb.answer("❌", show_alert=True)
    await safe_edit(cb.message, "💳 <b>Управление подписками</b>",
                    reply_markup=kb.adm_subs_kb(db.is_owner(cb.from_user.id)))
    await cb.answer()


async def cb_adm_plans(cb: types.CallbackQuery):
    if not admin_check(cb):
        return await cb.answer("❌", show_alert=True)
    plans = db.get_plans()
    await safe_edit(cb.message, "💰 <b>Тарифные планы</b>", reply_markup=kb.adm_plans_kb(plans))
    await cb.answer()


async def cb_adm_plan_create(cb: types.CallbackQuery, state: FSMContext):
    if not admin_check(cb):
        return await cb.answer("❌", show_alert=True)
    await state.set_state(States.adm_plan_name)
    await safe_edit(cb.message, "✏️ Введите название тарифа (например: 1 месяц):",
                    reply_markup=kb.kb(kb.back("adm_plans")))
    await cb.answer()


async def state_adm_plan_name(message: types.Message, state: FSMContext):
    if not db.is_admin(message.from_user.id):
        return
    _temp[message.from_user.id] = {"plan_name": message.text.strip()}
    await state.set_state(States.adm_plan_days)
    await message.answer(
        "📅 Введите количество дней:",
        reply_markup=kb.kb(kb.back("adm_plans")),
    )


async def state_adm_plan_days(message: types.Message, state: FSMContext):
    if not db.is_admin(message.from_user.id):
        return
    try:
        days = int(message.text.strip())
        _temp[message.from_user.id]["plan_days"] = days
        await state.set_state(States.adm_plan_price)
        await message.answer(
            "💵 Введите цену в USD (например: 9.99):",
            reply_markup=kb.kb(kb.back("adm_plans")),
        )
    except Exception:
        await message.answer("❌ Введите число")


async def state_adm_plan_price(message: types.Message, state: FSMContext):
    if not db.is_admin(message.from_user.id):
        return
    try:
        price = float(message.text.strip())
        uid = message.from_user.id
        temp = _temp.get(uid, {})
        plan_id = db.create_plan(temp["plan_name"], temp["plan_days"], price)
        _temp.pop(uid, None)
        await state.clear()
        await message.answer(f"✅ Тариф создан!\n{temp['plan_name']} — {temp['plan_days']} дн. — ${price}", reply_markup=kb.kb(kb.back("adm_plans")))
    except Exception:
        await message.answer("❌ Введите число")


async def cb_adm_plan_edit(cb: types.CallbackQuery, state: FSMContext):
    if not admin_check(cb):
        return await cb.answer("❌", show_alert=True)
    plan_id = int(cb.data.split(":")[1])
    plan = db.get_plan(plan_id)
    if not plan:
        await cb.answer("Не найдено", show_alert=True)
        return
    text = (
        f"📋 <b>Тариф: {plan['name']}</b>\n\n"
        f"📅 Дней: {plan['days']}\n"
        f"💵 Цена: ${plan['price_usd']}\n"
        f"🎁 Скидка: {plan.get('discount_pct', 0)}%\n"
        f"⏰ Скидка до: {plan.get('discount_until') or 'без ограничений'}"
    )
    await safe_edit(cb.message, text, reply_markup=kb.kb(
        [kb.btn("🎁 Установить скидку", f"adm_plan_discount:{plan_id}")],
        [kb.btn("🗑 Удалить тариф", f"adm_plan_delete:{plan_id}")],
        kb.back("adm_plans"),
    ))
    await cb.answer()


async def cb_adm_plan_discount(cb: types.CallbackQuery, state: FSMContext):
    if not admin_check(cb):
        return await cb.answer("❌", show_alert=True)
    plan_id = int(cb.data.split(":")[1])
    _temp[cb.from_user.id] = {"plan_id": plan_id}
    await state.set_state(States.adm_plan_discount)
    await safe_edit(cb.message, "Введите размер скидки в % (0 = без скидки):",
                    reply_markup=kb.kb(kb.back(f"adm_plan_edit:{plan_id}")))
    await cb.answer()


async def state_adm_plan_discount(message: types.Message, state: FSMContext):
    if not db.is_admin(message.from_user.id):
        return
    uid = message.from_user.id
    plan_id = _temp.get(uid, {}).get("plan_id")
    try:
        pct = int(message.text.strip())
        _temp[uid]["plan_discount"] = pct
        if pct > 0:
            await state.set_state(States.adm_plan_discount_until)
            await message.answer(
                "📅 Введите дату окончания скидки (формат: YYYY-MM-DD) или 0 для бессрочной:",
                reply_markup=kb.kb(kb.back(f"adm_plan_edit:{plan_id}")),
            )
        else:
            db.update_plan(plan_id, discount_pct=0, discount_until=None)
            _temp.pop(uid, None)
            await state.clear()
            await message.answer("✅ Скидка убрана!", reply_markup=kb.kb(kb.back(f"adm_plan_edit:{plan_id}")))
    except Exception:
        await message.answer("❌ Введите число")


async def state_adm_plan_discount_until(message: types.Message, state: FSMContext):
    if not db.is_admin(message.from_user.id):
        return
    uid = message.from_user.id
    temp = _temp.get(uid, {})
    plan_id = temp.get("plan_id")
    pct = temp.get("plan_discount", 0)
    until_str = message.text.strip()
    if until_str == "0":
        until_val = None
    else:
        try:
            datetime.strptime(until_str, "%Y-%m-%d")
            until_val = until_str
        except Exception:
            await message.answer("❌ Неверный формат даты. Используйте YYYY-MM-DD")
            return
    db.update_plan(plan_id, discount_pct=pct, discount_until=until_val)
    _temp.pop(uid, None)
    await state.clear()
    await message.answer(f"✅ Скидка {pct}% установлена!", reply_markup=kb.kb(kb.back(f"adm_plan_edit:{plan_id}")))


async def cb_adm_plan_delete(cb: types.CallbackQuery):
    if not admin_check(cb):
        return await cb.answer("❌", show_alert=True)
    plan_id = int(cb.data.split(":")[1])
    db.delete_plan(plan_id)
    await cb.answer("✅ Тариф удалён!")
    await cb_adm_plans(cb)


async def cb_adm_give_sub(cb: types.CallbackQuery):
    if not admin_check(cb):
        return await cb.answer("❌", show_alert=True)
    await safe_edit(cb.message, "🎁 <b>Выдать дни подписки</b>", reply_markup=kb.adm_give_sub_kb())
    await cb.answer()


async def cb_adm_give_sub_all(cb: types.CallbackQuery, state: FSMContext):
    if not admin_check(cb):
        return await cb.answer("❌", show_alert=True)
    _temp[cb.from_user.id] = {"sub_target": "all"}
    await state.set_state(States.adm_give_sub_days)
    await safe_edit(cb.message, "Введите количество дней для выдачи всем активным пользователям:",
                    reply_markup=kb.kb(kb.back("adm_give_sub")))
    await cb.answer()


async def cb_adm_give_sub_id(cb: types.CallbackQuery, state: FSMContext):
    if not admin_check(cb):
        return await cb.answer("❌", show_alert=True)
    await state.set_state(States.adm_give_sub_id)
    await safe_edit(cb.message, "Введите ID пользователя:",
                    reply_markup=kb.kb(kb.back("adm_give_sub")))
    await cb.answer()


async def state_adm_give_sub_id(message: types.Message, state: FSMContext):
    if not db.is_admin(message.from_user.id):
        return
    if not message.text.strip().isdigit():
        await message.answer("❌ ID должен быть числом")
        return
    _temp[message.from_user.id] = {"sub_target": int(message.text.strip())}
    await state.set_state(States.adm_give_sub_days)
    await message.answer(
        "Введите количество дней:",
        reply_markup=kb.kb(kb.back("adm_give_sub")),
    )


async def state_adm_give_sub_days(message: types.Message, state: FSMContext):
    if not db.is_admin(message.from_user.id):
        return
    uid = message.from_user.id
    temp = _temp.get(uid, {})
    try:
        days = int(message.text.strip())
        target = temp.get("sub_target")
        if target == "all":
            db.give_sub_to_all(days)
            await message.answer(f"✅ Выдано {days} дней всем активным пользователям!", reply_markup=kb.kb(kb.back("adm_give_sub")))
        else:
            db.add_sub_days(int(target), days)
            await message.answer(f"✅ Выдано {days} дней пользователю {target}!", reply_markup=kb.kb(kb.back("adm_give_sub")))
        _temp.pop(uid, None)
        await state.clear()
    except Exception:
        await message.answer("❌ Введите число")


async def cb_adm_take_sub(cb: types.CallbackQuery, state: FSMContext):
    if not admin_check(cb):
        return await cb.answer("❌", show_alert=True)
    await state.set_state(States.adm_take_sub_id)
    await safe_edit(cb.message, "Введите ID пользователя для списания дней подписки:",
                    reply_markup=kb.kb(kb.back("adm_subs")))
    await cb.answer()


async def state_adm_take_sub_id(message: types.Message, state: FSMContext):
    if not db.is_admin(message.from_user.id):
        return
    if not message.text.strip().isdigit():
        await message.answer("❌ ID должен быть числом")
        return
    _temp[message.from_user.id] = {"take_target": int(message.text.strip())}
    await state.set_state(States.adm_take_sub_days)
    await message.answer(
        "Введите количество дней для списания:",
        reply_markup=kb.kb(kb.back("adm_subs")),
    )


async def state_adm_take_sub_days(message: types.Message, state: FSMContext):
    if not db.is_admin(message.from_user.id):
        return
    uid = message.from_user.id
    temp = _temp.get(uid, {})
    try:
        days = int(message.text.strip())
        target = temp.get("take_target")
        db.subtract_sub_days(int(target), days)
        await message.answer(f"✅ Списано {days} дней у пользователя {target}!", reply_markup=kb.kb(kb.back("adm_subs")))
        _temp.pop(uid, None)
        await state.clear()
    except Exception:
        await message.answer("❌ Введите число")


# CryptoBot
async def cb_adm_cryptobot(cb: types.CallbackQuery, state: FSMContext):
    if not db.is_owner(cb.from_user.id):
        return await cb.answer("❌ Только для владельца", show_alert=True)
    cur = db.get_setting("cryptobot_token")
    masked = f"{cur[:6]}...{cur[-4:]}" if cur else "Не установлен"
    await state.set_state(States.adm_cryptobot_token)
    await safe_edit(cb.message,
                    f"🏦 <b>Настройка CryptoBot</b>\n\nТекущий токен: <code>{masked}</code>\n\nВведите токен CryptoPay API:",
                    reply_markup=kb.kb(kb.back("adm_subs")))
    await cb.answer()


async def state_adm_cryptobot_token(message: types.Message, state: FSMContext):
    if not db.is_owner(message.from_user.id):
        return
    db.set_setting("cryptobot_token", message.text.strip())
    await state.clear()
    await message.answer("✅ CryptoBot токен сохранён!", reply_markup=kb.kb(kb.back("adm_subs")))


# Referrals admin
async def cb_adm_ref(cb: types.CallbackQuery):
    if not admin_check(cb):
        return await cb.answer("❌", show_alert=True)
    await safe_edit(cb.message, "🤝 <b>Управление реферальной программой</b>", reply_markup=kb.adm_ref_kb())
    await cb.answer()


async def cb_adm_ref_toggle(cb: types.CallbackQuery):
    if not admin_check(cb):
        return await cb.answer("❌", show_alert=True)
    db.set_setting("ref_enabled", not db.get_setting("ref_enabled", True))
    await cb_adm_ref(cb)


async def cb_adm_ref_levels(cb: types.CallbackQuery, state: FSMContext):
    if not admin_check(cb):
        return await cb.answer("❌", show_alert=True)
    levels = db.get_ref_levels()
    if levels:
        text = "⚙️ <b>Текущие уровни:</b>\n"
        for lv in levels:
            text += f"\n{lv['level']}. {lv['name']} — {lv['required_ref']} реф. — {lv['pct']}%"
        text += "\n\nВведите количество уровней для перенастройки:"
    else:
        text = "⚙️ <b>Уровни не настроены</b>\n\nВведите количество уровней (например: 3):"
    await state.set_state(States.adm_ref_level_count)
    await safe_edit(cb.message, text, reply_markup=kb.kb(kb.back("adm_ref")))
    await cb.answer()


async def state_adm_ref_level_count(message: types.Message, state: FSMContext):
    if not db.is_admin(message.from_user.id):
        return
    try:
        count = int(message.text.strip())
        if count < 1 or count > 10:
            await message.answer("❌ От 1 до 10 уровней")
            return
        _temp[message.from_user.id] = {"ref_level_count": count, "ref_levels": [], "ref_step": 0}
        await state.set_state(States.adm_ref_level_data)
        await message.answer(
            f"Настраиваем уровень 1 из {count}\n\n"
            "Введите данные в формате: <code>Название КоличествоРеф Процент</code>\n"
            "Пример: <code>Новичок 0 10</code>",
            parse_mode="HTML",
            reply_markup=kb.kb(kb.back("adm_ref")),
        )
    except Exception:
        await message.answer("❌ Введите число")


async def state_adm_ref_level_data(message: types.Message, state: FSMContext):
    if not db.is_admin(message.from_user.id):
        return
    uid = message.from_user.id
    temp = _temp.get(uid, {})
    parts = message.text.strip().split()
    try:
        name = parts[0]
        req = int(parts[1])
        pct = int(parts[2])
        step = temp["ref_step"]
        temp["ref_levels"].append({"level": step + 1, "name": name, "required_ref": req, "pct": pct})
        temp["ref_step"] += 1

        if temp["ref_step"] >= temp["ref_level_count"]:
            db.set_ref_levels(temp["ref_levels"])
            _temp.pop(uid, None)
            await state.clear()
            await message.answer("✅ Уровни реферальной программы сохранены!", reply_markup=kb.kb(kb.back("adm_ref")))
        else:
            nxt = temp["ref_step"] + 1
            await message.answer(
                f"Настраиваем уровень {nxt} из {temp['ref_level_count']}\n\n"
                "Введите: <code>Название КоличествоРеф Процент</code>",
                parse_mode="HTML",
                reply_markup=kb.kb(kb.back("adm_ref")),
            )
    except Exception:
        await message.answer("❌ Неверный формат. Попробуйте ещё раз.")


# Promo codes
async def cb_adm_promos(cb: types.CallbackQuery):
    if not admin_check(cb):
        return await cb.answer("❌", show_alert=True)
    await safe_edit(cb.message, "🎟 <b>Промокоды</b>", reply_markup=kb.adm_promos_kb())
    await cb.answer()


async def cb_adm_promo_create(cb: types.CallbackQuery, state: FSMContext):
    if not admin_check(cb):
        return await cb.answer("❌", show_alert=True)
    await state.set_state(States.adm_promo_code)
    await safe_edit(cb.message, "Введите код промокода (например: SALE20):",
                    reply_markup=kb.kb(kb.back("adm_promos")))
    await cb.answer()


async def state_adm_promo_code(message: types.Message, state: FSMContext):
    if not db.is_admin(message.from_user.id):
        return
    _temp[message.from_user.id] = {"promo_code": message.text.strip().upper()}
    await state.set_state(States.adm_promo_type)
    await message.answer("Выберите тип промокода:",
                         reply_markup=kb.kb(
                             [kb.btn("🎁 Дни подписки", "promo_type:days")],
                             [kb.btn("💰 Скидка %", "promo_type:discount")],
                             kb.back("adm_promos"),
                         ))


async def cb_promo_type(cb: types.CallbackQuery, state: FSMContext):
    if not admin_check(cb):
        return await cb.answer("❌", show_alert=True)
    ptype = cb.data.split(":")[1]
    _temp[cb.from_user.id]["promo_type"] = ptype
    await state.set_state(States.adm_promo_value)
    label = "дней подписки" if ptype == "days" else "% скидки"
    await safe_edit(cb.message, f"Введите значение ({label}):", reply_markup=kb.kb(kb.back("adm_promos")))
    await cb.answer()


async def state_adm_promo_value(message: types.Message, state: FSMContext):
    if not db.is_admin(message.from_user.id):
        return
    try:
        val = int(message.text.strip())
        _temp[message.from_user.id]["promo_value"] = val
        await state.set_state(States.adm_promo_uses)
        await message.answer(
            "Введите количество активаций:",
            reply_markup=kb.kb(kb.back("adm_promos")),
        )
    except Exception:
        await message.answer("❌ Введите число")


async def state_adm_promo_uses(message: types.Message, state: FSMContext):
    if not db.is_admin(message.from_user.id):
        return
    uid = message.from_user.id
    temp = _temp.get(uid, {})
    try:
        uses = int(message.text.strip())
        if uses < 1:
            raise ValueError
        temp["promo_uses"] = uses
        await state.set_state(States.adm_promo_activation)
        await message.answer(
            "⏱ Введите срок активации промокода в формате дни.часы.минуты.\n"
            "Например: 1.0.0 или 0.0.1.\n"
            "0.0.0 — безлимитный срок:",
            reply_markup=kb.kb(kb.back("adm_promos")),
        )
    except Exception:
        await message.answer("❌ Введите целое число активаций от 1")


async def state_adm_promo_activation(message: types.Message, state: FSMContext):
    if not db.is_admin(message.from_user.id):
        return
    uid = message.from_user.id
    temp = _temp.get(uid, {})
    seconds = parse_duration(message.text)
    if seconds is None:
        await message.answer("❌ Формат: дни.часы.минуты, например 1.0.0")
        return
    temp["activation_seconds"] = seconds
    if temp.get("promo_type") == "discount":
        await state.set_state(States.adm_promo_discount_duration)
        await message.answer(
            "⏱ Введите срок действия скидки после активации в формате дни.часы.минуты.\n"
            "0.0.0 — скидка бессрочная:",
            reply_markup=kb.kb(kb.back("adm_promos")),
        )
        return
    await _finish_promo_creation(message, state, temp, 0)


async def state_adm_promo_discount_duration(message: types.Message, state: FSMContext):
    if not db.is_admin(message.from_user.id):
        return
    seconds = parse_duration(message.text)
    if seconds is None:
        await message.answer("❌ Формат: дни.часы.минуты, например 0.2.0")
        return
    await _finish_promo_creation(message, state, _temp.get(message.from_user.id, {}), seconds)


async def _finish_promo_creation(message: types.Message, state: FSMContext, temp: dict, discount_seconds: int):
    uid = message.from_user.id
    ok = db.create_promo(
        temp["promo_code"], temp["promo_type"], temp["promo_value"],
        temp["promo_uses"], temp.get("activation_seconds", 0), discount_seconds,
    )
    code = temp.get("promo_code")
    _temp.pop(uid, None)
    await state.clear()
    if ok:
        await message.answer(
            f"✅ Промокод <b>{code}</b> создан!",
            parse_mode="HTML",
            reply_markup=kb.kb(kb.back("adm_promos")),
        )
    else:
        await message.answer("❌ Такой промокод уже существует", reply_markup=kb.kb(kb.back("adm_promos")))


async def cb_adm_promo_list(cb: types.CallbackQuery):
    if not admin_check(cb):
        return await cb.answer("❌", show_alert=True)
    promos = db.get_all_promos()
    if not promos:
        await safe_edit(cb.message, "🎟 <b>Список промокодов</b>\n\nАктивных промокодов нет.", reply_markup=kb.kb(kb.back("adm_promos")))
        await cb.answer()
        return
    text = "🎟 <b>Список промокодов:</b>\n\n"
    for p in promos:
        activation = p.get("activation_until") or "безлимит"
        discount = p.get("discount_seconds", 0)
        text += f"• <code>{p['code']}</code> — {p['type']}: {p['value']}, осталось: {p['uses_left']}, до: {activation}"
        if p["type"] == "discount":
            text += f", скидка действует: {discount // 60} мин." if discount else ", скидка бессрочно"
        text += "\n"
    await safe_edit(cb.message, text, reply_markup=kb.adm_promo_list_kb(promos))
    await cb.answer()


async def cb_adm_promo_delete(cb: types.CallbackQuery):
    if not admin_check(cb):
        return await cb.answer("❌", show_alert=True)
    promo_id = int(cb.data.split(":")[1])
    db.delete_promo(promo_id)
    await cb_adm_promo_list(cb)


# Admin management
async def cb_adm_admins(cb: types.CallbackQuery):
    if not db.is_owner(cb.from_user.id):
        return await cb.answer("❌ Только для владельца", show_alert=True)
    await safe_edit(cb.message, "👑 <b>Управление администраторами</b>", reply_markup=kb.adm_admins_kb())
    await cb.answer()


async def cb_adm_admin_add(cb: types.CallbackQuery, state: FSMContext):
    if not db.is_owner(cb.from_user.id):
        return await cb.answer("❌", show_alert=True)
    await state.set_state(States.adm_admin_add)
    await safe_edit(cb.message, "Введите ID нового администратора:",
                    reply_markup=kb.kb(kb.back("adm_admins")))
    await cb.answer()


async def state_adm_admin_add(message: types.Message, state: FSMContext):
    if not db.is_owner(message.from_user.id):
        return
    if not message.text.strip().isdigit():
        await message.answer("❌ ID должен быть числом")
        return
    target_id = int(message.text.strip())
    db.add_admin(target_id, is_owner=False)
    await state.clear()
    await message.answer(f"✅ Администратор {target_id} добавлен!", reply_markup=kb.kb(kb.back("adm_admins")))


async def cb_adm_admin_remove(cb: types.CallbackQuery, state: FSMContext):
    if not db.is_owner(cb.from_user.id):
        return await cb.answer("❌", show_alert=True)
    await state.set_state(States.adm_admin_remove)
    await safe_edit(cb.message, "Введите ID администратора для удаления:",
                    reply_markup=kb.kb(kb.back("adm_admins")))
    await cb.answer()


async def state_adm_admin_remove(message: types.Message, state: FSMContext):
    if not db.is_owner(message.from_user.id):
        return
    if not message.text.strip().isdigit():
        await message.answer("❌ ID должен быть числом")
        return
    target_id = int(message.text.strip())
    if db.is_owner(target_id):
        await message.answer("❌ Нельзя удалить владельца")
        return
    db.remove_admin(target_id)
    await state.clear()
    await message.answer(f"✅ Администратор {target_id} удалён!", reply_markup=kb.kb(kb.back("adm_admins")))


async def cb_adm_admin_list(cb: types.CallbackQuery):
    if not db.is_owner(cb.from_user.id):
        return await cb.answer("❌", show_alert=True)
    admins = db.get_all_admins()
    text = "👑 <b>Администраторы:</b>\n\n"
    for a in admins:
        role = "👑 Владелец" if a["is_owner"] else "🛠 Админ"
        text += f"• {a['user_id']} — {role}\n"
    await safe_edit(cb.message, text, reply_markup=kb.kb(kb.back("adm_admins")))
    await cb.answer()


# Broadcast to all
async def cb_adm_broadcast(cb: types.CallbackQuery, state: FSMContext):
    if not admin_check(cb):
        return await cb.answer("❌", show_alert=True)
    await state.set_state(States.adm_broadcast_text)
    await safe_edit(cb.message, "📢 Введите текст рассылки для всех пользователей:",
                    reply_markup=kb.kb(kb.back("admin_menu")))
    await cb.answer()


async def state_adm_broadcast_text(message: types.Message, state: FSMContext, bot: Bot):
    if not db.is_admin(message.from_user.id):
        return
    await state.clear()
    users = db.get_all_users()
    sent = 0
    failed = 0
    for u in users:
        if u.get("banned"):
            continue
        try:
            await bot.send_message(u["user_id"], f"📢 <b>Сообщение от администратора:</b>\n\n{message.text}",
                                   parse_mode="HTML")
            sent += 1
        except Exception:
            failed += 1
        await asyncio.sleep(0.05)
    await message.answer(f"✅ Рассылка завершена!\nОтправлено: {sent} | Ошибок: {failed}", reply_markup=kb.kb(kb.back("admin_menu")))


# Users management

def _user_label(user: dict) -> str:
    name = escape(str(user.get("first_name") or "—"))
    username = user.get("username")
    return f"{name} (@{escape(str(username))})" if username else name


def _format_user_card(user: dict, sessions: list) -> str:
    uid = user["user_id"]
    session_lines = []
    for session in sessions[:20]:
        session_lines.append(
            f"• <code>{session['id']}</code> — {escape(str(session.get('name') or 'Без названия'))}"
        )
    session_text = "\n".join(session_lines) if session_lines else "нет активных сессий"
    return (
        f"🔍 <b>Информация о пользователе {uid}</b>\n\n"
        f"👤 Имя: {_user_label(user)}\n"
        f"📛 Username: @{escape(str(user.get('username') or '—'))}\n"
        f"📅 Регистрация: {(user.get('created_at') or '—')[:10]}\n"
        f"💳 Подписка: {fmt_sub(uid)}\n"
        f"📊 Статус: {'Заблокирован' if user.get('banned') else 'Активен'}\n\n"
        f"📱 <b>Конфигураций (сессий): {len(sessions)}</b>\n"
        f"{session_text}\n\n"
        f"📨 Всего отправлено сообщений: {user.get('messages_sent', 0)}"
    )


def _format_top_users(title: str, users: list, count_key: str) -> str:
    if not users:
        return f"{title}\n\nПока нет данных для отображения."

    lines = [title, ""]
    for index, user in enumerate(users, 1):
        status = "🔴" if user.get("banned") else "🟢"
        name = _user_label(user)
        count = user.get(count_key, 0)
        sessions = user.get("session_count", 0)
        lines.append(
            f"{index}. {status} <code>{user['user_id']}</code> — {name}\n"
            f"   📨 {count} сообщений · 📱 сессий: {sessions}"
        )
    return "\n".join(lines)


async def cb_adm_users(cb: types.CallbackQuery):
    if not admin_check(cb):
        return await cb.answer("❌", show_alert=True)
    await safe_edit(cb.message, "👥 <b>Управление пользователями</b>", reply_markup=kb.adm_users_kb())
    await cb.answer()


async def cb_adm_user_list(cb: types.CallbackQuery):
    if not admin_check(cb):
        return await cb.answer("❌", show_alert=True)
    users = db.get_all_users()
    if not users:
        await cb.answer("Пользователей нет", show_alert=True)
        return
    text = "👥 <b>Пользователи:</b>\n\n"
    for u in users[:30]:
        ban = "🔴" if u.get("banned") else "🟢"
        uname = f"@{escape(str(u['username']))}" if u.get("username") else escape(str(u.get("first_name") or "—"))
        sub = "✅" if db.has_subscription(u["user_id"]) else "❌"
        text += f"{ban} <code>{u['user_id']}</code> {uname} {sub}\n"
    if len(users) > 30:
        text += f"\n…и ещё {len(users)-30}"
    await safe_edit(cb.message, text, reply_markup=kb.kb(kb.back("adm_users")))
    await cb.answer()


async def cb_adm_user_top(cb: types.CallbackQuery):
    if not admin_check(cb):
        return await cb.answer("❌", show_alert=True)
    users = db.get_top_users_by_messages(20)
    text = _format_top_users("🏆 <b>Топ активных пользователей</b>", users, "messages_sent")
    await safe_edit(cb.message, text, reply_markup=kb.kb(kb.back("adm_users")))
    await cb.answer()


async def cb_adm_user_top_24h(cb: types.CallbackQuery):
    if not admin_check(cb):
        return await cb.answer("❌", show_alert=True)
    users = db.get_top_users_last_24h(20)
    text = _format_top_users("🕘 <b>Топ пользователей за последние 24 часа</b>", users, "messages_24h")
    await safe_edit(cb.message, text, reply_markup=kb.kb(kb.back("adm_users")))
    await cb.answer()


async def cb_adm_user_search(cb: types.CallbackQuery, state: FSMContext):
    if not admin_check(cb):
        return await cb.answer("❌", show_alert=True)
    await state.set_state(States.adm_user_search)
    await safe_edit(cb.message, "🔍 Введите ID пользователя:",
                    reply_markup=kb.kb(kb.back("adm_users")))
    await cb.answer()


async def _show_user_card_message(message: types.Message, user_id: int, edit: bool = False):
    user = db.get_user(user_id)
    if not user:
        if edit:
            await safe_edit(message, "Пользователь не найден", reply_markup=kb.kb(kb.back("adm_users")))
        else:
            await message.answer("Пользователь не найден", reply_markup=kb.kb(kb.back("adm_users")))
        return

    sessions = db.get_sessions(user_id)
    text = _format_user_card(user, sessions)
    markup = kb.adm_user_detail_kb(user_id, sessions)
    if edit:
        await safe_edit(message, text, reply_markup=markup)
    else:
        await message.answer(text, parse_mode="HTML", reply_markup=markup)


async def state_adm_user_search(message: types.Message, state: FSMContext):
    if not db.is_admin(message.from_user.id):
        return
    raw = (message.text or "").strip()
    if not raw.isdigit():
        await message.answer("❌ Введите числовой ID")
        return
    await state.clear()
    await _show_user_card_message(message, int(raw))


async def cb_adm_user_view(cb: types.CallbackQuery):
    if not admin_check(cb):
        return await cb.answer("❌", show_alert=True)
    user_id = int(cb.data.split(":")[1])
    await _show_user_card_message(cb.message, user_id, edit=True)
    await cb.answer()


async def _format_session_card(session: dict) -> str:
    user = db.get_user(session["user_id"]) or {"user_id": session["user_id"]}
    processes = db.get_processes(session["user_id"])
    running = any(
        session["id"] in p.get("session_ids", []) and broadcaster.is_running(p["id"])
        for p in processes
    )
    if not session.get("is_active"):
        status = "Удалена"
    else:
        status = "Работает" if running else "Стоит"

    username = session.get("tg_username") or "—"
    return (
        f"📱 <b>Информация о сессии {session['id']}</b>\n\n"
        f"👤 Владелец: <code>{user['user_id']}</code> — {_user_label(user)}\n"
        f"🏷 Название: <b>{escape(str(session.get('name') or 'Без названия'))}</b>\n"
        f"📊 Статус: {status}\n"
        f"🆔 Telegram ID: <code>{session.get('tg_id') or '—'}</code>\n"
        f"📛 Username: @{escape(str(username))}\n"
        f"📞 Телефон: {escape(str(session.get('phone') or '—'))}\n"
        f"🔑 API ID: <code>{escape(str(db.get_setting('api_id', '—')))}</code>\n"
        f"📨 Отправлено: {session.get('messages_sent', 0)}\n"
        f"🕐 Последний запуск: {session.get('last_run') or '—'}"
    )


async def cb_adm_session_view(cb: types.CallbackQuery):
    if not admin_check(cb):
        return await cb.answer("❌", show_alert=True)
    session_id = int(cb.data.split(":")[1])
    session = db.get_session(session_id)
    if not session:
        await cb.answer("Сессия не найдена", show_alert=True)
        return
    text = await _format_session_card(session)
    await safe_edit(
        cb.message,
        text,
        reply_markup=kb.kb(
            [kb.btn("👤 Открыть пользователя", f"adm_user_view:{session['user_id']}")],
            kb.back("adm_users"),
        ),
    )
    await cb.answer()


async def cb_adm_session_search(cb: types.CallbackQuery, state: FSMContext):
    if not admin_check(cb):
        return await cb.answer("❌", show_alert=True)
    await state.set_state(States.adm_session_search)
    await safe_edit(
        cb.message,
        "🔎 Введите ID сессии из базы данных (число):",
        reply_markup=kb.kb(kb.back("adm_users")),
    )
    await cb.answer()


async def state_adm_session_search(message: types.Message, state: FSMContext):
    if not db.is_admin(message.from_user.id):
        return
    raw = (message.text or "").strip()
    if not raw.isdigit():
        await message.answer("❌ ID сессии должен быть числом")
        return
    session = db.get_session(int(raw))
    if not session:
        await message.answer("❌ Сессия с таким ID не найдена")
        return

    await state.clear()
    text = await _format_session_card(session)
    await message.answer(
        text,
        parse_mode="HTML",
        reply_markup=kb.kb(
            [kb.btn("👤 Открыть пользователя", f"adm_user_view:{session['user_id']}")],
            kb.back("adm_users"),
        ),
    )


async def cb_adm_user_ban(cb: types.CallbackQuery, state: FSMContext):
    if not admin_check(cb):
        return await cb.answer("❌", show_alert=True)
    await state.set_state(States.adm_user_ban_id)
    await safe_edit(cb.message, "🚫 Введите ID пользователя для бана/разбана:",
                    reply_markup=kb.kb(kb.back("adm_users")))
    await cb.answer()


async def state_adm_user_ban_id(message: types.Message, state: FSMContext):
    if not db.is_admin(message.from_user.id):
        return
    if not message.text.strip().isdigit():
        await message.answer("❌ Введите числовой ID")
        return
    uid = int(message.text.strip())
    u = db.get_user(uid)
    if not u:
        await message.answer("Пользователь не найден")
        await state.clear()
        return
    new_ban = not u.get("banned", False)
    db.ban_user(uid, new_ban)
    await state.clear()
    status = "забанен 🔴" if new_ban else "разбанен 🟢"
    await message.answer(f"✅ Пользователь {uid} {status}", reply_markup=kb.kb(kb.back("adm_users")))


async def cb_adm_ban_user_id(cb: types.CallbackQuery):
    if not admin_check(cb):
        return await cb.answer("❌", show_alert=True)
    uid = int(cb.data.split(":")[1])
    u = db.get_user(uid)
    if not u:
        await cb.answer("Не найдено", show_alert=True)
        return
    new_ban = not u.get("banned", False)
    db.ban_user(uid, new_ban)
    status = "забанен 🔴" if new_ban else "разбанен 🟢"
    await cb.answer(f"✅ {uid} {status}", show_alert=True)


async def cb_adm_give_sub_single(cb: types.CallbackQuery, state: FSMContext):
    if not admin_check(cb):
        return await cb.answer("❌", show_alert=True)
    uid = int(cb.data.split(":")[1])
    _temp[cb.from_user.id] = {"sub_target": uid}
    await state.set_state(States.adm_give_sub_days)
    await safe_edit(cb.message, f"Введите количество дней для пользователя {uid}:",
                    reply_markup=kb.kb(kb.back("adm_users")))
    await cb.answer()


# ─── PAYMENT CHECKER ──────────────────────────────────────────────────────────

async def check_payments_loop(bot: Bot):
    """Периодически проверяет оплату счетов через CryptoBot API."""
    while True:
        try:
            cryptobot_token = db.get_setting("cryptobot_token")
            if cryptobot_token:
                pending = db.get_pending_invoices()
                for inv in pending:
                    try:
                        async with aiohttp.ClientSession() as session:
                            resp = await session.get(
                                "https://pay.crypt.bot/api/getInvoices",
                                headers={"Crypto-Pay-API-Token": cryptobot_token},
                                params={"invoice_ids": inv["invoice_id"]},
                                timeout=aiohttp.ClientTimeout(total=10),
                            )
                            result = await resp.json()

                        if result.get("ok"):
                            items = result["result"].get("items", [])
                            for item in items:
                                if str(item["invoice_id"]) == str(inv["invoice_id"]) and item["status"] == "paid":
                                    db.mark_invoice_paid(inv["invoice_id"])
                                    plan = db.get_plan(inv["plan_id"])
                                    if plan:
                                        db.add_sub_days(inv["user_id"], plan["days"])
                                        db.clear_user_discount(inv["user_id"])

                                    # Реферальное вознаграждение
                                    user = db.get_user(inv["user_id"])
                                    if user and user.get("referred_by"):
                                        referrer = user["referred_by"]
                                        ref_level = db.get_ref_level(referrer)
                                        pct = ref_level.get("pct", 0)
                                        if pct > 0:
                                            reward = inv["amount"] * pct / 100
                                            db.add_ref_reward(referrer, reward)

                                    try:
                                        await bot.send_message(
                                            inv["user_id"],
                                            f"✅ <b>Оплата получена!</b>\n\n"
                                            f"Подписка активирована на {plan['days'] if plan else '?'} дней.",
                                            parse_mode="HTML",
                                        )
                                    except Exception:
                                        pass
                    except Exception as e:
                        logger.warning(f"Ошибка проверки инвойса {inv.get('invoice_id')}: {e}")
        except Exception as e:
            logger.error(f"Ошибка цикла проверки платежей: {e}")

        await asyncio.sleep(30)


# ─── ROUTER SETUP ─────────────────────────────────────────────────────────────

def register_handlers(dp: Dispatcher):
    # /start
    dp.message.register(cmd_start, CommandStart())
    dp.message.register(cmd_promo, Command("promo"))

    # Navigation
    dp.callback_query.register(nav_main_menu, F.data == "main_menu")

    # Profile
    dp.callback_query.register(cb_profile, F.data == "profile")

    # Sessions
    dp.callback_query.register(cb_sessions, F.data == "sessions")
    dp.callback_query.register(cb_sess_add, F.data == "sess_add")
    dp.callback_query.register(cb_sess_open, F.data.startswith("sess_open:"))
    dp.callback_query.register(cb_sess_stats, F.data.startswith("sess_stats:"))
    dp.callback_query.register(cb_sess_rename, F.data.startswith("sess_rename:"))
    dp.callback_query.register(cb_sess_proxy, F.data.startswith("sess_proxy:"))
    dp.callback_query.register(cb_sess_delete, F.data.startswith("sess_delete:"))

    dp.message.register(state_sess_phone, States.sess_phone)
    dp.message.register(state_sess_code, States.sess_code)
    dp.message.register(state_sess_2fa, States.sess_2fa)
    dp.message.register(state_sess_name, States.sess_name)
    dp.message.register(state_sess_rename, States.sess_rename)
    dp.message.register(state_sess_proxy, States.sess_proxy)

    # Templates
    dp.callback_query.register(cb_templates, F.data == "templates")
    dp.callback_query.register(cb_tpl_create, F.data == "tpl_create")
    dp.callback_query.register(cb_tpl_svc, F.data.startswith("tpl_svc:"))
    dp.callback_query.register(cb_tpl_open, F.data.startswith("tpl_open:"))
    dp.callback_query.register(cb_tpl_rename, F.data.startswith("tpl_rename:"))
    dp.callback_query.register(cb_tpl_delete, F.data.startswith("tpl_delete:"))

    dp.message.register(state_tpl_name, States.tpl_name)

    # Broadcast texts
    dp.callback_query.register(cb_tpl_texts, F.data.startswith("tpl_texts:"))
    dp.callback_query.register(cb_tpl_texts_mode, F.data.startswith("tpl_texts_mode:"))
    dp.callback_query.register(cb_tpl_texts_alt, F.data.startswith("tpl_texts_alt:"))
    dp.callback_query.register(cb_tpl_texts_symbols, F.data.startswith("tpl_texts_symbols:"))
    dp.callback_query.register(cb_tpl_texts_add, F.data.startswith("tpl_texts_add:"))
    dp.callback_query.register(cb_tpl_texts_del, F.data.startswith("tpl_texts_del:"))
    dp.callback_query.register(cb_tpl_texts_clear, F.data.startswith("tpl_texts_clear:"))

    dp.message.register(state_tpl_texts_add, States.tpl_texts_add)
    dp.message.register(state_tpl_texts_del, States.tpl_texts_del)

    # Broadcast chats
    dp.callback_query.register(cb_tpl_chats, F.data.startswith("tpl_chats:"))
    dp.callback_query.register(cb_tpl_chats_rand, F.data.startswith("tpl_chats_rand:"))
    dp.callback_query.register(cb_tpl_chats_folder, F.data.startswith("tpl_chats_folder:"))
    dp.callback_query.register(cb_tpl_folder_session, F.data.startswith("tpl_folder_session:"))
    dp.callback_query.register(cb_tpl_folder_set, F.data.startswith("tpl_folder_set:"))
    dp.callback_query.register(cb_tpl_folder_clear, F.data.startswith("tpl_chats_folder_clear:"))
    dp.callback_query.register(cb_tpl_chats_add, F.data.startswith("tpl_chats_add:"))
    dp.callback_query.register(cb_tpl_chats_del, F.data.startswith("tpl_chats_del:"))
    dp.callback_query.register(cb_tpl_chats_clear, F.data.startswith("tpl_chats_clear:"))

    dp.message.register(state_tpl_chats_add, States.tpl_chats_add)
    dp.message.register(state_tpl_chats_del, States.tpl_chats_del)

    # Timings
    dp.callback_query.register(cb_tpl_timings, F.data.startswith("tpl_timings:"))
    dp.callback_query.register(cb_tpl_set_delay_msg, F.data.startswith("tpl_set_delay_msg:"))
    dp.callback_query.register(cb_tpl_set_delay_cycle, F.data.startswith("tpl_set_delay_cycle:"))

    dp.message.register(state_tpl_set_delay_msg, States.tpl_set_delay_msg)
    dp.message.register(state_tpl_set_delay_cycle, States.tpl_set_delay_cycle)

    # Chunks
    dp.callback_query.register(cb_tpl_chunks, F.data.startswith("tpl_chunks:"))
    dp.callback_query.register(cb_tpl_chunks_toggle, F.data.startswith("tpl_chunks_toggle:"))
    dp.callback_query.register(cb_tpl_set_chunk, F.data.startswith("tpl_set_chunk:"))

    dp.message.register(state_tpl_set_chunk, States.tpl_set_chunk)

    # Typing
    dp.callback_query.register(cb_tpl_typing, F.data.startswith("tpl_typing:"))
    dp.callback_query.register(cb_tpl_typing_toggle, F.data.startswith("tpl_typing_toggle:"))
    dp.callback_query.register(cb_tpl_set_typing, F.data.startswith("tpl_set_typing:"))
    dp.callback_query.register(cb_tpl_autosub, F.data.startswith("tpl_autosub:"))
    dp.callback_query.register(cb_tpl_autosub_toggle, F.data.startswith("tpl_autosub_toggle:"))
    dp.callback_query.register(cb_tpl_autosub_action, F.data.startswith("tpl_autosub_action:"))
    dp.callback_query.register(cb_tpl_autosub_delay, F.data.startswith("tpl_autosub_delay:"))
    dp.callback_query.register(cb_tpl_repeats, F.data.startswith("tpl_repeats:"))
    dp.callback_query.register(cb_tpl_repeats_toggle, F.data.startswith("tpl_repeats_toggle:"))
    dp.callback_query.register(cb_tpl_repeats_set, F.data.startswith("tpl_repeats_set:"))

    dp.message.register(state_tpl_set_typing, States.tpl_set_typing)
    dp.message.register(state_tpl_repeats, States.tpl_repeats)
    dp.message.register(state_tpl_autosub_delay, States.tpl_autosub_delay)

    # Autochecker
    dp.callback_query.register(cb_tpl_autochecker, F.data.startswith("tpl_autochecker:"))
    dp.callback_query.register(cb_tpl_ac_source, F.data.startswith("tpl_ac_source:"))
    dp.callback_query.register(cb_tpl_ac_source_toggle, F.data.startswith("tpl_ac_source_toggle:"))
    dp.callback_query.register(cb_tpl_ac_where, F.data.startswith("tpl_ac_where:"))
    dp.callback_query.register(cb_tpl_ac_where_set, F.data.startswith("tpl_ac_where_set:"))
    dp.callback_query.register(cb_tpl_ac_folder, F.data.startswith("tpl_ac_folder:"))
    dp.callback_query.register(cb_tpl_ac_folder_session, F.data.startswith("tpl_ac_folder_session:"))
    dp.callback_query.register(cb_tpl_ac_folder_set, F.data.startswith("tpl_ac_folder_set:"))
    dp.callback_query.register(cb_tpl_ac_chats_add, F.data.startswith("tpl_ac_chats_add:"))
    dp.callback_query.register(cb_tpl_ac_chats_clear, F.data.startswith("tpl_ac_chats_clear:"))
    dp.callback_query.register(cb_tpl_ac_daily, F.data.startswith("tpl_ac_daily:"))
    dp.callback_query.register(cb_tpl_ac_attempts, F.data.startswith("tpl_ac_attempts:"))

    # Autoresponder
    dp.callback_query.register(cb_tpl_ar_who, F.data.startswith("tpl_ar_who:"))
    dp.callback_query.register(cb_tpl_ar_who_set, F.data.startswith("tpl_ar_who_set:"))
    dp.callback_query.register(cb_tpl_ar_reply, F.data.startswith("tpl_ar_reply:"))
    dp.callback_query.register(cb_tpl_ar_cd, F.data.startswith("tpl_ar_cd:"))

    dp.message.register(state_tpl_ac_chats, States.tpl_ac_chats)
    dp.message.register(state_tpl_ac_daily, States.tpl_ac_daily)
    dp.message.register(state_tpl_ac_attempts, States.tpl_ac_attempts)

    dp.message.register(state_tpl_ar_reply, States.tpl_ar_reply_wait, F.content_type.in_(
        {"text", "photo", "animation", "sticker", "video"}))
    dp.message.register(state_tpl_ar_cd, States.tpl_ar_cd)

    # Triggerbot
    dp.callback_query.register(cb_tpl_tb_where, F.data.startswith("tpl_tb_where:"))
    dp.callback_query.register(cb_tpl_tb_where_set, F.data.startswith("tpl_tb_where_set:"))
    dp.callback_query.register(cb_tpl_tb_chats_add, F.data.startswith("tpl_tb_chats_add:"))
    dp.callback_query.register(cb_tpl_tb_triggers, F.data.startswith("tpl_tb_triggers:"))
    dp.callback_query.register(cb_tpl_tb_trig_add, F.data.startswith("tpl_tb_trig_add:"))
    dp.callback_query.register(cb_tpl_tb_trig_open, F.data.startswith("tpl_tb_trig_open:"))
    dp.callback_query.register(cb_tpl_tb_trig_edit, F.data.startswith("tpl_tb_trig_edit:"))
    dp.callback_query.register(cb_tpl_tb_trig_del, F.data.startswith("tpl_tb_trig_del:"))

    dp.message.register(state_tpl_tb_chats_add, States.tpl_tb_chats_add)
    dp.message.register(state_tpl_tb_trig_kw, States.tpl_tb_trig_kw)
    dp.message.register(state_tpl_tb_trig_reply, States.tpl_tb_trig_reply, F.content_type.in_(
        {"text", "photo", "animation", "sticker", "video"}))

    # Processes
    dp.callback_query.register(cb_processes, F.data == "processes")
    dp.callback_query.register(cb_proc_create, F.data == "proc_create")
    dp.callback_query.register(cb_proc_svc, F.data.startswith("proc_svc:"))
    dp.callback_query.register(cb_proc_open, F.data.startswith("proc_open:"))
    dp.callback_query.register(cb_proc_accounts, F.data.startswith("proc_accounts:"))
    dp.callback_query.register(cb_proc_acc_toggle, F.data.startswith("proc_acc_toggle:"))
    dp.callback_query.register(cb_proc_acc_save, F.data.startswith("proc_acc_save:"))
    dp.callback_query.register(cb_proc_template, F.data.startswith("proc_template:"))
    dp.callback_query.register(cb_proc_tpl_toggle, F.data.startswith("proc_tpl_toggle:"))
    dp.callback_query.register(cb_proc_tpl_save, F.data.startswith("proc_tpl_save:"))
    dp.callback_query.register(cb_proc_work, F.data.startswith("proc_work:"))
    dp.callback_query.register(cb_proc_work_mode, F.data.startswith("proc_work_mode:"))
    dp.callback_query.register(cb_proc_work_set, F.data.startswith("proc_work_set:"))
    dp.callback_query.register(cb_proc_flood, F.data.startswith("proc_flood:"))
    dp.callback_query.register(cb_proc_flood_toggle, F.data.startswith("proc_flood_toggle:"))
    dp.callback_query.register(cb_proc_flood_set, F.data.startswith("proc_flood_set:"))
    dp.callback_query.register(cb_proc_slow, F.data.startswith("proc_slow:"))
    dp.callback_query.register(cb_proc_slow_toggle, F.data.startswith("proc_slow_toggle:"))
    dp.callback_query.register(cb_proc_slow_mode, F.data.startswith("proc_slow_mode:"))
    dp.callback_query.register(cb_proc_slow_set, F.data.startswith("proc_slow_set:"))
    dp.callback_query.register(cb_proc_logs, F.data.startswith("proc_logs:"))
    dp.callback_query.register(cb_proc_set_log, F.data.startswith("proc_set_log:"))
    dp.callback_query.register(cb_proc_start, F.data.startswith("proc_start:"))
    dp.callback_query.register(cb_proc_stop, F.data.startswith("proc_stop:"))
    dp.callback_query.register(cb_proc_delete, F.data.startswith("proc_delete:"))

    dp.message.register(state_proc_name, States.proc_name)
    dp.message.register(state_proc_flood_input, States.proc_flood_input)
    dp.message.register(state_proc_work_input, States.proc_work_input)
    dp.message.register(state_proc_slow_input, States.proc_slow_input)

    # Functions
    dp.callback_query.register(cb_functions, F.data == "functions")

    # Promo input
    dp.callback_query.register(cb_promo_enter, F.data == "promo_enter")
    dp.message.register(state_promo_code, States.promo_code)

    # Subscriptions
    dp.callback_query.register(cb_subscriptions, F.data == "subscriptions")
    dp.callback_query.register(cb_sub_buy, F.data.startswith("sub_buy:"))

    # Referral
    dp.callback_query.register(cb_referral, F.data == "referral")
    dp.callback_query.register(cb_ref_withdraw, F.data == "ref_withdraw")
    dp.message.register(state_ref_withdraw, States.ref_withdraw)

    # Support / Channel
    dp.callback_query.register(cb_support, F.data == "support")
    dp.callback_query.register(cb_channel, F.data == "channel")

    # Admin
    dp.callback_query.register(cb_admin_menu, F.data == "admin_menu")
    dp.callback_query.register(cb_adm_statistics, F.data == "adm_statistics")
    dp.callback_query.register(cb_adm_settings, F.data == "adm_settings")
    dp.callback_query.register(cb_adm_set_api, F.data == "adm_set_api")
    dp.callback_query.register(cb_adm_set_links, F.data == "adm_set_links")
    dp.callback_query.register(cb_adm_link, F.data.in_({
        "adm_link_channel", "adm_link_support",
        "adm_link_func_broadcast", "adm_link_func_ar", "adm_link_func_tb",
        "adm_link_func_autochecker"
    }))
    dp.callback_query.register(cb_adm_media_limits, F.data == "adm_media_limits")
    dp.callback_query.register(cb_adm_media_toggle, F.data == "adm_media_toggle")
    dp.callback_query.register(cb_adm_media_set, F.data.in_({
        "adm_media_photo", "adm_media_gif", "adm_media_video_size", "adm_media_video_dur"
    }))
    dp.callback_query.register(cb_adm_subs, F.data == "adm_subs")
    dp.callback_query.register(cb_adm_plans, F.data == "adm_plans")
    dp.callback_query.register(cb_adm_plan_create, F.data == "adm_plan_create")
    dp.callback_query.register(cb_adm_plan_edit, F.data.startswith("adm_plan_edit:"))
    dp.callback_query.register(cb_adm_plan_discount, F.data.startswith("adm_plan_discount:"))
    dp.callback_query.register(cb_adm_plan_delete, F.data.startswith("adm_plan_delete:"))
    dp.callback_query.register(cb_adm_give_sub, F.data == "adm_give_sub")
    dp.callback_query.register(cb_adm_give_sub_all, F.data == "adm_give_sub_all")
    dp.callback_query.register(cb_adm_give_sub_id, F.data == "adm_give_sub_id")
    dp.callback_query.register(cb_adm_take_sub, F.data == "adm_take_sub")
    dp.callback_query.register(cb_adm_cryptobot, F.data == "adm_cryptobot")
    dp.callback_query.register(cb_adm_ref, F.data == "adm_ref")
    dp.callback_query.register(cb_adm_ref_toggle, F.data == "adm_ref_toggle")
    dp.callback_query.register(cb_adm_ref_levels, F.data == "adm_ref_levels")
    dp.callback_query.register(cb_adm_promos, F.data == "adm_promos")
    dp.callback_query.register(cb_adm_promo_create, F.data == "adm_promo_create")
    dp.callback_query.register(cb_promo_type, F.data.startswith("promo_type:"))
    dp.callback_query.register(cb_adm_promo_list, F.data == "adm_promo_list")
    dp.callback_query.register(cb_adm_promo_delete, F.data.startswith("adm_promo_delete:"))
    dp.callback_query.register(cb_adm_admins, F.data == "adm_admins")
    dp.callback_query.register(cb_adm_admin_add, F.data == "adm_admin_add")
    dp.callback_query.register(cb_adm_admin_remove, F.data == "adm_admin_remove")
    dp.callback_query.register(cb_adm_admin_list, F.data == "adm_admin_list")
    dp.callback_query.register(cb_adm_broadcast, F.data == "adm_broadcast")
    dp.callback_query.register(cb_adm_users, F.data == "adm_users")
    dp.callback_query.register(cb_adm_user_list, F.data == "adm_user_list")
    dp.callback_query.register(cb_adm_user_top, F.data == "adm_user_top")
    dp.callback_query.register(cb_adm_user_top_24h, F.data == "adm_user_top_24h")
    dp.callback_query.register(cb_adm_user_search, F.data == "adm_user_search")
    dp.callback_query.register(cb_adm_user_view, F.data.startswith("adm_user_view:"))
    dp.callback_query.register(cb_adm_session_search, F.data == "adm_session_search")
    dp.callback_query.register(cb_adm_session_view, F.data.startswith("adm_session_view:"))
    dp.callback_query.register(cb_adm_user_ban, F.data == "adm_user_ban")
    dp.callback_query.register(cb_adm_ban_user_id, F.data.startswith("adm_ban_user_id:"))
    dp.callback_query.register(cb_adm_give_sub_single, F.data.startswith("adm_give_sub_single:"))

    # FSM states for admin
    dp.message.register(state_adm_api_id, States.adm_api_id)
    dp.message.register(state_adm_api_hash, States.adm_api_hash)
    dp.message.register(state_adm_broadcast_text, States.adm_broadcast_text)
    dp.message.register(state_adm_give_sub_id, States.adm_give_sub_id)
    dp.message.register(state_adm_give_sub_days, States.adm_give_sub_days)
    dp.message.register(state_adm_take_sub_id, States.adm_take_sub_id)
    dp.message.register(state_adm_take_sub_days, States.adm_take_sub_days)
    dp.message.register(state_adm_plan_name, States.adm_plan_name)
    dp.message.register(state_adm_plan_days, States.adm_plan_days)
    dp.message.register(state_adm_plan_price, States.adm_plan_price)
    dp.message.register(state_adm_plan_discount, States.adm_plan_discount)
    dp.message.register(state_adm_plan_discount_until, States.adm_plan_discount_until)
    dp.message.register(state_adm_promo_code, States.adm_promo_code)
    dp.message.register(state_adm_promo_value, States.adm_promo_value)
    dp.message.register(state_adm_promo_uses, States.adm_promo_uses)
    dp.message.register(state_adm_promo_activation, States.adm_promo_activation)
    dp.message.register(state_adm_promo_discount_duration, States.adm_promo_discount_duration)
    dp.message.register(state_adm_admin_add, States.adm_admin_add)
    dp.message.register(state_adm_admin_remove, States.adm_admin_remove)
    dp.message.register(state_adm_link, States.adm_link)
    dp.message.register(state_adm_media_val, States.adm_media_val)
    dp.message.register(state_adm_ref_level_count, States.adm_ref_level_count)
    dp.message.register(state_adm_ref_level_data, States.adm_ref_level_data)
    dp.message.register(state_adm_cryptobot_token, States.adm_cryptobot_token)
    dp.message.register(state_adm_user_search, States.adm_user_search)
    dp.message.register(state_adm_session_search, States.adm_session_search)
    dp.message.register(state_adm_user_ban_id, States.adm_user_ban_id)

    # Catch-all for unhandled callbacks
    dp.callback_query.register(cb_unknown)


async def cb_unknown(cb: types.CallbackQuery):
    try:
        await cb.answer()
    except Exception:
        pass


# ─── MAIN ─────────────────────────────────────────────────────────────────────

async def main():
    settings = load_settings()
    bot_token = settings.get("BOT_TOKEN", "").strip()
    owner_id_str = settings.get("OWNER_ID", "").strip()

    if not bot_token or bot_token == "YOUR_BOT_TOKEN_HERE":
        print("❌ Укажите BOT_TOKEN в файле settings.txt")
        return

    # Init DB
    db.init_db()

    # Add owner
    if owner_id_str.isdigit():
        owner_id = int(owner_id_str)
        db.add_admin(owner_id, is_owner=True)
        db.ensure_user(owner_id)
        # Save bot username if not set
        if not db.get_setting("bot_username"):
            db.set_setting("bot_username", "your_bot")

    bot = Bot(token=bot_token)
    payment_task = None

    try:
        storage = MemoryStorage()
        dp = Dispatcher(storage=storage)

        # Register handlers
        register_handlers(dp)

        # Resume active processes
        await broadcaster.resume_processes(bot_token)

        # Start payment checker and keep a reference for clean shutdown.
        payment_task = asyncio.create_task(check_payments_loop(bot))

        # Try to get bot username
        try:
            me = await bot.get_me()
            db.set_setting("bot_username", me.username)
            logger.info(f"Бот запущен: @{me.username}")
        except Exception as e:
            logger.warning(f"Не удалось получить username бота: {e}")

        logger.info("Начало поллинга...")
        await dp.start_polling(bot, allowed_updates=["message", "callback_query"])
    finally:
        if payment_task is not None:
            payment_task.cancel()
            await asyncio.gather(payment_task, return_exceptions=True)

        # Задачи останавливаем, но флаг is_running сохраняем.
        # После следующего запуска main() вызовет resume_processes().
        await broadcaster.stop_all(preserve_running_state=True)
        await bot.session.close()


if __name__ == "__main__":
    asyncio.run(main())
