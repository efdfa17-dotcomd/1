"""
database.py — SQLite база данных через встроенный sqlite3.
Все операции синхронные, вызываются через asyncio.to_thread для неблокирующей работы.
"""

import sqlite3
import os
import threading
import json
import random
import string
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any, Tuple

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "bot_data.db")

_local = threading.local()


def get_conn() -> sqlite3.Connection:
    if not hasattr(_local, "conn") or _local.conn is None:
        _local.conn = sqlite3.connect(DB_PATH, check_same_thread=False, timeout=30)
        _local.conn.row_factory = sqlite3.Row
        _local.conn.execute("PRAGMA journal_mode=WAL")
        _local.conn.execute("PRAGMA busy_timeout=30000")
        _local.conn.execute("PRAGMA foreign_keys=ON")
        _local.conn.execute("PRAGMA synchronous=NORMAL")
        _local.conn.execute("PRAGMA temp_store=MEMORY")
    return _local.conn


def init_db():
    conn = get_conn()
    c = conn.cursor()

    # Пользователи
    c.execute("""
        CREATE TABLE IF NOT EXISTS users (
            user_id      INTEGER PRIMARY KEY,
            username     TEXT,
            first_name   TEXT,
            ref_code     TEXT UNIQUE,
            referred_by  INTEGER,
            banned       INTEGER DEFAULT 0,
            created_at   TEXT DEFAULT (datetime('now')),
            sub_until    TEXT,
            ref_balance  REAL DEFAULT 0.0,
            ref_paid     INTEGER DEFAULT 0,
            ref_clicks   INTEGER DEFAULT 0,
            messages_sent INTEGER DEFAULT 0,
            promo_discount_pct INTEGER DEFAULT 0,
            promo_discount_until TEXT,
            FOREIGN KEY (referred_by) REFERENCES users(user_id)
        )
    """)

    # Уникальные переходы по реферальной ссылке: один Telegram user_id
    # учитывается только один раз за всё время.
    c.execute("""
        CREATE TABLE IF NOT EXISTS referral_visits (
            visitor_id  INTEGER PRIMARY KEY,
            referrer_id INTEGER NOT NULL,
            ref_code    TEXT NOT NULL,
            created_at  TEXT DEFAULT (datetime('now')),
            FOREIGN KEY (visitor_id) REFERENCES users(user_id),
            FOREIGN KEY (referrer_id) REFERENCES users(user_id)
        )
    """)

    # Сессии (Pyrogram)
    c.execute("""
        CREATE TABLE IF NOT EXISTS sessions (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id      INTEGER NOT NULL,
            name         TEXT NOT NULL,
            phone        TEXT,
            tg_id        INTEGER,
            tg_username  TEXT,
            proxy_host   TEXT,
            proxy_port   INTEGER,
            proxy_login  TEXT,
            proxy_pass   TEXT,
            proxy_scheme TEXT DEFAULT 'socks5',
            is_active    INTEGER DEFAULT 1,
            created_at   TEXT DEFAULT (datetime('now')),
            messages_sent INTEGER DEFAULT 0,
            last_run     TEXT,
            FOREIGN KEY (user_id) REFERENCES users(user_id)
        )
    """)

    # Шаблоны
    c.execute("""
        CREATE TABLE IF NOT EXISTS templates (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id      INTEGER NOT NULL,
            name         TEXT NOT NULL,
            service      TEXT NOT NULL,
            data         TEXT NOT NULL DEFAULT '{}',
            created_at   TEXT DEFAULT (datetime('now')),
            FOREIGN KEY (user_id) REFERENCES users(user_id)
        )
    """)

    # Процессы
    c.execute("""
        CREATE TABLE IF NOT EXISTS processes (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id      INTEGER NOT NULL,
            name         TEXT NOT NULL,
            service      TEXT NOT NULL,
            template_id  INTEGER,
            template_ids TEXT DEFAULT '[]',
            session_ids  TEXT DEFAULT '[]',
            log_level    TEXT DEFAULT 'errors',
            flood_settings TEXT DEFAULT '{}',
            slowdown_settings TEXT DEFAULT '{}',
            work_settings TEXT DEFAULT '{}',
            is_running   INTEGER DEFAULT 0,
            created_at   TEXT DEFAULT (datetime('now')),
            FOREIGN KEY (user_id) REFERENCES users(user_id),
            FOREIGN KEY (template_id) REFERENCES templates(id)
        )
    """)

    # Миграция существующих БД: старые процессы имели только template_id.
    try:
        c.execute("ALTER TABLE processes ADD COLUMN template_ids TEXT DEFAULT '[]'")
    except sqlite3.OperationalError:
        pass
    for column, definition in (("promo_discount_pct", "INTEGER DEFAULT 0"), ("promo_discount_until", "TEXT"), ("flood_settings", "TEXT DEFAULT '{}'"), ("slowdown_settings", "TEXT DEFAULT '{}'"), ("work_settings", "TEXT DEFAULT '{}'")):
        table = "users" if column in ("promo_discount_pct", "promo_discount_until") else "processes"
        try:
            c.execute(f"ALTER TABLE {table} ADD COLUMN {column} {definition}")
        except sqlite3.OperationalError:
            pass
    for column, definition in (("activation_until", "TEXT"), ("discount_seconds", "INTEGER DEFAULT 0")):
        try:
            c.execute(f"ALTER TABLE promo_codes ADD COLUMN {column} {definition}")
        except sqlite3.OperationalError:
            pass
    for column, definition in (("external_check_id", "TEXT"), ("check_url", "TEXT")):
        try:
            c.execute(f"ALTER TABLE withdrawals ADD COLUMN {column} {definition}")
        except sqlite3.OperationalError:
            pass

    # История отправленных сообщений для статистики за период.
    # Агрегаты users.messages_sent и sessions.messages_sent сохраняются
    # отдельно для быстрых общих показателей.
    c.execute("""
        CREATE TABLE IF NOT EXISTS message_events (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id     INTEGER NOT NULL,
            session_id  INTEGER,
            process_id  INTEGER,
            created_at  TEXT DEFAULT (datetime('now')),
            FOREIGN KEY (user_id) REFERENCES users(user_id),
            FOREIGN KEY (session_id) REFERENCES sessions(id),
            FOREIGN KEY (process_id) REFERENCES processes(id)
        )
    """)
    c.execute("CREATE INDEX IF NOT EXISTS idx_message_events_created_at ON message_events(created_at)")
    c.execute("CREATE INDEX IF NOT EXISTS idx_message_events_user_created ON message_events(user_id, created_at)")

    # Успешно активированные чеки CryptoBot/@send.
    c.execute("""
        CREATE TABLE IF NOT EXISTS check_events (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id     INTEGER NOT NULL,
            session_id  INTEGER NOT NULL,
            process_id  INTEGER,
            source      TEXT NOT NULL DEFAULT 'send',
            currency    TEXT NOT NULL,
            amount      REAL NOT NULL,
            created_at  TEXT DEFAULT (datetime('now')),
            link        TEXT,
            FOREIGN KEY (user_id) REFERENCES users(user_id),
            FOREIGN KEY (session_id) REFERENCES sessions(id),
            FOREIGN KEY (process_id) REFERENCES processes(id)
        )
    """)
    c.execute("CREATE INDEX IF NOT EXISTS idx_check_events_session_date ON check_events(session_id, created_at)")
    c.execute("CREATE INDEX IF NOT EXISTS idx_check_events_user_date ON check_events(user_id, created_at)")

    c.execute("""
        CREATE TABLE IF NOT EXISTS flood_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            process_id INTEGER NOT NULL,
            session_id INTEGER,
            seconds INTEGER NOT NULL,
            created_at TEXT DEFAULT (datetime('now')),
            FOREIGN KEY (process_id) REFERENCES processes(id),
            FOREIGN KEY (session_id) REFERENCES sessions(id)
        )
    """)
    c.execute("CREATE INDEX IF NOT EXISTS idx_flood_events_process_date ON flood_events(process_id, created_at)")

    # Настройки (глобальные)
    c.execute("""
        CREATE TABLE IF NOT EXISTS settings (
            key   TEXT PRIMARY KEY,
            value TEXT
        )
    """)

    # Тарифы подписки
    c.execute("""
        CREATE TABLE IF NOT EXISTS plans (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            name         TEXT NOT NULL,
            days         INTEGER NOT NULL,
            price_usd    REAL NOT NULL,
            discount_pct INTEGER DEFAULT 0,
            discount_until TEXT,
            is_active    INTEGER DEFAULT 1
        )
    """)

    # Промокоды
    c.execute("""
        CREATE TABLE IF NOT EXISTS promo_codes (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            code         TEXT UNIQUE NOT NULL,
            type         TEXT NOT NULL,
            value        INTEGER NOT NULL,
            uses_left    INTEGER NOT NULL,
            activation_until TEXT,
            discount_seconds INTEGER DEFAULT 0,
            created_at   TEXT DEFAULT (datetime('now'))
        )
    """)

    # Один активированный промокод каждого типа на пользователя.
    c.execute("""
        CREATE TABLE IF NOT EXISTS user_promo_uses (
            user_id INTEGER NOT NULL,
            promo_type TEXT NOT NULL,
            promo_id INTEGER NOT NULL,
            used_at TEXT DEFAULT (datetime('now')),
            PRIMARY KEY (user_id, promo_type),
            FOREIGN KEY (user_id) REFERENCES users(user_id)
        )
    """)
    # В ранней версии promo_id ошибочно был внешним ключом. Пересоздаём
    # таблицу без FK, сохраняя историю типа промокода пользователя.
    try:
        fks = c.execute("PRAGMA foreign_key_list(user_promo_uses)").fetchall()
        if any(row[2] == "promo_codes" for row in fks):
            c.execute("""CREATE TABLE user_promo_uses_new (
                user_id INTEGER NOT NULL, promo_type TEXT NOT NULL,
                promo_id INTEGER, used_at TEXT DEFAULT (datetime('now')),
                PRIMARY KEY(user_id, promo_type),
                FOREIGN KEY(user_id) REFERENCES users(user_id)
            )""")
            c.execute("INSERT OR IGNORE INTO user_promo_uses_new SELECT user_id,promo_type,promo_id,used_at FROM user_promo_uses")
            c.execute("DROP TABLE user_promo_uses")
            c.execute("ALTER TABLE user_promo_uses_new RENAME TO user_promo_uses")
    except sqlite3.OperationalError:
        pass

    # Реф. уровни
    c.execute("""
        CREATE TABLE IF NOT EXISTS ref_levels (
            level        INTEGER PRIMARY KEY,
            name         TEXT NOT NULL,
            required_ref INTEGER NOT NULL,
            pct          INTEGER NOT NULL
        )
    """)

    # Заявки на вывод
    c.execute("""
        CREATE TABLE IF NOT EXISTS withdrawals (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id      INTEGER NOT NULL,
            amount       REAL NOT NULL,
            status       TEXT DEFAULT 'pending',
            external_check_id TEXT,
            check_url    TEXT,
            created_at   TEXT DEFAULT (datetime('now')),
            FOREIGN KEY (user_id) REFERENCES users(user_id)
        )
    """)

    # Счета оплаты
    c.execute("""
        CREATE TABLE IF NOT EXISTS invoices (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id      INTEGER NOT NULL,
            plan_id      INTEGER NOT NULL,
            invoice_id   TEXT UNIQUE,
            amount       REAL NOT NULL,
            status       TEXT DEFAULT 'pending',
            created_at   TEXT DEFAULT (datetime('now')),
            FOREIGN KEY (user_id) REFERENCES users(user_id)
        )
    """)

    # Администраторы
    c.execute("""
        CREATE TABLE IF NOT EXISTS admins (
            user_id      INTEGER PRIMARY KEY,
            is_owner     INTEGER DEFAULT 0,
            added_at     TEXT DEFAULT (datetime('now'))
        )
    """)

    conn.commit()
    # История нужна для 24-часового рейтинга, но не должна бесконечно расти.
    prune_message_events(90)


# ─── HELPERS ───────────────────────────────────────────────────────────────────

def _gen_ref() -> str:
    return "ref_" + "".join(random.choices(string.ascii_letters + string.digits, k=8))


def _jdump(v) -> str:
    return json.dumps(v, ensure_ascii=False)


def _jload(v: str):
    try:
        return json.loads(v)
    except Exception:
        return {}


# ─── SETTINGS ─────────────────────────────────────────────────────────────────

def get_setting(key: str, default: Any = None) -> Any:
    row = get_conn().execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    if row is None:
        return default
    try:
        return json.loads(row[0])
    except Exception:
        return row[0]


def set_setting(key: str, value: Any):
    conn = get_conn()
    conn.execute(
        "INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        (key, json.dumps(value))
    )
    conn.commit()


# ─── ADMINS ───────────────────────────────────────────────────────────────────

def add_admin(user_id: int, is_owner: bool = False):
    conn = get_conn()
    conn.execute(
        "INSERT INTO admins(user_id,is_owner) VALUES(?,?) ON CONFLICT(user_id) DO UPDATE SET is_owner=excluded.is_owner",
        (user_id, 1 if is_owner else 0)
    )
    conn.commit()
    ensure_user(user_id)


def remove_admin(user_id: int):
    conn = get_conn()
    conn.execute("DELETE FROM admins WHERE user_id=? AND is_owner=0", (user_id,))
    conn.commit()


def is_admin(user_id: int) -> bool:
    row = get_conn().execute("SELECT 1 FROM admins WHERE user_id=?", (user_id,)).fetchone()
    return row is not None


def is_owner(user_id: int) -> bool:
    row = get_conn().execute("SELECT is_owner FROM admins WHERE user_id=?", (user_id,)).fetchone()
    return row is not None and bool(row[0])


def get_all_admins() -> List[Dict]:
    rows = get_conn().execute("SELECT user_id, is_owner, added_at FROM admins").fetchall()
    return [dict(r) for r in rows]


# ─── USERS ────────────────────────────────────────────────────────────────────

def ensure_user(user_id: int, username: str = None, first_name: str = None, ref_by: int = None):
    conn = get_conn()
    ref_code = _gen_ref()
    conn.execute(
        """INSERT INTO users(user_id, username, first_name, ref_code, referred_by)
           VALUES(?,?,?,?,?)
           ON CONFLICT(user_id) DO UPDATE SET
             username=COALESCE(excluded.username, users.username),
             first_name=COALESCE(excluded.first_name, users.first_name)
        """,
        (user_id, username, first_name, ref_code, ref_by)
    )
    conn.commit()


def get_user(user_id: int) -> Optional[Dict]:
    row = get_conn().execute("SELECT * FROM users WHERE user_id=?", (user_id,)).fetchone()
    return dict(row) if row else None


def ban_user(user_id: int, banned: bool):
    conn = get_conn()
    conn.execute("UPDATE users SET banned=? WHERE user_id=?", (1 if banned else 0, user_id))
    conn.commit()


def has_subscription(user_id: int) -> bool:
    row = get_conn().execute("SELECT sub_until FROM users WHERE user_id=?", (user_id,)).fetchone()
    if not row or not row[0]:
        return False
    try:
        return datetime.fromisoformat(row[0]) > datetime.utcnow()
    except Exception:
        return False


def sub_days_left(user_id: int) -> int:
    row = get_conn().execute("SELECT sub_until FROM users WHERE user_id=?", (user_id,)).fetchone()
    if not row or not row[0]:
        return 0
    try:
        delta = datetime.fromisoformat(row[0]) - datetime.utcnow()
        return max(0, delta.days)
    except Exception:
        return 0


def add_sub_days(user_id: int, days: int):
    conn = get_conn()
    row = conn.execute("SELECT sub_until FROM users WHERE user_id=?", (user_id,)).fetchone()
    if row and row[0]:
        try:
            current = datetime.fromisoformat(row[0])
            if current < datetime.utcnow():
                current = datetime.utcnow()
        except Exception:
            current = datetime.utcnow()
    else:
        current = datetime.utcnow()
    new_until = current + timedelta(days=days)
    conn.execute("UPDATE users SET sub_until=? WHERE user_id=?", (new_until.isoformat(), user_id))
    conn.commit()


def subtract_sub_days(user_id: int, days: int):
    conn = get_conn()
    row = conn.execute("SELECT sub_until FROM users WHERE user_id=?", (user_id,)).fetchone()
    if not row or not row[0]:
        return
    try:
        current = datetime.fromisoformat(row[0])
        new_until = current - timedelta(days=days)
        conn.execute("UPDATE users SET sub_until=? WHERE user_id=?", (new_until.isoformat(), user_id))
        conn.commit()
    except Exception:
        pass


def give_sub_to_all(days: int):
    conn = get_conn()
    rows = conn.execute("SELECT user_id FROM users WHERE sub_until IS NOT NULL AND sub_until != ''").fetchall()
    for row in rows:
        add_sub_days(row[0], days)


def get_all_users() -> List[Dict]:
    rows = get_conn().execute("SELECT * FROM users").fetchall()
    return [dict(r) for r in rows]


def get_user_by_ref(ref_code: str) -> Optional[Dict]:
    row = get_conn().execute("SELECT * FROM users WHERE ref_code=?", (ref_code,)).fetchone()
    return dict(row) if row else None


def increment_ref_click(ref_code: str):
    """Legacy helper. New code should use record_ref_visit()."""
    conn = get_conn()
    conn.execute("UPDATE users SET ref_clicks=ref_clicks+1 WHERE ref_code=?", (ref_code,))
    conn.commit()


def record_ref_visit(ref_code: str, visitor_id: int) -> bool:
    """Засчитывает переход только при первом визите пользователя."""
    conn = get_conn()
    referrer = conn.execute(
        "SELECT user_id FROM users WHERE ref_code=?", (ref_code,)
    ).fetchone()
    if not referrer or int(referrer[0]) == int(visitor_id):
        return False

    try:
        conn.execute(
            "INSERT INTO referral_visits(visitor_id,referrer_id,ref_code) VALUES(?,?,?)",
            (visitor_id, int(referrer[0]), ref_code),
        )
    except sqlite3.IntegrityError:
        return False

    conn.execute(
        "UPDATE users SET ref_clicks=ref_clicks+1 WHERE user_id=?",
        (int(referrer[0]),),
    )
    conn.commit()
    return True


def add_ref_reward(referrer_id: int, amount: float):
    conn = get_conn()
    conn.execute(
        "UPDATE users SET ref_balance=ref_balance+?, ref_paid=ref_paid+1 WHERE user_id=?",
        (amount, referrer_id)
    )
    conn.commit()


def get_ref_level(user_id: int) -> Dict:
    user = get_user(user_id)
    paid = user.get("ref_paid", 0) if user else 0
    levels = get_ref_levels()
    if not levels:
        return {"level": 1, "name": "Участник", "pct": 0, "next": None}
    current = levels[0]
    for lv in levels:
        if paid >= lv["required_ref"]:
            current = lv
    # find next level
    next_lv = None
    for lv in levels:
        if lv["level"] > current["level"]:
            next_lv = lv
            break
    return {"level": current["level"], "name": current["name"], "pct": current["pct"], "next": next_lv}


def withdraw_request(user_id: int, amount: float) -> bool:
    user = get_user(user_id)
    if not user or user.get("ref_balance", 0) < amount:
        return False
    conn = get_conn()
    conn.execute("UPDATE users SET ref_balance=ref_balance-? WHERE user_id=?", (amount, user_id))
    conn.execute("INSERT INTO withdrawals(user_id,amount) VALUES(?,?)", (user_id, amount))
    conn.commit()
    return True


def increment_messages_sent(
    user_id: int,
    count: int = 1,
    session_id: int = None,
    process_id: int = None,
):
    """Увеличивает общий счётчик и записывает события для статистики."""
    count = max(0, int(count))
    if count == 0:
        return

    conn = get_conn()
    conn.execute(
        "UPDATE users SET messages_sent=messages_sent+? WHERE user_id=?",
        (count, user_id),
    )
    conn.executemany(
        "INSERT INTO message_events(user_id,session_id,process_id) VALUES(?,?,?)",
        [(user_id, session_id, process_id)] * count,
    )
    conn.commit()


def record_message_sent(
    user_id: int,
    session_id: int,
    process_id: int = None,
    count: int = 1,
):
    """Атомарно обновляет счётчики аккаунта/пользователя и историю."""
    count = max(0, int(count))
    if count == 0:
        return

    conn = get_conn()
    conn.execute(
        "UPDATE users SET messages_sent=messages_sent+? WHERE user_id=?",
        (count, user_id),
    )
    conn.execute(
        """
        UPDATE sessions
        SET messages_sent=messages_sent+?, last_run=datetime('now')
        WHERE id=?
        """,
        (count, session_id),
    )
    conn.executemany(
        "INSERT INTO message_events(user_id,session_id,process_id) VALUES(?,?,?)",
        [(user_id, session_id, process_id)] * count,
    )
    conn.commit()


def get_top_users_by_messages(limit: int = 20) -> List[Dict]:
    """Топ пользователей по общему числу отправленных сообщений."""
    limit = max(1, min(int(limit), 100))
    rows = get_conn().execute(
        """
        SELECT u.user_id, u.username, u.first_name, u.banned,
               u.messages_sent,
               (SELECT COUNT(*) FROM sessions s
                WHERE s.user_id=u.user_id AND s.is_active=1) AS session_count
        FROM users u
        WHERE u.messages_sent > 0
        ORDER BY u.messages_sent DESC, u.user_id
        LIMIT ?
        """,
        (limit,),
    ).fetchall()
    return [dict(r) for r in rows]


def get_top_users_last_24h(limit: int = 20) -> List[Dict]:
    """Топ пользователей по событиям за последние 24 часа."""
    limit = max(1, min(int(limit), 100))
    rows = get_conn().execute(
        """
        SELECT u.user_id, u.username, u.first_name, u.banned,
               COUNT(e.id) AS messages_24h,
               u.messages_sent,
               (SELECT COUNT(*) FROM sessions s
                WHERE s.user_id=u.user_id AND s.is_active=1) AS session_count
        FROM message_events e
        JOIN users u ON u.user_id=e.user_id
        WHERE e.created_at >= datetime('now', '-24 hours')
        GROUP BY u.user_id, u.username, u.first_name, u.banned, u.messages_sent
        ORDER BY messages_24h DESC, u.user_id
        LIMIT ?
        """,
        (limit,),
    ).fetchall()
    return [dict(r) for r in rows]


def prune_message_events(days: int = 90):
    """Удаляет старую историю, чтобы служебная таблица не росла бесконечно."""
    days = max(2, int(days))
    conn = get_conn()
    conn.execute(
        "DELETE FROM message_events WHERE created_at < datetime('now', ?)",
        (f"-{days} days",),
    )
    conn.commit()


def create_ref_withdrawal(user_id: int, amount: float, check_id: str, check_url: str) -> bool:
    """Списывает весь баланс только после успешного создания CryptoBot-чека."""
    amount = float(amount)
    if amount < 1:
        return False
    conn = get_conn()
    cur = conn.execute(
        "UPDATE users SET ref_balance=ref_balance-? WHERE user_id=? AND ref_balance>=?",
        (amount, user_id, amount),
    )
    if cur.rowcount != 1:
        conn.rollback()
        return False
    conn.execute(
        "INSERT INTO withdrawals(user_id,amount,status,external_check_id,check_url) VALUES(?,?, 'created', ?, ?)",
        (user_id, amount, str(check_id), check_url),
    )
    conn.commit()
    return True


def record_check_success(
    user_id: int,
    session_id: int,
    currency: str,
    amount: float,
    process_id: int = None,
    link: str = None,
):
    conn = get_conn()
    conn.execute(
        """INSERT INTO check_events
           (user_id,session_id,process_id,source,currency,amount,link)
           VALUES(?,?,?,?,?,?,?)""",
        (user_id, session_id, process_id, "send", currency.upper(), float(amount), link),
    )
    conn.commit()


def get_daily_check_count(session_id: int) -> int:
    row = get_conn().execute(
        """SELECT COUNT(*) FROM check_events
           WHERE session_id=? AND created_at >= date('now')""",
        (session_id,),
    ).fetchone()
    return int(row[0] or 0)


def get_check_stats(user_id: int) -> List[Dict]:
    rows = get_conn().execute(
        """SELECT currency, COUNT(*) AS checks, SUM(amount) AS amount
           FROM check_events WHERE user_id=?
           GROUP BY currency ORDER BY amount DESC""",
        (user_id,),
    ).fetchall()
    return [dict(r) for r in rows]


def get_session_check_stats(session_id: int) -> List[Dict]:
    rows = get_conn().execute(
        """SELECT currency, COUNT(*) AS checks, SUM(amount) AS amount
           FROM check_events WHERE session_id=?
           GROUP BY currency ORDER BY amount DESC""",
        (session_id,),
    ).fetchall()
    return [dict(r) for r in rows]


def _promo_cleanup(conn):
    conn.execute("DELETE FROM promo_codes WHERE uses_left<=0 OR (activation_until IS NOT NULL AND activation_until <= datetime('now'))")


def redeem_promo(user_id: int, code: str):
    conn = get_conn()
    _promo_cleanup(conn)
    promo = conn.execute(
        "SELECT * FROM promo_codes WHERE code=? AND uses_left>0",
        (code.strip().upper(),),
    ).fetchone()
    if not promo:
        conn.commit()
        return False, "Промокод не найден, истёк или уже закончился"
    used = conn.execute(
        "SELECT 1 FROM user_promo_uses WHERE user_id=? AND promo_type=?",
        (user_id, promo["type"]),
    ).fetchone()
    if used:
        conn.commit()
        return False, "Вы уже использовали промокод этого типа"

    conn.execute(
        "INSERT INTO user_promo_uses(user_id,promo_type,promo_id) VALUES(?,?,?)",
        (user_id, promo["type"], promo["id"]),
    )
    if promo["type"] == "days":
        user = conn.execute("SELECT sub_until FROM users WHERE user_id=?", (user_id,)).fetchone()
        now = datetime.utcnow()
        current = now
        if user and user[0]:
            try:
                current = max(now, datetime.fromisoformat(user[0]))
            except Exception:
                current = now
        conn.execute(
            "UPDATE users SET sub_until=? WHERE user_id=?",
            ((current + timedelta(days=int(promo["value"]))).isoformat(), user_id),
        )
        result = f"Подписка продлена на {promo['value']} дн."
    elif promo["type"] == "discount":
        value = max(0, min(100, int(promo["value"])))
        duration = int(promo["discount_seconds"] or 0)
        until = None if duration <= 0 else (datetime.utcnow() + timedelta(seconds=duration)).isoformat()
        conn.execute("UPDATE users SET promo_discount_pct=?, promo_discount_until=? WHERE user_id=?", (value, until, user_id))
        result = f"Скидка {value}% применится после оплаты тарифа"
    else:
        conn.rollback()
        return False, "Неизвестный тип промокода"
    conn.execute("UPDATE promo_codes SET uses_left=uses_left-1 WHERE id=?", (promo["id"],))
    conn.commit()
    return True, result


def get_user_discount(user_id: int) -> int:
    row = get_conn().execute("SELECT promo_discount_pct, promo_discount_until FROM users WHERE user_id=?", (user_id,)).fetchone()
    if not row:
        return 0
    if row[1]:
        try:
            if datetime.fromisoformat(row[1]) <= datetime.utcnow():
                clear_user_discount(user_id)
                return 0
        except Exception:
            clear_user_discount(user_id)
            return 0
    return int(row[0] or 0)


def clear_user_discount(user_id: int):
    conn = get_conn()
    conn.execute("UPDATE users SET promo_discount_pct=0, promo_discount_until=NULL WHERE user_id=?", (user_id,))
    conn.commit()



def record_flood_event(process_id: int, session_id: int, seconds: int):
    conn = get_conn()
    conn.execute("INSERT INTO flood_events(process_id,session_id,seconds) VALUES(?,?,?)", (process_id, session_id, int(seconds)))
    conn.commit()


def count_flood_events(process_id: int, hours: int) -> int:
    row = get_conn().execute(
        "SELECT COUNT(*) FROM flood_events WHERE process_id=? AND created_at >= datetime('now', ?)",
        (process_id, f"-{max(1, int(hours))} hours"),
    ).fetchone()
    return int(row[0] or 0)


def get_admin_statistics() -> Dict[str, Any]:
    conn = get_conn()
    total_users = conn.execute("SELECT COUNT(*) FROM users").fetchone()[0]
    subscribed = conn.execute("SELECT COUNT(*) FROM users WHERE sub_until IS NOT NULL AND sub_until > datetime('now')").fetchone()[0]
    active_users = conn.execute("SELECT COUNT(DISTINCT user_id) FROM processes WHERE is_running=1").fetchone()[0]
    active_sessions = conn.execute("SELECT COUNT(*) FROM sessions WHERE is_active=1").fetchone()[0]
    total_messages = conn.execute("SELECT COALESCE(SUM(messages_sent),0) FROM sessions").fetchone()[0]
    referrals = conn.execute("SELECT COUNT(*) FROM users WHERE referred_by IS NOT NULL").fetchone()[0]

    # В invoices.amount уже хранится фактически созданная сумма счёта,
    # включая применённую скидку. Учитываем только оплаченные счета.
    subscription_revenue = conn.execute(
        "SELECT COALESCE(SUM(amount), 0) FROM invoices WHERE status='paid'"
    ).fetchone()[0]

    # Баланс уменьшается при создании заявки на вывод, поэтому полный доход
    # рефералов = текущие остатки + все суммы, уже заявленные к выводу.
    referral_withdrawn = conn.execute(
        "SELECT COALESCE(SUM(amount), 0) FROM withdrawals "
        "WHERE status IN ('created', 'pending', 'paid')"
    ).fetchone()[0]
    referral_balance = conn.execute(
        "SELECT COALESCE(SUM(ref_balance), 0) FROM users"
    ).fetchone()[0]
    referral_earned = referral_balance + referral_withdrawn

    return {
        "total_users": int(total_users),
        "subscribed": int(subscribed),
        "active_users": int(active_users),
        "active_sessions": int(active_sessions),
        "total_messages": int(total_messages),
        "referrals": int(referrals),
        "subscription_revenue": float(subscription_revenue or 0),
        "referral_earned": float(referral_earned or 0),
        "referral_withdrawn": float(referral_withdrawn or 0),
    }


# ─── SESSIONS ─────────────────────────────────────────────────────────────────

def add_session(user_id: int, name: str, phone: str, tg_id: int = None, tg_username: str = None) -> int:
    conn = get_conn()
    cur = conn.execute(
        "INSERT INTO sessions(user_id,name,phone,tg_id,tg_username) VALUES(?,?,?,?,?)",
        (user_id, name, phone, tg_id, tg_username)
    )
    conn.commit()
    return cur.lastrowid


def get_sessions(user_id: int) -> List[Dict]:
    rows = get_conn().execute("SELECT * FROM sessions WHERE user_id=? AND is_active=1", (user_id,)).fetchall()
    return [dict(r) for r in rows]


def get_session(session_id: int) -> Optional[Dict]:
    row = get_conn().execute("SELECT * FROM sessions WHERE id=?", (session_id,)).fetchone()
    return dict(row) if row else None


def rename_session(session_id: int, name: str):
    conn = get_conn()
    conn.execute("UPDATE sessions SET name=? WHERE id=?", (name, session_id))
    conn.commit()


def delete_session(session_id: int):
    conn = get_conn()
    conn.execute("UPDATE sessions SET is_active=0 WHERE id=?", (session_id,))
    conn.commit()


def set_session_proxy(session_id: int, host: str, port: int, login: str, password: str, scheme: str = "socks5"):
    conn = get_conn()
    conn.execute(
        "UPDATE sessions SET proxy_host=?,proxy_port=?,proxy_login=?,proxy_pass=?,proxy_scheme=? WHERE id=?",
        (host, port, login, password, scheme, session_id)
    )
    conn.commit()


def increment_session_messages(session_id: int, count: int = 1):
    conn = get_conn()
    conn.execute(
        "UPDATE sessions SET messages_sent=messages_sent+?, last_run=datetime('now') WHERE id=?",
        (count, session_id)
    )
    conn.commit()


def count_sessions(user_id: int) -> int:
    row = get_conn().execute("SELECT COUNT(*) FROM sessions WHERE user_id=? AND is_active=1", (user_id,)).fetchone()
    return row[0] if row else 0


# ─── TEMPLATES ────────────────────────────────────────────────────────────────

def create_template(user_id: int, name: str, service: str, data: dict = None) -> int:
    conn = get_conn()
    cur = conn.execute(
        "INSERT INTO templates(user_id,name,service,data) VALUES(?,?,?,?)",
        (user_id, name, service, _jdump(data or {}))
    )
    conn.commit()
    return cur.lastrowid


def get_templates(user_id: int) -> List[Dict]:
    rows = get_conn().execute("SELECT * FROM templates WHERE user_id=?", (user_id,)).fetchall()
    result = []
    for r in rows:
        d = dict(r)
        d["data"] = _jload(d["data"])
        result.append(d)
    return result


def get_template(template_id: int) -> Optional[Dict]:
    row = get_conn().execute("SELECT * FROM templates WHERE id=?", (template_id,)).fetchone()
    if not row:
        return None
    d = dict(row)
    d["data"] = _jload(d["data"])
    return d


def update_template_data(template_id: int, data: dict):
    conn = get_conn()
    conn.execute("UPDATE templates SET data=? WHERE id=?", (_jdump(data), template_id))
    conn.commit()


def rename_template(template_id: int, name: str):
    conn = get_conn()
    conn.execute("UPDATE templates SET name=? WHERE id=?", (name, template_id))
    conn.commit()


def delete_template(template_id: int):
    conn = get_conn()
    rows = conn.execute("SELECT id, template_id, template_ids FROM processes").fetchall()
    for row in rows:
        try:
            ids = json.loads(row[2] or "[]")
        except Exception:
            ids = []
        if row[1] != template_id and template_id not in ids:
            continue
        ids = [int(x) for x in ids if int(x) != int(template_id)]
        conn.execute(
            "UPDATE processes SET template_id=?, template_ids=? WHERE id=?",
            (ids[0] if ids else None, json.dumps(ids), row[0]),
        )
    conn.execute("DELETE FROM templates WHERE id=?", (template_id,))
    conn.commit()


# ─── PROCESSES ────────────────────────────────────────────────────────────────

def create_process(user_id: int, name: str, service: str) -> int:
    conn = get_conn()
    cur = conn.execute(
        "INSERT INTO processes(user_id,name,service) VALUES(?,?,?)",
        (user_id, name, service)
    )
    conn.commit()
    return cur.lastrowid


def _normalize_process(d: Dict) -> Dict:
    d["session_ids"] = json.loads(d.get("session_ids") or "[]")
    raw_templates = d.get("template_ids") or "[]"
    try:
        template_ids = json.loads(raw_templates)
    except Exception:
        template_ids = []
    if not template_ids and d.get("template_id"):
        template_ids = [d["template_id"]]
    d["template_ids"] = [int(x) for x in template_ids if str(x).isdigit()]
    for key in ("flood_settings", "slowdown_settings", "work_settings"):
        try:
            d[key] = json.loads(d.get(key) or "{}")
        except Exception:
            d[key] = {}
    return d


def get_processes(user_id: int) -> List[Dict]:
    rows = get_conn().execute("SELECT * FROM processes WHERE user_id=?", (user_id,)).fetchall()
    return [_normalize_process(dict(r)) for r in rows]


def get_process(process_id: int) -> Optional[Dict]:
    row = get_conn().execute("SELECT * FROM processes WHERE id=?", (process_id,)).fetchone()
    if not row:
        return None
    return _normalize_process(dict(row))


def update_process(process_id: int, **kwargs):
    conn = get_conn()
    if "session_ids" in kwargs:
        kwargs["session_ids"] = json.dumps(kwargs["session_ids"])
    if "template_ids" in kwargs:
        template_ids = [int(x) for x in kwargs["template_ids"]]
        kwargs["template_ids"] = json.dumps(template_ids)
        kwargs.setdefault("template_id", template_ids[0] if template_ids else None)
    for key in ("flood_settings", "slowdown_settings", "work_settings"):
        if key in kwargs:
            kwargs[key] = json.dumps(kwargs[key], ensure_ascii=False)
    sets = ", ".join(f"{k}=?" for k in kwargs)
    vals = list(kwargs.values()) + [process_id]
    conn.execute(f"UPDATE processes SET {sets} WHERE id=?", vals)
    conn.commit()


def delete_process(process_id: int):
    conn = get_conn()
    conn.execute("UPDATE message_events SET process_id=NULL WHERE process_id=?", (process_id,))
    conn.execute("UPDATE check_events SET process_id=NULL WHERE process_id=?", (process_id,))
    conn.execute("DELETE FROM processes WHERE id=?", (process_id,))
    conn.commit()


def set_process_running(process_id: int, running: bool):
    conn = get_conn()
    conn.execute("UPDATE processes SET is_running=? WHERE id=?", (1 if running else 0, process_id))
    conn.commit()


def get_all_running_processes() -> List[Dict]:
    rows = get_conn().execute("SELECT * FROM processes WHERE is_running=1").fetchall()
    return [_normalize_process(dict(r)) for r in rows]


# ─── PLANS ────────────────────────────────────────────────────────────────────

def get_plans() -> List[Dict]:
    rows = get_conn().execute("SELECT * FROM plans WHERE is_active=1 ORDER BY days").fetchall()
    return [dict(r) for r in rows]


def create_plan(name: str, days: int, price: float) -> int:
    conn = get_conn()
    cur = conn.execute("INSERT INTO plans(name,days,price_usd) VALUES(?,?,?)", (name, days, price))
    conn.commit()
    return cur.lastrowid


def update_plan(plan_id: int, **kwargs):
    conn = get_conn()
    sets = ", ".join(f"{k}=?" for k in kwargs)
    vals = list(kwargs.values()) + [plan_id]
    conn.execute(f"UPDATE plans SET {sets} WHERE id=?", vals)
    conn.commit()


def delete_plan(plan_id: int):
    conn = get_conn()
    conn.execute("UPDATE plans SET is_active=0 WHERE id=?", (plan_id,))
    conn.commit()


def get_plan(plan_id: int) -> Optional[Dict]:
    row = get_conn().execute("SELECT * FROM plans WHERE id=?", (plan_id,)).fetchone()
    return dict(row) if row else None


def effective_price(plan: Dict) -> float:
    price = plan["price_usd"]
    disc = plan.get("discount_pct", 0)
    if disc and disc > 0:
        until = plan.get("discount_until")
        if until:
            try:
                if datetime.fromisoformat(until) > datetime.utcnow():
                    price = price * (1 - disc / 100)
            except Exception:
                pass
        else:
            price = price * (1 - disc / 100)
    return round(price, 2)


# ─── PROMO CODES ──────────────────────────────────────────────────────────────

def create_promo(
    code: str,
    type_: str,
    value: int,
    uses: int,
    activation_seconds: int = 0,
    discount_seconds: int = 0,
) -> bool:
    conn = get_conn()
    _promo_cleanup(conn)
    try:
        activation_until = None if int(activation_seconds) <= 0 else (
            datetime.utcnow() + timedelta(seconds=int(activation_seconds))
        ).isoformat()
        conn.execute(
            """INSERT INTO promo_codes
               (code,type,value,uses_left,activation_until,discount_seconds)
               VALUES(?,?,?,?,?,?)""",
            (code.strip().upper(), type_, int(value), int(uses), activation_until, int(discount_seconds)),
        )
        conn.commit()
        return True
    except Exception:
        conn.rollback()
        return False


def get_promo(code: str) -> Optional[Dict]:
    conn = get_conn()
    _promo_cleanup(conn)
    row = conn.execute(
        "SELECT * FROM promo_codes WHERE code=? AND uses_left>0", (code.upper(),)
    ).fetchone()
    conn.commit()
    return dict(row) if row else None


def use_promo(code: str):
    conn = get_conn()
    conn.execute("UPDATE promo_codes SET uses_left=uses_left-1 WHERE code=?", (code.upper(),))
    conn.commit()


def delete_promo(promo_id: int):
    conn = get_conn()
    conn.execute("DELETE FROM promo_codes WHERE id=?", (promo_id,))
    conn.commit()


def get_all_promos() -> List[Dict]:
    conn = get_conn()
    _promo_cleanup(conn)
    rows = conn.execute("SELECT * FROM promo_codes WHERE uses_left>0 ORDER BY id DESC").fetchall()
    conn.commit()
    return [dict(r) for r in rows]


# ─── REF LEVELS ───────────────────────────────────────────────────────────────

def get_ref_levels() -> List[Dict]:
    rows = get_conn().execute("SELECT * FROM ref_levels ORDER BY level").fetchall()
    return [dict(r) for r in rows]


def set_ref_levels(levels: List[Dict]):
    conn = get_conn()
    conn.execute("DELETE FROM ref_levels")
    for lv in levels:
        conn.execute(
            "INSERT INTO ref_levels(level,name,required_ref,pct) VALUES(?,?,?,?)",
            (lv["level"], lv["name"], lv["required_ref"], lv["pct"])
        )
    conn.commit()


# ─── INVOICES ─────────────────────────────────────────────────────────────────

def create_invoice(user_id: int, plan_id: int, invoice_id: str, amount: float) -> int:
    conn = get_conn()
    cur = conn.execute(
        "INSERT INTO invoices(user_id,plan_id,invoice_id,amount) VALUES(?,?,?,?)",
        (user_id, plan_id, invoice_id, amount)
    )
    conn.commit()
    return cur.lastrowid


def get_invoice_by_external(invoice_id: str) -> Optional[Dict]:
    row = get_conn().execute("SELECT * FROM invoices WHERE invoice_id=?", (invoice_id,)).fetchone()
    return dict(row) if row else None


def mark_invoice_paid(invoice_id: str):
    conn = get_conn()
    conn.execute("UPDATE invoices SET status='paid' WHERE invoice_id=?", (invoice_id,))
    conn.commit()


def get_pending_invoices() -> List[Dict]:
    rows = get_conn().execute("SELECT * FROM invoices WHERE status='pending'").fetchall()
    return [dict(r) for r in rows]
