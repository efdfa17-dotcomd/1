"""
broadcaster.py — Движок рассылки, автоответчика и триггербота.
Запускается как asyncio.Task на каждый процесс.
"""

import asyncio
import json
import logging
import os
import random
import re
import time
from datetime import datetime
from urllib.parse import parse_qs, urlparse
from typing import Dict, Optional, Tuple

import aiohttp
from pyrogram import Client, errors, filters
from pyrogram.enums import ChatAction, ChatType
from pyrogram.types import Message as PyroMessage
from pyrogram.handlers import MessageHandler
from pyrogram.raw import functions as raw_functions

import database as db

logger = logging.getLogger(__name__)

SESSIONS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "sessions")
os.makedirs(SESSIONS_DIR, exist_ok=True)

SEPARATORS = [", ", ". ", " — ", " | ", " "]

# process_id -> (task, stop_event)
active_processes: Dict[int, Tuple[asyncio.Task, asyncio.Event]] = {}
# Процессы, состояние которых нужно сохранить при штатном выключении.
# Множество живёт до следующего запуска процесса и защищает от гонки с
# done-callback asyncio, который может сработать уже после отмены задачи.
_preserve_process_state = set()

# Один Pyrogram-клиент на один файл сессии. Это позволяет безопасно
# запускать несколько процессов на одном аккаунте без database is locked.
_shared_clients: Dict[int, Client] = {}
_shared_client_refs: Dict[int, int] = {}
_shared_client_locks: Dict[int, asyncio.Lock] = {}
_process_runtime: Dict[int, Dict] = {}
_autosub_seen = set()

# ─── TEXT GENERATION ──────────────────────────────────────────────────────────

def _toggle_case(text: str, use_upper: bool) -> str:
    for i, c in enumerate(text):
        if c.isalpha():
            return text[:i] + (c.upper() if use_upper else c.lower()) + text[i + 1:]
    return text


def generate_message(data: dict, prev: str, upper: bool) -> Tuple[str, bool]:
    mode = data.get("msg_mode", "random")
    parts = data.get("texts", [])
    if not parts:
        return "—", upper

    if mode == "sequence":
        idx = data.get("_seq_idx", 0)
        msg = parts[idx % len(parts)]
        data["_seq_idx"] = (idx + 1) % len(parts)
        return msg, upper

    if mode == "parts":
        for _ in range(50):
            separators = [" "]
            if data.get("parts_symbols", False):
                separators = [" ", ". ", ", "]
            sep = [random.choice(separators) for _ in range(len(parts) - 1)]
            msg = "".join(p + (sep[i] if i < len(sep) else "") for i, p in enumerate(parts))
            alt = data.get("alt_case", False)
            if alt:
                msg = _toggle_case(msg, upper)
                upper = not upper
            if msg != prev:
                return msg, upper
        return parts[0], upper

    # random
    for _ in range(50):
        msg = random.choice(parts)
        alt = data.get("alt_case", False)
        if alt:
            msg = _toggle_case(msg, upper)
            upper = not upper
        if msg != prev:
            return msg, upper
    return parts[0], upper


# ─── SESSION UTILS ────────────────────────────────────────────────────────────

def session_path(session_id: int) -> str:
    return os.path.join(SESSIONS_DIR, str(session_id))


def make_client(session_id: int) -> Optional[Client]:
    sess = db.get_session(session_id)
    if not sess:
        return None
    api_id = db.get_setting("api_id")
    api_hash = db.get_setting("api_hash")
    if not api_id or not api_hash:
        return None

    proxy = None
    if sess.get("proxy_host"):
        proxy = {
            "scheme": sess.get("proxy_scheme", "socks5"),
            "hostname": sess["proxy_host"],
            "port": int(sess["proxy_port"]),
            "username": sess.get("proxy_login", ""),
            "password": sess.get("proxy_pass", ""),
        }

    spath = session_path(session_id)

    # Проверяем, существует ли файл сессии физически на диске
    if not os.path.exists(spath + ".session"):
        logger.error(f"Файл сессии {spath}.session не найден! Отмена создания клиента во избежание зависания.")
        return None

    return Client(
        spath,
        api_id=int(api_id),
        api_hash=api_hash,
        no_updates=False,
        sleep_threshold=60,
        proxy=proxy,
    )


def get_active_session_ids():
    return set(_shared_clients.keys())


async def acquire_shared_client(session_id: int) -> Optional[Client]:
    lock = _shared_client_locks.setdefault(session_id, asyncio.Lock())
    async with lock:
        client = _shared_clients.get(session_id)
        if client is None:
            client = make_client(session_id)
            if client is None:
                return None
            try:
                await client.start()
            except Exception:
                try:
                    await client.stop(block=True)
                except Exception:
                    pass
                raise
            _shared_clients[session_id] = client
            _shared_client_refs[session_id] = 0
        _shared_client_refs[session_id] = _shared_client_refs.get(session_id, 0) + 1
        return client


async def release_shared_client(session_id: int):
    lock = _shared_client_locks.setdefault(session_id, asyncio.Lock())
    async with lock:
        refs = _shared_client_refs.get(session_id, 0) - 1
        if refs > 0:
            _shared_client_refs[session_id] = refs
            return
        client = _shared_clients.pop(session_id, None)
        _shared_client_refs.pop(session_id, None)
        if client is not None:
            try:
                await client.stop(block=True)
            except Exception:
                pass


def _raw_peer_id(peer) -> Optional[int]:
    if hasattr(peer, "user_id"):
        return int(peer.user_id)
    if hasattr(peer, "chat_id"):
        return -int(peer.chat_id)
    if hasattr(peer, "channel_id"):
        return -1000000000000 - int(peer.channel_id)
    return None


def _dialog_filter_items(result):
    """Pyrogram 2.0 возвращает vector/list, новые версии — объект filters."""
    if isinstance(result, (list, tuple)):
        return list(result)
    return list(getattr(result, "filters", []) or [])


async def get_session_folders(session_id: int):
    client = await acquire_shared_client(session_id)
    if not client:
        return []
    try:
        result = await client.invoke(raw_functions.messages.GetDialogFilters())
        folders = []
        for item in _dialog_filter_items(result):
            title = getattr(getattr(item, "title", None), "text", None) or str(getattr(item, "title", "Папка"))
            folders.append({"id": int(getattr(item, "id", 0)), "name": title})
        return folders
    finally:
        await release_shared_client(session_id)


async def get_folder_chats(client: Client, folder_id: int):
    result = await client.invoke(raw_functions.messages.GetDialogFilters())
    folder = next((x for x in _dialog_filter_items(result) if int(getattr(x, "id", -1)) == int(folder_id)), None)
    if folder is None:
        return []
    include_ids = {_raw_peer_id(p) for p in getattr(folder, "include_peers", []) or []}
    exclude_ids = {_raw_peer_id(p) for p in getattr(folder, "exclude_peers", []) or []}
    include_ids.discard(None)
    exclude_ids.discard(None)
    chats = []
    async for dialog in client.get_dialogs():
        chat_id = getattr(dialog.chat, "id", None)
        if chat_id is None or chat_id in exclude_ids:
            continue
        # Для пользовательских папок Telegram хранит include_peers. Если
        # список пустой, возвращаем все доступные диалоги как fallback.
        if include_ids and chat_id not in include_ids:
            continue
        chats.append(chat_id)
    return chats


async def _notify_user(bot_token: str, user_id: int, text: str, buttons=None):
    payload = {"chat_id": user_id, "text": text, "parse_mode": "HTML"}
    if buttons:
        payload["reply_markup"] = {"inline_keyboard": buttons}
    try:
        async with aiohttp.ClientSession() as session:
            await session.post(
                f"https://api.telegram.org/bot{bot_token}/sendMessage",
                json=payload,
                timeout=aiohttp.ClientTimeout(total=10),
            )
    except Exception:
        logger.debug("Не удалось отправить уведомление пользователю %s", user_id)


def _adjust_delay(process_id: int, minimum: int, maximum: int):
    state = _process_runtime.get(process_id, {})
    mode = state.get("mode", "percent")
    value = state.get("value", 0)
    if mode == "seconds":
        return max(0, minimum + value), max(0, maximum + value)
    factor = 1 + max(0, value) / 100
    return max(0, round(minimum * factor)), max(0, round(maximum * factor))


async def _handle_flood_wait(process_id: int, sess_id: int, seconds: int, stop_event: asyncio.Event, bot_token: str):
    proc = db.get_process(process_id)
    if not proc:
        return True
    db.record_flood_event(process_id, sess_id, seconds)
    flood = proc.get("flood_settings") or {"enabled": True, "threshold": 3, "hours": 1}
    slow = proc.get("slowdown_settings") or {"enabled": False, "threshold": 1, "mode": "percent", "value": 20}
    count = db.count_flood_events(process_id, flood.get("hours", 1))
    name = proc.get("name", str(process_id))
    service_name = "Рассылка"

    if flood.get("enabled", True) and count >= int(flood.get("threshold", 3)):
        stop_event.set()
        await _notify_user(
            bot_token,
            proc["user_id"],
            f"🛡 <b>Процесс {name} | {service_name}</b>\nОстановлен, так как получил {count} FloodWait за {flood.get('hours', 1)} ч.\nПоследний FloodWait: {seconds} сек.",
            [[{"text": "Открыть процесс", "callback_data": f"proc_open:{process_id}"}]],
        )
        return True

    if slow.get("enabled", False) and count >= int(slow.get("threshold", 1)):
        state = _process_runtime.setdefault(process_id, {"value": 0, "mode": "percent", "slow_triggered": False})
        if not state.get("slow_triggered"):
            state["value"] = int(slow.get("value", 20))
            state["mode"] = slow.get("mode", "percent")
            state["slow_triggered"] = True
            suffix = f"+{state['value']}%" if state["mode"] == "percent" else f"+{state['value']} сек."
            await _notify_user(
                bot_token,
                proc["user_id"],
                f"🐢 <b>Процесс {name} | {service_name}</b>\nНадбавка {suffix}, поскольку включено Авто-Замедление.",
                [[{"text": "Открыть настройки авто-замедления", "callback_data": f"proc_slow:{process_id}"}, {"text": "Отключить авто-замедление", "callback_data": f"proc_slow_toggle:{process_id}"}]],
            )
    else:
        await _notify_user(
            bot_token,
            proc["user_id"],
            f"⚠️ <b>Процесс {name} | {service_name}</b>\nВы получили FloodWait на {seconds} сек.\nПопробуйте изменить тайминги или настройки реакции на FloodWait.",
            [[{"text": "Посетить настройки", "callback_data": f"proc_flood:{process_id}"}, {"text": "Отключить процесс", "callback_data": f"proc_stop:{process_id}"}]],
        )
    return False


async def _wait_or_stop(stop_event: asyncio.Event, seconds: float):
    """Ждёт таймер или остановку, не блокируя быстрое завершение процесса."""
    if stop_event.is_set():
        return
    try:
        await asyncio.wait_for(stop_event.wait(), timeout=max(0.0, seconds))
    except asyncio.TimeoutError:
        pass


async def _maybe_send_typing(
    client: Client, chat_id: int, data: dict, stop_event: asyncio.Event = None
):
    """Показывает статус «печатает» перед отправкой ответа.

    Режим общий для всех сервисов: рассылки, автоответчика и триггербота.
    Некритичная ошибка ChatAction не должна ломать основной процесс.
    """
    if not data.get("typing_mode", False):
        return

    try:
        typing_min = max(0, int(data.get("typing_min", 3)))
        typing_max = max(typing_min, int(data.get("typing_max", typing_min)))
        await client.send_chat_action(chat_id, ChatAction.TYPING)
        delay = random.randint(typing_min, typing_max)
        if delay:
            if stop_event is not None:
                await _wait_or_stop(stop_event, delay)
            else:
                await asyncio.sleep(delay)
    except Exception as exc:
        logger.debug("Не удалось показать статус 'печатает' в чате %s: %s", chat_id, exc)


async def _autosub_handler(
    client: Client,
    message: PyroMessage,
    data: dict,
    process_id: int,
    sess_id: int,
    bot_token: str,
):
    global _autosub_seen
    key = (sess_id, getattr(message.chat, "id", 0), getattr(message, "id", 0))
    if key in _autosub_seen:
        return
    _autosub_seen.add(key)
    if len(_autosub_seen) > 10000:
        _autosub_seen = set(list(_autosub_seen)[-5000:])
    markup = getattr(message, "reply_markup", None)
    rows = getattr(markup, "inline_keyboard", []) if markup else []
    actions = data.get("autosub_actions") or {}
    delay = max(0, int(data.get("autosub_delay", 3)))
    for row in rows or []:
        for button in row:
            label = (getattr(button, "text", "") or "").lower()
            url = getattr(button, "url", None)
            try:
                if url:
                    parsed = urlparse(url if url.startswith("http") else "https://" + url.lstrip("/"))
                    parts = [x for x in parsed.path.split("/") if x]
                    username = parts[0] if parts else ""
                    query = parse_qs(parsed.query)
                    payload = (query.get("start") or [None])[0]
                    is_bot = bool(payload) or "bot" in label or "запуск" in label or "start" in label
                    is_join = any(word in label for word in ("подпис", "subscribe", "вступ", "join"))
                    if is_bot and actions.get("start_bots", True) and payload:
                        await client.send_message(username, f"/start {payload}")
                    elif is_join and actions.get("subscribe", True):
                        await client.join_chat(url)
                    elif is_join and actions.get("join", True):
                        await client.join_chat(url)
                    else:
                        continue
                    await _wait_or_stop(asyncio.Event(), delay)
                elif any(word in label for word in ("подпис", "subscribe", "вступ", "join")):
                    if actions.get("subscribe", True) or actions.get("join", True):
                        await message.click(getattr(button, "text", ""))
                        await _wait_or_stop(asyncio.Event(), delay)
            except errors.FloodWait as ex:
                proc = db.get_process(process_id)
                if proc:
                    await _notify_user(
                        bot_token,
                        proc["user_id"],
                        f"⚠️ <b>Процесс {proc.get('name', process_id)} | Рассылка Автосаб</b>\n"
                        f"Вы получили FloodWait на {ex.value} сек. Попробуйте увеличить задержку Автосаба.",
                        [[{"text": "Открыть настройки Автосаба", "callback_data": f"tpl_autosub:{proc.get('template_ids', [0])[0]}"}, {"text": "Отключить Автосаб", "callback_data": f"tpl_autosub_toggle:{proc.get('template_ids', [0])[0]}"}]],
                    )
                    return
            except Exception:
                continue


# ─── BROADCAST ────────────────────────────────────────────────────────────────

async def _run_broadcast(process_id: int, sess_id: int, stop_event: asyncio.Event, bot_token: str, template_id: int = None):
    proc = db.get_process(process_id)
    template_id = _template_id_for_process(proc, template_id)
    if not proc or not template_id:
        logger.error(f"[proc={process_id}] Процесс или шаблон не найден")
        return

    tpl = db.get_template(template_id)
    if not tpl:
        logger.error(f"[proc={process_id}] Шаблон не найден")
        return

    data = tpl["data"]
    chats = data.get("chats", [])

    client = None
    client_acquired = False
    autosub_handler = None
    log_level = proc.get("log_level", "errors")

    async def tg_log(text: str, force: bool = False):
        if log_level == "off" and not force:
            return
        sess_info = db.get_session(sess_id)
        uid = db.get_process(process_id)["user_id"]
        try:
            async with aiohttp.ClientSession() as s:
                await s.post(
                    f"https://api.telegram.org/bot{bot_token}/sendMessage",
                    json={"chat_id": uid, "text": text, "parse_mode": "HTML"},
                    timeout=aiohttp.ClientTimeout(total=10),
                )
        except Exception:
            pass

    try:
        client = await acquire_shared_client(sess_id)
        if not client:
            return
        client_acquired = True
        if data.get("folder_id"):
            chats = await get_folder_chats(client, int(data["folder_id"]))
        if not chats:
            logger.warning(f"[proc={process_id}] Нет чатов")
            return
        if data.get("autosub_enabled", False):
            async def _on_autosub(client_, message_):
                await _autosub_handler(client_, message_, data, process_id, sess_id, bot_token)
            autosub_handler = MessageHandler(_on_autosub)
            client.add_handler(autosub_handler)
        me = await client.get_me()
        logger.info(f"[proc={process_id}] Запуск рассылки: {me.first_name}, аккаунт {sess_id}")

        delay_msg_min = int(data.get("delay_msg_min", 0))
        delay_msg_max = int(data.get("delay_msg_max", delay_msg_min))
        delay_cycle_min = int(data.get("delay_cycle_min", 60))
        delay_cycle_max = int(data.get("delay_cycle_max", delay_cycle_min))
        chunk_mode = data.get("chunk_mode", False)
        chunk_size = int(data.get("chunk_size", 20))
        chunk_delay_min = int(data.get("chunk_delay_min", 180))
        chunk_delay_max = int(data.get("chunk_delay_max", chunk_delay_min))
        typing_mode = data.get("typing_mode", False)
        typing_min = int(data.get("typing_min", 3))
        typing_max = int(data.get("typing_max", 5))
        random_chats = data.get("random_chats", False)
        runtime = _process_runtime.get(process_id, {})
        work_settings = proc.get("work_settings") or {"mode": "unlimited"}
        work_mode = work_settings.get("mode", "unlimited")
        cycle_limit = int(work_settings.get("cycles", 0) or 0) if work_mode == "cycles" else None
        deadline = runtime.get("deadline") if work_mode == "duration" else None
        cycles_done = 0
        worker_key = f"{sess_id}:{template_id}"

        prev_msg = ""
        upper_flag = False
        sent_total = 0

        while not stop_event.is_set():
            current_chats = list(chats)
            if random_chats:
                random.shuffle(current_chats)

            chunk_count = 0
            success = 0
            errors_count = 0

            for chat in current_chats:
                if stop_event.is_set():
                    break

                msg_text, upper_flag = generate_message(data, prev_msg, upper_flag)
                prev_msg = msg_text

                if chunk_count > 0 and delay_msg_max > 0:
                    dmin, dmax = _adjust_delay(process_id, delay_msg_min, delay_msg_max)
                    await _wait_or_stop(stop_event, random.randint(dmin, dmax))

                try:
                    target = int(chat) if str(chat).lstrip("-").isdigit() else chat
                    if typing_mode:
                        await _maybe_send_typing(client, target, data, stop_event)
                    await client.send_message(target, msg_text)
                    success += 1
                    sent_total += 1
                    chunk_count += 1
                    db.record_message_sent(
                        proc["user_id"], sess_id, process_id=process_id
                    )
                except errors.FloodWait as e:
                    stopped = await _handle_flood_wait(process_id, sess_id, e.value, stop_event, bot_token)
                    if stopped:
                        break
                    await _wait_or_stop(stop_event, e.value)
                    continue
                except Exception as ex:
                    errors_count += 1
                    logger.warning(f"[proc={process_id}] Ошибка отправки в {chat}: {ex}")

                if chunk_mode and chunk_count >= chunk_size:
                    if log_level in ("all", "important"):
                        await tg_log(f"📦 Пачка завершена ({chunk_size} шт). Пауза...")
                    cmin, cmax = _adjust_delay(process_id, chunk_delay_min, chunk_delay_max)
                    await _wait_or_stop(stop_event, random.randint(cmin, cmax))
                    chunk_count = 0

            if log_level in ("all", "important", "errors"):
                if log_level == "errors" and errors_count == 0:
                    pass
                else:
                    await tg_log(
                        f"✅ Цикл завершён\n"
                        f"Успешно: {success} | Ошибок: {errors_count}\n"
                        f"Всего отправлено: {sent_total}"
                    )

            cycles_done += 1
            runtime = _process_runtime.setdefault(process_id, {})
            runtime.setdefault("cycle_counts", {})[worker_key] = cycles_done
            reached_limit = cycle_limit is not None and cycles_done >= cycle_limit
            reached_deadline = deadline is not None and time.time() >= deadline
            if reached_limit or reached_deadline:
                runtime["natural_done"] = True
                runtime["reason"] = "cycles" if reached_limit else "duration"
                break
            if stop_event.is_set():
                break

            cmin, cmax = _adjust_delay(process_id, delay_cycle_min, delay_cycle_max)
            cycle_delay = random.randint(cmin, cmax)
            await _wait_or_stop(stop_event, cycle_delay)

    except asyncio.CancelledError:
        pass
    except Exception as e:
        logger.error(f"[proc={process_id}] Критическая ошибка: {e}")
    finally:
        if client is not None and autosub_handler is not None:
            try:
                client.remove_handler(autosub_handler, group=0)
            except Exception:
                pass
        if client_acquired:
            await release_shared_client(sess_id)
        logger.info(f"[proc={process_id}] Рассылка остановлена, сессия {sess_id}")


# ─── AUTORESPONDER ────────────────────────────────────────────────────────────

_ar_cooldowns: Dict[int, Dict[int, float]] = {}


def _template_id_for_process(proc: dict, template_id: int = None) -> Optional[int]:
    if template_id:
        return int(template_id)
    ids = proc.get("template_ids") or [] if proc else []
    if ids:
        return int(ids[0])
    return int(proc["template_id"]) if proc and proc.get("template_id") else None


async def _run_autoresponder(
    process_id: int,
    sess_id: int,
    stop_event: asyncio.Event,
    bot_token: str,
    template_id: int = None,
):
    proc = db.get_process(process_id)
    template_id = _template_id_for_process(proc, template_id)
    if not proc or not template_id:
        logger.error(f"[AR proc={process_id}] Процесс или шаблон не найден")
        return
    tpl = db.get_template(template_id)
    if not tpl:
        logger.error(f"[AR proc={process_id}] Шаблон не найден")
        return

    data = tpl["data"]
    who = data.get("ar_who", "all")
    cooldown_hours = max(0, int(data.get("ar_cooldown", 8)))
    reply_text = data.get("ar_reply_text", "")
    reply_media = data.get("ar_reply_media")

    cooldown_map: Dict[int, float] = {}
    contact_ids = set()
    contacts_loaded_at = 0.0
    client = None
    handler = None
    acquired = False

    async def on_message(client_: Client, message: PyroMessage):
        nonlocal contact_ids, contacts_loaded_at
        if stop_event.is_set() or not message.from_user or message.from_user.is_bot:
            return
        if not message.chat or message.chat.type != ChatType.PRIVATE:
            return

        sender = message.from_user
        now = time.time()
        if now - cooldown_map.get(sender.id, 0) < cooldown_hours * 3600:
            return

        if who != "all" and now - contacts_loaded_at >= 300:
            try:
                contacts = await client_.get_contacts()
                contact_ids = {contact.id for contact in contacts}
            except Exception:
                contact_ids = set()
            contacts_loaded_at = now

        if who == "contacts" and sender.id not in contact_ids:
            return
        if who == "non_contacts" and sender.id in contact_ids:
            return

        try:
            await _maybe_send_typing(client_, sender.id, data, stop_event)
            sent = False
            if reply_media:
                m_type = reply_media.get("type", "photo")
                file_id = reply_media.get("file_id", "")
                if m_type == "photo":
                    await client_.send_photo(sender.id, file_id, caption=reply_text or None)
                elif m_type == "video":
                    await client_.send_video(sender.id, file_id, caption=reply_text or None)
                elif m_type == "animation":
                    await client_.send_animation(sender.id, file_id, caption=reply_text or None)
                elif m_type == "sticker":
                    await client_.send_sticker(sender.id, file_id)
                else:
                    await client_.send_message(sender.id, reply_text or "👋")
                sent = True
            elif reply_text:
                await client_.send_message(sender.id, reply_text)
                sent = True
            if sent:
                cooldown_map[sender.id] = now
                db.record_message_sent(proc["user_id"], sess_id, process_id=process_id)
        except Exception as ex:
            logger.warning(f"[AR proc={process_id}] Ошибка ответа: {ex}")

    try:
        client = await acquire_shared_client(sess_id)
        if not client:
            return
        acquired = True
        handler = MessageHandler(on_message, filters.private)
        client.add_handler(handler)
        logger.info(f"[AR proc={process_id}] Автоответчик запущен, сессия {sess_id}")
        while not stop_event.is_set():
            await _wait_or_stop(stop_event, 1)
    except asyncio.CancelledError:
        pass
    except Exception as e:
        logger.error(f"[AR proc={process_id}] Ошибка: {e}")
    finally:
        if client is not None and handler is not None:
            try:
                client.remove_handler(handler, group=0)
            except Exception:
                pass
        if acquired:
            await release_shared_client(sess_id)


# ─── TRIGGERBOT ───────────────────────────────────────────────────────────────

async def _run_triggerbot(
    process_id: int,
    sess_id: int,
    stop_event: asyncio.Event,
    bot_token: str,
    template_id: int = None,
):
    proc = db.get_process(process_id)
    template_id = _template_id_for_process(proc, template_id)
    if not proc or not template_id:
        logger.error(f"[TB proc={process_id}] Процесс или шаблон не найден")
        return
    tpl = db.get_template(template_id)
    if not tpl:
        logger.error(f"[TB proc={process_id}] Шаблон не найден")
        return

    data = tpl["data"]
    triggers = data.get("triggers", [])
    where = data.get("tb_where", "all")
    selected_chats = data.get("tb_chats", [])
    client = None
    handler = None
    acquired = False

    async def on_message(client_: Client, message: PyroMessage):
        if stop_event.is_set() or not message.text or not message.chat:
            return
        if where == "selected":
            chat_id = str(message.chat.id)
            chat_username = message.chat.username or ""
            if chat_id not in selected_chats and chat_username not in selected_chats:
                return

        text_lower = message.text.lower()
        for trigger in triggers:
            kw = trigger.get("keyword", "").lower()
            if not kw or kw not in text_lower:
                continue
            reply_text = trigger.get("reply_text", "")
            reply_media = trigger.get("reply_media")
            try:
                await _maybe_send_typing(client_, message.chat.id, data, stop_event)
                sent = False
                if reply_media:
                    m_type = reply_media.get("type", "photo")
                    file_id = reply_media.get("file_id", "")
                    if m_type == "photo":
                        await message.reply_photo(file_id, caption=reply_text or None)
                    elif m_type == "video":
                        await message.reply_video(file_id, caption=reply_text or None)
                    elif m_type == "animation":
                        await message.reply_animation(file_id, caption=reply_text or None)
                    elif m_type == "sticker":
                        await message.reply_sticker(file_id)
                    else:
                        await message.reply(reply_text or "👋")
                    sent = True
                elif reply_text:
                    await message.reply(reply_text)
                    sent = True
                if sent:
                    db.record_message_sent(proc["user_id"], sess_id, process_id=process_id)
            except Exception as ex:
                logger.warning(f"[TB proc={process_id}] Ошибка ответа: {ex}")
            break

    try:
        client = await acquire_shared_client(sess_id)
        if not client:
            return
        acquired = True
        if data.get("ac_folder_id"):
            folder_chat_ids = set(await get_folder_chats(client, int(data["ac_folder_id"])))
        handler = MessageHandler(on_message)
        client.add_handler(handler)
        logger.info(f"[TB proc={process_id}] Триггербот запущен, сессия {sess_id}")
        while not stop_event.is_set():
            await _wait_or_stop(stop_event, 1)
    except asyncio.CancelledError:
        pass
    except Exception as e:
        logger.error(f"[TB proc={process_id}] Ошибка: {e}")
    finally:
        if client is not None and handler is not None:
            try:
                client.remove_handler(handler, group=0)
            except Exception:
                pass
        if acquired:
            await release_shared_client(sess_id)


# ─── AUTOCHECKER ──────────────────────────────────────────────────────────────

_CHECK_LINK_RE = re.compile(r"(?:https?://)?t\.me/[A-Za-z0-9_]+(?:/[A-Za-z0-9_]+)?\?[^\s>\]\)]+", re.I)
_AMOUNT_RE = re.compile(r"(?<![\w.])([0-9]+(?:[.,][0-9]+)?)\s*([A-ZА-Я][A-ZА-Я0-9]{1,9})(?!\w)", re.I)
_SUCCESS_RE = re.compile(r"(?:вы\s+получили|you\s+received|получено|received)", re.I)
_SKIP_RE = re.compile(r"(?:парол|password|подпис|subscribe|капч|captcha)", re.I)


def _message_urls(message: PyroMessage):
    urls = []
    text = message.text or message.caption or ""
    urls.extend(_CHECK_LINK_RE.findall(text))
    entities = list(getattr(message, "entities", None) or []) + list(getattr(message, "caption_entities", None) or [])
    for entity in entities:
        entity_url = getattr(entity, "url", None)
        if entity_url:
            urls.append(entity_url)
    markup = getattr(message, "reply_markup", None)
    for row in getattr(markup, "inline_keyboard", []) or []:
        for button in row:
            url = getattr(button, "url", None)
            if url:
                urls.append(url)
    return list(dict.fromkeys(urls))


def _send_payload(url: str):
    if not url.lower().startswith(("http://", "https://")):
        url = "https://" + url.lstrip("/")
    parsed = urlparse(url)
    query = parse_qs(parsed.query)
    payload = (query.get("start") or [None])[0]
    username = (parsed.path.strip("/").split("/") or [""])[0].lower()
    if username in {"send", "cryptobot"} and payload:
        return "send", username, payload
    return None


def _parse_success(text: str):
    if not text or not _SUCCESS_RE.search(text) or _SKIP_RE.search(text):
        return None
    match = _AMOUNT_RE.search(text.upper().replace(",", "."))
    if not match:
        return None
    try:
        return float(match.group(1)), match.group(2).upper()
    except ValueError:
        return None


async def _run_autochecker(
    process_id: int,
    sess_id: int,
    stop_event: asyncio.Event,
    bot_token: str,
    template_id: int = None,
):
    proc = db.get_process(process_id)
    template_id = _template_id_for_process(proc, template_id)
    if not proc or not template_id:
        return
    tpl = db.get_template(template_id)
    if not tpl:
        return
    data = tpl["data"]
    source_mode = data.get("ac_source", "send")
    where = data.get("ac_where", "all")
    selected_chats = {str(x) for x in data.get("ac_chats", [])}
    daily_limit = data.get("ac_daily_limit")
    try:
        daily_limit = int(daily_limit) if daily_limit not in (None, "", 0, "0") else None
    except (TypeError, ValueError):
        daily_limit = None
    attempts = max(1, int(data.get("ac_attempts", 1)))
    client = None
    handler = None
    acquired = False
    inflight = set()
    activation_tasks = set()
    folder_chat_ids = set()
    pending = {"send": asyncio.Queue()}

    def allowed_source(source):
        return source_mode in ("send", "both") and source == "send"

    def allowed_chat(message):
        chat_id = str(message.chat.id)
        if where == "folder":
            return message.chat.id in folder_chat_ids
        if where == "selected":
            return chat_id in selected_chats or (message.chat.username or "") in selected_chats
        if where == "except":
            return chat_id not in selected_chats and (message.chat.username or "") not in selected_chats
        return True

    async def wait_result(bot_name: str, payload: str):
        queue = pending[bot_name]
        for attempt in range(attempts):
            await client.send_message(bot_name, f"/start {payload}")
            try:
                result = await asyncio.wait_for(queue.get(), timeout=8)
            except asyncio.TimeoutError:
                continue
            text = result.text or result.caption or ""
            parsed = _parse_success(text)
            if parsed:
                return parsed
            if _SKIP_RE.search(text):
                return None
        return None

    async def activate(url: str, source: str, bot_name: str, payload: str):
        if url in inflight:
            return
        if daily_limit is not None and db.get_daily_check_count(sess_id) >= daily_limit:
            return
        inflight.add(url)
        try:
            result = await wait_result(bot_name, payload)
            if result:
                amount, currency = result
                db.record_check_success(
                    proc["user_id"], sess_id, currency, amount,
                    process_id=process_id, link=url,
                )
        finally:
            inflight.discard(url)

    async def on_message(client_: Client, message: PyroMessage):
        if stop_event.is_set() or not message.chat:
            return
        username = (getattr(message.from_user, "username", "") or "").lower()
        if username == "send" and message.chat.type == ChatType.PRIVATE:
            try:
                pending["send"].put_nowait(message)
            except asyncio.QueueFull:
                pass
        if not allowed_chat(message):
            return
        for url in _message_urls(message):
            parsed = _send_payload(url)
            if not parsed:
                continue
            source, bot_name, payload = parsed
            if allowed_source(source):
                task = asyncio.create_task(activate(url, source, bot_name, payload))
                activation_tasks.add(task)
                task.add_done_callback(activation_tasks.discard)

    try:
        client = await acquire_shared_client(sess_id)
        if not client:
            return
        acquired = True
        handler = MessageHandler(on_message)
        client.add_handler(handler)
        logger.info(f"[AC proc={process_id}] Авточекер запущен, сессия {sess_id}")
        while not stop_event.is_set():
            await _wait_or_stop(stop_event, 1)
    except asyncio.CancelledError:
        pass
    except Exception as ex:
        logger.error(f"[AC proc={process_id}] Ошибка: {ex}")
    finally:
        for task in list(activation_tasks):
            task.cancel()
        if activation_tasks:
            await asyncio.gather(*activation_tasks, return_exceptions=True)
        if client is not None and handler is not None:
            try:
                client.remove_handler(handler, group=0)
            except Exception:
                pass
        if acquired:
            await release_shared_client(sess_id)


# ─── PUBLIC API ───────────────────────────────────────────────────────────────


def _on_process_done(process_id: int, task: asyncio.Future):
    """Синхронизирует память и БД после завершения всех аккаунтов процесса."""
    current = active_processes.get(process_id)
    if current is not None and current[0] is not task:
        # Для этого процесса уже запущена более новая задача.
        return
    if current is not None:
        active_processes.pop(process_id, None)
    runtime = _process_runtime.pop(process_id, {})
    if runtime.get("natural_done") and runtime.get("bot_token"):
        total_cycles = sum((runtime.get("cycle_counts") or {}).values())
        proc_name = runtime.get("process_name", str(process_id))
        if runtime.get("reason") == "duration":
            elapsed = max(0, int(time.time() - runtime.get("started_at", time.time())))
            days, rem = divmod(elapsed, 86400)
            hours, rem = divmod(rem, 3600)
            minutes, _ = divmod(rem, 60)
            work_text = f"Времени прошло: {days}.{hours:02d}.{minutes:02d}"
        else:
            work_text = f"Циклов прошло: {total_cycles}"
        asyncio.create_task(_notify_user(
            runtime["bot_token"],
            runtime["user_id"],
            f"✅ <b>Процесс {proc_name} закончил работу</b>\n{work_text}",
            [[{"text": "Открыть процесс", "callback_data": f"proc_open:{process_id}"}]],
        ))

    # При штатном выключении бота флаг оставляем в БД для автопродолжения.
    if process_id not in _preserve_process_state:
        db.set_process_running(process_id, False)

    if task.cancelled():
        return
    try:
        exception = task.exception()
    except asyncio.CancelledError:
        return
    # Отмена задачи при ручной остановке/выключении — штатный сценарий,
    # не нужно превращать его в красную строку с пустым текстом ошибки.
    if exception is None or isinstance(exception, asyncio.CancelledError):
        return
    logger.error("Процесс %s завершился с ошибкой: %s", process_id, exception)


def get_session_conflicts(process_id: int):
    """Возвращает активные процессы, которые уже используют те же сессии."""
    proc = db.get_process(process_id)
    if not proc:
        return []

    selected = set(proc.get("session_ids", []))
    conflicts = []
    for other_id in list(active_processes):
        if other_id == process_id or not is_running(other_id):
            continue
        other = db.get_process(other_id)
        if not other:
            continue
        overlap = selected.intersection(other.get("session_ids", []))
        for session_id in overlap:
            conflicts.append((session_id, other_id, other.get("name", str(other_id))))
    return conflicts


async def start_process(process_id: int, bot_token: str) -> bool:
    # Если процесс запускают вручную после сохранённого shutdown-состояния,
    # это уже новый жизненный цикл — старую защитную отметку снимаем.
    _preserve_process_state.discard(process_id)

    existing = active_processes.get(process_id)
    if existing is not None:
        if existing[0].done():
            active_processes.pop(process_id, None)
        else:
            return False

    proc = db.get_process(process_id)
    template_ids = proc.get("template_ids", []) if proc else []
    if not proc or not template_ids or not proc.get("session_ids"):
        return False

    stop_event = asyncio.Event()
    service = proc["service"]
    sess_ids = proc["session_ids"]
    for template_id in template_ids:
        template = db.get_template(template_id)
        folder_session_id = (template["data"].get("folder_session_id") or template["data"].get("ac_folder_session_id")) if template else None
        if folder_session_id and set(sess_ids) != {int(folder_session_id)}:
            logger.error("Процесс %s не запущен: папка шаблона привязана к другой сессии", process_id)
            return False

    work_settings = proc.get("work_settings") or {"mode": "unlimited"}
    runtime = {"value": 0, "mode": "percent", "slow_triggered": False, "started_at": time.time(), "cycle_counts": {}, "natural_done": False, "bot_token": bot_token, "user_id": proc["user_id"], "process_name": proc.get("name", str(process_id))}
    if work_settings.get("mode") == "duration":
        runtime["deadline"] = runtime["started_at"] + int(work_settings.get("duration_seconds", 0) or 0)
    _process_runtime[process_id] = runtime
    tasks = []
    # Несколько шаблонов работают параллельно, но используют общий клиент
    # сессии, поэтому один .session не открывается дважды.
    for sid in sess_ids:
        for template_id in template_ids:
            if service == "broadcast":
                coro = _run_broadcast(process_id, sid, stop_event, bot_token, template_id)
            elif service == "autoresponder":
                coro = _run_autoresponder(process_id, sid, stop_event, bot_token, template_id)
            elif service == "triggerbot":
                coro = _run_triggerbot(process_id, sid, stop_event, bot_token, template_id)
            elif service == "autochecker":
                coro = _run_autochecker(process_id, sid, stop_event, bot_token, template_id)
            else:
                continue
            tasks.append(asyncio.create_task(coro))

    if not tasks:
        return False

    main_task = asyncio.gather(*tasks)
    active_processes[process_id] = (main_task, stop_event)
    main_task.add_done_callback(lambda task: _on_process_done(process_id, task))
    db.set_process_running(process_id, True)
    return True


async def stop_process(process_id: int, preserve_running_state: bool = False):
    entry = active_processes.pop(process_id, None)
    if entry is not None:
        task, stop_event = entry
        stop_event.set()
        try:
            # Сначала даём Pyrogram штатно остановить update-handler'ы.
            # Немедленная отмена была причиной «closed database» от фоновых
            # handle_updates при закрытии session-файла.
            await asyncio.wait_for(asyncio.shield(task), timeout=15)
        except asyncio.TimeoutError:
            task.cancel()
            try:
                await asyncio.gather(task, return_exceptions=True)
            except asyncio.CancelledError:
                pass
            except Exception:
                pass
        except asyncio.CancelledError:
            pass
        except Exception:
            pass

    # Даже если задача уже завершилась или была потеряна, ручная остановка
    # должна снять флаг, иначе процесс снова запустится после перезапуска.
    if not preserve_running_state:
        db.set_process_running(process_id, False)


async def stop_all(preserve_running_state: bool = False):
    """Останавливает задачи.

    preserve_running_state=True используется только при выключении самого
    бота: процессы физически останавливаются, но их флаг в БД сохраняется,
    поэтому resume_processes запустит их после следующего старта.
    """
    pids = list(active_processes.keys())
    if preserve_running_state:
        _preserve_process_state.update(pids)
    for pid in pids:
        await stop_process(pid, preserve_running_state=preserve_running_state)


def is_running(process_id: int) -> bool:
    entry = active_processes.get(process_id)
    return entry is not None and not entry[0].done()


async def resume_processes(bot_token: str):
    procs = db.get_all_running_processes()
    for proc in procs:
        try:
            ok = await start_process(proc["id"], bot_token)
            if ok:
                logger.info(f"Процесс {proc['id']} '{proc['name']}' возобновлён")
            else:
                # Некорректно настроенный процесс не должен бесконечно
                # пытаться запускаться на каждом старте бота.
                db.set_process_running(proc["id"], False)
                logger.error(f"Процесс {proc['id']} не удалось возобновить: неполная настройка")
        except Exception as e:
            db.set_process_running(proc["id"], False)
            logger.error(f"Ошибка возобновления процесса {proc['id']}: {e}")
