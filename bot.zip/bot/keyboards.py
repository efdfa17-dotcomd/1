"""
keyboards.py — Все клавиатуры бота.
"""

from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from typing import List, Optional
import database as db

SERVICE_NAMES = {
    "broadcast": "Рассылка",
    "autoresponder": "Автоответчик",
    "triggerbot": "Триггербот",
    "autochecker": "Авточекер",
}


def kb(*rows) -> InlineKeyboardMarkup:
    """Быстрый конструктор клавиатуры из списков кнопок."""
    return InlineKeyboardMarkup(inline_keyboard=list(rows))


def btn(text: str, data: str) -> InlineKeyboardButton:
    return InlineKeyboardButton(text=text, callback_data=data)


def url_btn(text: str, url: str) -> InlineKeyboardButton:
    return InlineKeyboardButton(text=text, url=url)


def back(target: str) -> List[InlineKeyboardButton]:
    return [btn("⬅️ Назад", target)]


# ─── ГЛАВНОЕ МЕНЮ ─────────────────────────────────────────────────────────────

def main_menu(user_id: int) -> InlineKeyboardMarkup:
    has_sub = db.has_subscription(user_id)
    is_adm = db.is_admin(user_id)

    rows = []
    if has_sub:
        rows.append([btn("👤 Профиль", "profile"), btn("📱 Сессии", "sessions")])
        rows.append([btn("⚡ Процессы", "processes"), btn("📋 Шаблоны", "templates")])
        rows.append([btn("⚙️ Функции", "functions"), btn("💳 Подписки", "subscriptions")])
        rows.append([btn("🤝 Реф. программа", "referral"), btn("👨‍💻 Тех. поддержка", "support")])
        rows.append([btn("📢 Канал", "channel")])
    else:
        rows.append([btn("👤 Профиль", "profile")])
        rows.append([btn("⚙️ Функции", "functions"), btn("💳 Подписки", "subscriptions")])
        rows.append([btn("🤝 Реф. программа", "referral")])
        rows.append([btn("👨‍💻 Тех. поддержка", "support"), btn("📢 Канал", "channel")])

    if is_adm:
        rows.append([btn("🛠 Админ-меню", "admin_menu")])

    return InlineKeyboardMarkup(inline_keyboard=rows)


# ─── ПРОФИЛЬ ──────────────────────────────────────────────────────────────────

def profile_kb() -> InlineKeyboardMarkup:
    return kb(back("main_menu"))


# ─── СЕССИИ ───────────────────────────────────────────────────────────────────

def sessions_kb(user_id: int) -> InlineKeyboardMarkup:
    sessions = db.get_sessions(user_id)
    rows = []
    for s in sessions:
        rows.append([btn(f"📱 {s['name']}", f"sess_open:{s['id']}")])
    rows.append([btn("➕ Добавить сессию", "sess_add")])
    rows.append(back("main_menu"))
    return InlineKeyboardMarkup(inline_keyboard=rows)


def session_menu_kb(session_id: int) -> InlineKeyboardMarkup:
    return kb(
        [btn("✏️ Переименовать", f"sess_rename:{session_id}"),
         btn("📊 Статистика", f"sess_stats:{session_id}")],
        [btn("🌐 Добавить прокси", f"sess_proxy:{session_id}"),
         btn("🗑 Удалить", f"sess_delete:{session_id}")],
        back("sessions"),
    )


# ─── ШАБЛОНЫ ──────────────────────────────────────────────────────────────────

def templates_kb(user_id: int) -> InlineKeyboardMarkup:
    tpls = db.get_templates(user_id)
    rows = []
    for t in tpls:
        svc = SERVICE_NAMES.get(t["service"], t["service"])
        rows.append([btn(f"📋 {t['name']} | {svc}", f"tpl_open:{t['id']}")])
    rows.append([btn("➕ Создать шаблон", "tpl_create")])
    rows.append(back("main_menu"))
    return InlineKeyboardMarkup(inline_keyboard=rows)


def tpl_service_kb() -> InlineKeyboardMarkup:
    return kb(
        [btn("✉️ Рассылка", "tpl_svc:broadcast")],
        [btn("🤖 Автоответчик", "tpl_svc:autoresponder")],
        [btn("⚡ Триггербот", "tpl_svc:triggerbot")],
        [btn("🧾 Авточекер", "tpl_svc:autochecker")],
        back("templates"),
    )


def tpl_menu_kb(tpl_id: int, service: str, data: dict = None) -> InlineKeyboardMarkup:
    data = data or {}
    rows = [[btn("✏️ Переименовать", f"tpl_rename:{tpl_id}")]]

    if service == "broadcast":
        rows += [
            [btn("💬 Тексты", f"tpl_texts:{tpl_id}"),
             btn("👥 Чаты", f"tpl_chats:{tpl_id}")],
            [btn("⏱ Тайминги", f"tpl_timings:{tpl_id}"),
             btn("📦 Пачки", f"tpl_chunks:{tpl_id}")],
            [btn(f"🛠 Автосаб: {'вкл' if data.get('autosub_enabled', False) else 'выкл'}", f"tpl_autosub:{tpl_id}")],
            [btn("⌨️ Режим печатает", f"tpl_typing:{tpl_id}")],
        ]
    elif service == "autoresponder":
        rows += [
            [btn("🎯 Кому отвечать", f"tpl_ar_who:{tpl_id}")],
            [btn("✉️ Сообщение ответа", f"tpl_ar_reply:{tpl_id}")],
            [btn("⏳ КД ответа (часы)", f"tpl_ar_cd:{tpl_id}")],
            [btn("⌨️ Режим печатает", f"tpl_typing:{tpl_id}")],
        ]
    elif service == "triggerbot":
        rows += [
            [btn("📍 Где отвечать", f"tpl_tb_where:{tpl_id}")],
            [btn("🔑 Команды/Слова", f"tpl_tb_triggers:{tpl_id}")],
            [btn("⌨️ Режим печатает", f"tpl_typing:{tpl_id}")],
        ]

    elif service == "autochecker":
        rows += [
            [btn("🎯 Где ловить", f"tpl_ac_where:{tpl_id}")],
            [btn("🤖 Источник: @send", f"tpl_ac_source:{tpl_id}")],
            [btn("📅 Лимит в сутки", f"tpl_ac_daily:{tpl_id}")],
            [btn("🔁 Попытки на чек", f"tpl_ac_attempts:{tpl_id}")],
        ]

    rows.append([btn("🗑 Удалить шаблон", f"tpl_delete:{tpl_id}")])
    rows.append(back("templates"))
    return InlineKeyboardMarkup(inline_keyboard=rows)


def tpl_texts_kb(tpl_id: int, data: dict) -> InlineKeyboardMarkup:
    mode_names = {
        "random": "Случайный",
        "parts": "Из частей",
        "sequence": "По порядку"
    }
    mode = data.get("msg_mode", "random")
    alt = "✅" if data.get("alt_case") else "❌"
    add_label = "➕ Добавить часть" if mode == "parts" else "➕ Добавить текст"
    rows = [
        [btn(f"🔄 Режим: {mode_names.get(mode, mode)}", f"tpl_texts_mode:{tpl_id}")],
        [btn(f"🔡 Смена регистра: {alt}", f"tpl_texts_alt:{tpl_id}")],
    ]
    if mode == "parts":
        symbols = "✅" if data.get("parts_symbols", False) else "❌"
        rows.append([btn(f"🔣 Символы между частями: {symbols}", f"tpl_texts_symbols:{tpl_id}")])
    rows += [
        [btn(add_label, f"tpl_texts_add:{tpl_id}"),
         btn("➖ Удалить №", f"tpl_texts_del:{tpl_id}")],
        [btn("🗑 Очистить всё", f"tpl_texts_clear:{tpl_id}")],
        back(f"tpl_open:{tpl_id}"),
    ]
    return InlineKeyboardMarkup(inline_keyboard=rows)


def tpl_chats_kb(tpl_id: int, data: dict) -> InlineKeyboardMarkup:
    rnd = "✅" if data.get("random_chats") else "❌"
    folder = data.get("folder_name")
    rows = [
        [btn(f"🔀 Случайная очередь: {rnd}", f"tpl_chats_rand:{tpl_id}")],
        [btn("➕ Добавить чаты", f"tpl_chats_add:{tpl_id}"),
         btn("➖ Удалить №", f"tpl_chats_del:{tpl_id}")],
        [btn("🗑 Очистить все", f"tpl_chats_clear:{tpl_id}")],
        [btn(f"📁 Папка: {folder}" if folder else "📁 Выбрать папку", f"tpl_chats_folder:{tpl_id}")],
    ]
    if folder:
        rows.append([btn("✖️ Убрать папку", f"tpl_chats_folder_clear:{tpl_id}")])
    rows.append(back(f"tpl_open:{tpl_id}"))
    return InlineKeyboardMarkup(inline_keyboard=rows)


def tpl_folder_sessions_kb(tpl_id: int, sessions: list) -> InlineKeyboardMarkup:
    rows = [[btn(f"📱 {s['name']}", f"tpl_folder_session:{tpl_id}:{s['id']}")] for s in sessions]
    rows.append([btn("➕ Добавить аккаунт", "sessions")])
    rows.append(back(f"tpl_chats:{tpl_id}"))
    return InlineKeyboardMarkup(inline_keyboard=rows)


def tpl_folders_kb(tpl_id: int, session_id: int, folders: list) -> InlineKeyboardMarkup:
    rows = [[btn(f"📁 {folder['name']}", f"tpl_folder_set:{tpl_id}:{session_id}:{folder['id']}")] for folder in folders]
    rows.append(back(f"tpl_chats_folder:{tpl_id}"))
    return InlineKeyboardMarkup(inline_keyboard=rows)


def tpl_timings_kb(tpl_id: int) -> InlineKeyboardMarkup:
    return kb(
        [btn("✉️ Задержка между сообщениями", f"tpl_set_delay_msg:{tpl_id}")],
        [btn("🔄 Задержка между циклами", f"tpl_set_delay_cycle:{tpl_id}")],
        back(f"tpl_open:{tpl_id}"),
    )


def tpl_chunks_kb(tpl_id: int, data: dict) -> InlineKeyboardMarkup:
    on = "✅" if data.get("chunk_mode") else "❌"
    return kb(
        [btn(f"📦 Режим пачек: {on}", f"tpl_chunks_toggle:{tpl_id}")],
        [btn("⚙️ Настроить пачки", f"tpl_set_chunk:{tpl_id}")],
        back(f"tpl_open:{tpl_id}"),
    )


def tpl_autosub_kb(tpl_id: int, data: dict) -> InlineKeyboardMarkup:
    enabled = "✅" if data.get("autosub_enabled", False) else "❌"
    actions = data.get("autosub_actions") or {}
    return kb(
        [btn(f"🛠 Автосаб: {enabled}", f"tpl_autosub_toggle:{tpl_id}")],
        [btn(f"Подписываться: {'✅' if actions.get('subscribe', True) else '❌'}", f"tpl_autosub_action:{tpl_id}:subscribe")],
        [btn(f"Вступать в чаты: {'✅' if actions.get('join', True) else '❌'}", f"tpl_autosub_action:{tpl_id}:join")],
        [btn(f"Запускать ботов: {'✅' if actions.get('start_bots', True) else '❌'}", f"tpl_autosub_action:{tpl_id}:start_bots")],
        [btn(f"Задержка: {data.get('autosub_delay', 3)} сек.", f"tpl_autosub_delay:{tpl_id}")],
        back(f"tpl_open:{tpl_id}"),
    )


def tpl_repeats_kb(tpl_id: int, data: dict) -> InlineKeyboardMarkup:
    current = data.get("repeat_cycles")
    label = "Безлимит" if not current else str(current)
    return kb(
        [btn(f"🔁 Повторы: {label}", f"tpl_repeats_toggle:{tpl_id}")],
        [btn("🔢 Указать количество", f"tpl_repeats_set:{tpl_id}")],
        back(f"tpl_open:{tpl_id}"),
    )


def tpl_typing_kb(tpl_id: int, data: dict) -> InlineKeyboardMarkup:
    on = "✅" if data.get("typing_mode") else "❌"
    return kb(
        [btn(f"⌨️ Режим печатает: {on}", f"tpl_typing_toggle:{tpl_id}")],
        [btn("⚙️ Настроить время", f"tpl_set_typing:{tpl_id}")],
        back(f"tpl_open:{tpl_id}"),
    )


def ar_who_kb(tpl_id: int, current: str) -> InlineKeyboardMarkup:
    options = [("all", "Всем"), ("non_contacts", "Только не контактам"), ("contacts", "Только контактам")]
    rows = []
    for val, label in options:
        check = "✅ " if current == val else ""
        rows.append([btn(f"{check}{label}", f"tpl_ar_who_set:{tpl_id}:{val}")])
    rows.append(back(f"tpl_open:{tpl_id}"))
    return InlineKeyboardMarkup(inline_keyboard=rows)


def ac_where_kb(tpl_id: int, current: str) -> InlineKeyboardMarkup:
    labels = {
        "all": "Везде",
        "selected": "Выбранные чаты",
        "except": "Везде кроме",
        "folder": "Папка",
    }
    rows = []
    for value, label in labels.items():
        mark = "✅ " if current == value else ""
        rows.append([btn(f"{mark}{label}", f"tpl_ac_where_set:{tpl_id}:{value}")])
    rows.append(back(f"tpl_open:{tpl_id}"))
    return InlineKeyboardMarkup(inline_keyboard=rows)


def ac_source_kb(tpl_id: int, current: str) -> InlineKeyboardMarkup:
    label = "@send" if current == "send" else "@CryptoBot / @send"
    return kb(
        [btn(f"🤖 Источник: {label}", f"tpl_ac_source_toggle:{tpl_id}")],
        back(f"tpl_open:{tpl_id}"),
    )


def ac_folder_sessions_kb(tpl_id: int, sessions: list) -> InlineKeyboardMarkup:
    rows = [[btn(f"📱 {s['name']}", f"tpl_ac_folder_session:{tpl_id}:{s['id']}")] for s in sessions]
    rows.append([btn("➕ Добавить аккаунт", "sessions")])
    rows.append(back(f"tpl_ac_where:{tpl_id}"))
    return InlineKeyboardMarkup(inline_keyboard=rows)


def ac_folders_kb(tpl_id: int, session_id: int, folders: list) -> InlineKeyboardMarkup:
    rows = [[btn(f"📁 {folder['name']}", f"tpl_ac_folder_set:{tpl_id}:{session_id}:{folder['id']}")] for folder in folders]
    rows.append(back(f"tpl_ac_folder:{tpl_id}"))
    return InlineKeyboardMarkup(inline_keyboard=rows)


def ac_chats_kb(tpl_id: int, data: dict) -> InlineKeyboardMarkup:
    return kb(
        [btn("➕ Указать чаты", f"tpl_ac_chats_add:{tpl_id}")],
        [btn("🗑 Очистить список", f"tpl_ac_chats_clear:{tpl_id}")],
        back(f"tpl_ac_where:{tpl_id}"),
    )


def tb_where_kb(tpl_id: int, current: str) -> InlineKeyboardMarkup:
    return kb(
        [btn("✅ Все личные чаты" if current == "all" else "Все личные чаты", f"tpl_tb_where_set:{tpl_id}:all")],
        [btn("✅ Выборочные чаты" if current == "selected" else "Выборочные чаты", f"tpl_tb_where_set:{tpl_id}:selected")],
        back(f"tpl_open:{tpl_id}"),
    )


def tb_triggers_kb(tpl_id: int, triggers: list) -> InlineKeyboardMarkup:
    rows = []
    for i, t in enumerate(triggers):
        rows.append([btn(f"🔑 {t['keyword']}", f"tpl_tb_trig_open:{tpl_id}:{i}")])
    rows.append([btn("➕ Создать команду", f"tpl_tb_trig_add:{tpl_id}")])
    rows.append(back(f"tpl_open:{tpl_id}"))
    return InlineKeyboardMarkup(inline_keyboard=rows)


def trigger_menu_kb(tpl_id: int, idx: int) -> InlineKeyboardMarkup:
    return kb(
        [btn("✏️ Изменить ответ", f"tpl_tb_trig_edit:{tpl_id}:{idx}")],
        [btn("🗑 Удалить", f"tpl_tb_trig_del:{tpl_id}:{idx}")],
        back(f"tpl_tb_triggers:{tpl_id}"),
    )


# ─── ПРОЦЕССЫ ─────────────────────────────────────────────────────────────────

def processes_kb(user_id: int) -> InlineKeyboardMarkup:
    procs = db.get_processes(user_id)
    rows = []
    for p in procs:
        svc = SERVICE_NAMES.get(p["service"], p["service"])
        icon = "▶️" if p["is_running"] else "⏹️"
        rows.append([btn(f"{icon} {p['name']} | {svc}", f"proc_open:{p['id']}")])
    rows.append([btn("➕ Создать процесс", "proc_create")])
    rows.append(back("main_menu"))
    return InlineKeyboardMarkup(inline_keyboard=rows)


def proc_service_kb() -> InlineKeyboardMarkup:
    return kb(
        [btn("✉️ Рассылка", "proc_svc:broadcast")],
        [btn("🤖 Автоответчик", "proc_svc:autoresponder")],
        [btn("⚡ Триггербот", "proc_svc:triggerbot")],
        [btn("🧾 Авточекер", "proc_svc:autochecker")],
        back("processes"),
    )


def proc_menu_kb(proc_id: int, is_running: bool) -> InlineKeyboardMarkup:
    proc = db.get_process(proc_id) or {}
    flood = proc.get("flood_settings") or {}
    slow = proc.get("slowdown_settings") or {}
    flood_label = "вкл" if flood.get("enabled", True) else "выкл"
    slow_label = "вкл" if slow.get("enabled", False) else "выкл"
    slow_extra = "" if not slow.get("enabled") else (f" +{slow.get('value', 20)}%" if slow.get("mode", "percent") == "percent" else f" +{slow.get('value', 10)}с")
    run_btn = btn("⏹ ОСТАНОВИТЬ", f"proc_stop:{proc_id}") if is_running else btn("🚀 ЗАПУСТИТЬ", f"proc_start:{proc_id}")
    return kb(
        [btn("📱 Выбрать аккаунты", f"proc_accounts:{proc_id}"),
         btn("📋 Выбрать шаблоны", f"proc_template:{proc_id}")],
        [btn("🔔 Настройка логов", f"proc_logs:{proc_id}")],
        [btn("⏱ Время работы", f"proc_work:{proc_id}")],
        [btn(f"🛡 Анти-Заморозка: {flood_label}", f"proc_flood:{proc_id}"),
         btn(f"🐢 Авто-Замедление: {slow_label}{slow_extra}", f"proc_slow:{proc_id}")],
        [run_btn],
        [btn("🗑 Удалить процесс", f"proc_delete:{proc_id}")],
        back("processes"),
    )


def proc_accounts_kb(proc_id: int, user_id: int, selected: list) -> InlineKeyboardMarkup:
    sessions = db.get_sessions(user_id)
    rows = []
    for s in sessions:
        check = "✅ " if s["id"] in selected else ""
        rows.append([btn(f"{check}📱 {s['name']}", f"proc_acc_toggle:{proc_id}:{s['id']}")])
    rows.append([btn("💾 Сохранить", f"proc_acc_save:{proc_id}")])
    rows.append(back(f"proc_open:{proc_id}"))
    return InlineKeyboardMarkup(inline_keyboard=rows)


def proc_template_kb(proc_id: int, user_id: int, service: str, selected: list = None) -> InlineKeyboardMarkup:
    tpls = [t for t in db.get_templates(user_id) if t["service"] == service]
    selected = set(selected or [])
    rows = []
    for t in tpls:
        check = "✅ " if t["id"] in selected else ""
        rows.append([btn(f"{check}📋 {t['name']}", f"proc_tpl_toggle:{proc_id}:{t['id']}")])
    rows.append([btn("💾 Сохранить шаблоны", f"proc_tpl_save:{proc_id}")])
    rows.append(back(f"proc_open:{proc_id}"))
    return InlineKeyboardMarkup(inline_keyboard=rows)


def proc_work_kb(proc_id: int, data: dict) -> InlineKeyboardMarkup:
    mode = data.get("mode", "unlimited")
    if mode == "cycles":
        label = f"{data.get('cycles', 1)} циклов"
    elif mode == "duration":
        label = f"{data.get('duration_text', '0.0.0')}"
    else:
        label = "Бессрочно"
    return kb(
        [btn(f"⏱ Режим: {label}", f"proc_work_mode:{proc_id}")],
        [btn("🔢 Количество циклов", f"proc_work_set:{proc_id}:cycles")],
        [btn("⌛ Время дни.часы.минуты", f"proc_work_set:{proc_id}:duration")],
        back(f"proc_open:{proc_id}"),
    )


def proc_flood_kb(proc_id: int, data: dict) -> InlineKeyboardMarkup:
    enabled = "✅ Включена" if data.get("enabled", True) else "❌ Выключена"
    return kb(
        [btn(f"Анти-Заморозка: {enabled}", f"proc_flood_toggle:{proc_id}")],
        [btn(f"Порог: {data.get('threshold', 3)} FloodWait", f"proc_flood_set:{proc_id}:threshold")],
        [btn(f"Окно: {data.get('hours', 1)} ч.", f"proc_flood_set:{proc_id}:hours")],
        back(f"proc_open:{proc_id}"),
    )


def proc_slow_kb(proc_id: int, data: dict) -> InlineKeyboardMarkup:
    enabled = "✅ Включено" if data.get("enabled", False) else "❌ Выключено"
    mode = "%" if data.get("mode", "percent") == "percent" else "сек."
    return kb(
        [btn(f"Авто-Замедление: {enabled}", f"proc_slow_toggle:{proc_id}")],
        [btn(f"Порог: {data.get('threshold', 1)} FloodWait", f"proc_slow_set:{proc_id}:threshold")],
        [btn(f"Надбавка: +{data.get('value', 20)} {mode}", f"proc_slow_set:{proc_id}:value")],
        [btn("⚙️ Формат надбавки: % или секунды", f"proc_slow_mode:{proc_id}")],
        back(f"proc_open:{proc_id}"),
    )


def proc_logs_kb(proc_id: int, current: str) -> InlineKeyboardMarkup:
    options = [("all", "Все"), ("important", "Важные"), ("errors", "Ошибки"), ("off", "Отключено")]
    rows = []
    for val, label in options:
        check = "✅ " if current == val else ""
        rows.append([btn(f"{check}{label}", f"proc_set_log:{proc_id}:{val}")])
    rows.append(back(f"proc_open:{proc_id}"))
    return InlineKeyboardMarkup(inline_keyboard=rows)


# ─── ФУНКЦИИ ──────────────────────────────────────────────────────────────────

def functions_kb() -> InlineKeyboardMarkup:
    broadcast_url = db.get_setting("func_broadcast_url") or "https://t.me/"
    ar_url = db.get_setting("func_ar_url") or "https://t.me/"
    tb_url = db.get_setting("func_tb_url") or "https://t.me/"
    return kb(
        [url_btn("✉️ Рассылка", broadcast_url)],
        [url_btn("🤖 Автоответчик", ar_url)],
        [url_btn("⚡ Триггербот", tb_url)],
        [url_btn("🧾 Авточекер", db.get_setting("func_autochecker_url") or "https://t.me/")],
        back("main_menu"),
    )


# ─── ПОДПИСКИ ─────────────────────────────────────────────────────────────────

def subscriptions_kb(plans: list, user_id: int = None) -> InlineKeyboardMarkup:
    rows = []
    discount = db.get_user_discount(user_id) if user_id else 0
    for p in plans:
        price = db.effective_price(p)
        if discount:
            price = round(price * (1 - discount / 100), 2)
        disc_note = f" (скидка {p['discount_pct']}%)" if p.get("discount_pct") else ""
        rows.append([btn(f"💳 {p['name']} — ${price:.2f}{disc_note}", f"sub_buy:{p['id']}")])
    rows.append([btn("🎟 Ввести промокод", "promo_enter")])
    rows.append(back("main_menu"))
    return InlineKeyboardMarkup(inline_keyboard=rows)


# ─── РЕФЕРАЛЬНАЯ ПРОГРАММА ────────────────────────────────────────────────────

def referral_kb() -> InlineKeyboardMarkup:
    return kb(
        [btn("💸 Вывести средства", "ref_withdraw")],
        back("main_menu"),
    )


# ─── ПОДДЕРЖКА / КАНАЛ ────────────────────────────────────────────────────────

def support_kb() -> InlineKeyboardMarkup:
    support_url = db.get_setting("support_url") or "https://t.me/"
    return kb([url_btn("👨‍💻 Написать в поддержку", support_url)], back("main_menu"))


def channel_kb() -> InlineKeyboardMarkup:
    channel_url = db.get_setting("channel_url") or "https://t.me/"
    return kb([url_btn("📢 Перейти в канал", channel_url)], back("main_menu"))


# ─── АДМИН-МЕНЮ ───────────────────────────────────────────────────────────────

def admin_main_kb(user_id: int) -> InlineKeyboardMarkup:
    is_own = db.is_owner(user_id)
    rows = [
        [btn("⚙️ Общие настройки", "adm_settings")],
        [btn("💳 Управление подписками", "adm_subs")],
        [btn("🤝 Управление рефералами", "adm_ref")],
        [btn("🎟 Промокоды", "adm_promos")],
        [btn("📢 Рассылка всем", "adm_broadcast")],
        [btn("👥 Пользователи", "adm_users")],
        [btn("📊 Статистика", "adm_statistics")],
    ]
    if is_own:
        rows.append([btn("👑 Управление админами", "adm_admins")])
    rows.append(back("main_menu"))
    return InlineKeyboardMarkup(inline_keyboard=rows)


def adm_settings_kb() -> InlineKeyboardMarkup:
    return kb(
        [btn("🔑 Установить API Keys", "adm_set_api")],
        [btn("🔗 Изменить ссылки", "adm_set_links")],
        [btn("🖼 Лимиты медиафайлов", "adm_media_limits")],
        back("admin_menu"),
    )


def adm_links_kb() -> InlineKeyboardMarkup:
    return kb(
        [btn("📢 Ссылка канала", "adm_link_channel")],
        [btn("👨‍💻 Ссылка поддержки", "adm_link_support")],
        [btn("✉️ Канал Рассылки", "adm_link_func_broadcast")],
        [btn("🤖 Канал Автоответчика", "adm_link_func_ar")],
        [btn("⚡ Канал Триггербота", "adm_link_func_tb")],
        [btn("🧾 Канал Авточекера", "adm_link_func_autochecker")],
        back("adm_settings"),
    )


def adm_subs_kb(is_own: bool) -> InlineKeyboardMarkup:
    rows = [
        [btn("💰 Управление тарифами", "adm_plans")],
        [btn("🎁 Выдать дни подписки", "adm_give_sub")],
        [btn("➖ Списать дни подписки", "adm_take_sub")],
    ]
    if is_own:
        rows.append([btn("🏦 Настройки CryptoBot", "adm_cryptobot")])
    rows.append(back("admin_menu"))
    return InlineKeyboardMarkup(inline_keyboard=rows)


def adm_plans_kb(plans: list) -> InlineKeyboardMarkup:
    rows = []
    for p in plans:
        rows.append([btn(f"📋 {p['name']} ({p['days']}д) — ${p['price_usd']}", f"adm_plan_edit:{p['id']}")])
    rows.append([btn("➕ Создать тариф", "adm_plan_create")])
    rows.append(back("adm_subs"))
    return InlineKeyboardMarkup(inline_keyboard=rows)


def adm_give_sub_kb() -> InlineKeyboardMarkup:
    return kb(
        [btn("👥 Выдать всем активным", "adm_give_sub_all")],
        [btn("👤 Выдать по ID", "adm_give_sub_id")],
        back("adm_subs"),
    )


def adm_ref_kb() -> InlineKeyboardMarkup:
    ref_enabled = db.get_setting("ref_enabled", True)
    status = "✅ Включена" if ref_enabled else "❌ Отключена"
    return kb(
        [btn(f"Реф. система: {status}", "adm_ref_toggle")],
        [btn("⚙️ Настроить уровни", "adm_ref_levels")],
        back("admin_menu"),
    )


def adm_promos_kb() -> InlineKeyboardMarkup:
    return kb(
        [btn("➕ Создать промокод", "adm_promo_create")],
        [btn("📋 Список промокодов", "adm_promo_list")],
        back("admin_menu"),
    )


def adm_promo_list_kb(promos: list) -> InlineKeyboardMarkup:
    rows = [[btn(f"🗑 Удалить {p['code']}", f"adm_promo_delete:{p['id']}")] for p in promos]
    rows.append(back("adm_promos"))
    return InlineKeyboardMarkup(inline_keyboard=rows)


def adm_admins_kb() -> InlineKeyboardMarkup:
    return kb(
        [btn("➕ Добавить админа", "adm_admin_add")],
        [btn("➖ Удалить админа", "adm_admin_remove")],
        [btn("📋 Список админов", "adm_admin_list")],
        back("admin_menu"),
    )


def adm_media_limits_kb() -> InlineKeyboardMarkup:
    no_limits = db.get_setting("media_no_limits", False)
    return kb(
        [btn("🖼 Макс. вес картинки (МБ)", "adm_media_photo")],
        [btn("🎞 Макс. вес гифки (МБ)", "adm_media_gif")],
        [btn("🎬 Макс. вес видео (МБ)", "adm_media_video_size")],
        [btn("⏱ Макс. длительность видео (сек)", "adm_media_video_dur")],
        [btn("🚫 Отключить лимиты" if not no_limits else "✅ Включить лимиты", "adm_media_toggle")],
        back("adm_settings"),
    )


def adm_users_kb() -> InlineKeyboardMarkup:
    return kb(
        [btn("📋 Список пользователей", "adm_user_list")],
        [btn("🏆 Топ активных", "adm_user_top"),
         btn("🕘 Топ за 24 часа", "adm_user_top_24h")],
        [btn("🔍 Поиск по ID", "adm_user_search")],
        [btn("🔎 Поиск по сессии", "adm_session_search")],
        [btn("🚫 Бан / Разбан", "adm_user_ban")],
        back("admin_menu"),
    )


def adm_user_detail_kb(user_id: int, sessions: list) -> InlineKeyboardMarkup:
    """Кнопки карточки пользователя, включая переход к его сессиям."""
    rows = []
    for session in sessions[:50]:
        rows.append([btn(
            f"📱 {session['name']} · ID {session['id']}",
            f"adm_session_view:{session['id']}",
        )])
    rows.append([btn("🚫 Бан/Разбан", f"adm_ban_user_id:{user_id}")])
    rows.append([btn("🎁 Выдать подписку", f"adm_give_sub_single:{user_id}")])
    rows.append(back("adm_users"))
    return InlineKeyboardMarkup(inline_keyboard=rows)
